module.exports = {
  root: true,
  env: {
    node: true
  },
  plugins: ['vue'], // enable vue plugin
  extends: ['plugin:vue/essential', '@vue/prettier'],
  rules: {
    'no-console': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'prettier/prettier': [
      'warn',
      {
        '#': 'prettier config in here :)',
        singleQuote: true,
        semi: true,
        trailingComma: 'none',
        "indent": [4, "tab"]
      }
    ]
  },
  parserOptions: {
    parser: 'babel-eslint'
  }
}
