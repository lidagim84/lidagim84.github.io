export const TeamType = {
  T7901: 't7901', //입법정책팀
  T7911: 't7911', //법제지원팀
  T8301: 't8301',  //지방분권팀
  T7921: 't7921', //의정자료팀
};
//pl_sppt : 입안지원, lm_pc: 입법정책, lg_adv : 법률자문, pf_info:전문정보
export const TeamAssignType = {
  "pl_sppt": 't7911',
  "lm_pc": 't8301',
  "lg_adv": 't7911',
  "pf_info": 't7921',
};
export const ReqTypeBtnClassName = {
  "pl_sppt": 'label-warning',
  "lm_pc": 'label-secondary',
  "lg_adv": 'label-danger',
  "pf_info": 'label-success',
};

export const ReqTypeResLimitDate = {
  "pl_sppt": 30,
  "lm_pc": 20,
  "lg_adv": 7,
  "pf_info": null,
};

export const RowHeight = 53;
//보류, 철회
//신청대기, 회답중, 회답완료, (요청자일경우.)
//요청중, 접수대기, 회답중, 결제중, 회답완료.(팀장, 과장 권한자가 배정안한거 따로 표시.)))
//배정대기
export const userTypeStateMap = {
  member: ["request", "wait", "res", "approve", "complete"],
  supporter: ["request wait", "res", "complete"],
  councilor: ["request wait", "res", "complete"]
}

export const stateNameMap = {
  "request": '요청중',
  "request wait": '접수대기',
  "wait": '접수대기',
  "res": '회답중',
  "approve": '결제중',
  "complete": '회답완료',
  "retract": '요청철회',
  "hold": '보류'
};

export const stateCommentMap = {
  "request": '조사관 미배정',
  "request wait": '조사관 배정 미확정',
  "wait": '조사관 배정 미확정',
  "res": '회답서 작성중',
  "approve": '회답서 결재상신',
  "complete": '회답 완료',
  "retract": '요청 철회',
  "hold": '회답 보류'
};

export const RoleType = {
  Councilor: 'councilor',
  Supporter: 'supporter',
  Examiner: 'examiner',
  Admin: 'admin',
  TeamMember: 'team_member',
  TeamLeader: 'team_leader'
};

export const ReqState = {
  REQ: 'request', //요청중
  WAIT: 'wait', //접수대기
  RES: 'res', //회답중
  HOLD: 'hold', //보류
  COMEBACK: 'comeback', //재기
  APPROVE: 'approve', //결재중
  REJECT: 'reject', //전자결제 반려 임시
  // APPPROVED: 'approved', //전자결제 승인 임시
  COMPLETE: 'complete', //회답완료
  RETRACT: 'retract' //요청철회
};

export const ReqTemplate = {
  "lm_pc": [
    {
      label: '요청제목',
      field_nm: 'title',
      type: 'input',
      required: 'true',
      value: ''
    },
    {
      label: '요청내용',
      field_nm: 'content',
      type: 'textarea',
      required: 'true',
      value: ''
    },
    {
      label: '요청사항',
      field_nm: 'req_map',
      type: 'checkbox-group',
      code: 'req_map',
      value: '',
      children: []
    },
    { label: '메 모', field_nm: 'memo', type: 'textarea', value: '' }
  ],
  "pl_sppt": [
    { label: '제 목', field_nm: 'title', type: 'input', required: 'true', value: '' },
    { label: '제안이유', field_nm: 'content', type: 'textarea', required: 'true', value: '' },
    { label: '제개정방향', field_nm: 'content2', type: 'textarea', required: 'true', value: '' },
    { label: '기 타', field_nm: 'etc', type: 'textarea', value: '' },
    { label: '메 모', field_nm: 'memo', type: 'textarea', value: '' }
  ],
  "lg_adv": [
    { label: '제목', field_nm: 'title', type: 'input', required: 'true', value: '' },
    { label: '자문배경', field_nm: 'background', type: 'textarea', required: 'true', value: '' },
    { label: '자문요지', field_nm: 'content', type: 'textarea', required: 'true', value: '' },
    { label: '자문내용', field_nm: 'content2', type: 'textarea', required: 'true', value: '' },
    { label: '의뢰자의견', field_nm: 'content3', type: 'textarea', value: '' },
    { label: '참고사항', field_nm: 'etc', type: 'textarea', value: '' },
    { label: '메모', field_nm: 'memo', type: 'textarea', value: '' }
  ],
  "pf_info": [
    { label: '제목', field_nm: 'title', type: 'input', required: 'true', value: '' },
    { label: '요청내용', field_nm: 'content', type: 'textarea', required: 'true', value: '' },
    { label: '메 모', field_nm: 'memo', type: 'textarea', value: '' }
  ]
};



export const queryMap = {
  "000000000": {
    tableNm: "getTableFigure",
    data_id: "BDM00000014105"
  },
  "201010000": {
    tableNm: "getResearchReport",
    div_cd: "201010000"
  },
  "202010000": {
    tableNm: "getJournal",
    div_cd: "202010000"
  },
  "203010000": {
    tableNm: "getSeminarConferenceData",
    div_cd: "203010000"
  },
  "204010000": {
    tableNm: "getResearchNotification",
    div_cd: "204010000"
  },
  "204020000": {
    tableNm: "getResearchNotification",
    div_cd: "204020000"
  },
  "204030000": {
    tableNm: "getResearchNotification",
    div_cd: "204030000"
  },
  "205010000": {
    tableNm: "getPolicyResearchServiceData",
    div_cd: "205010000"
  },
  "206010000": {
    tableNm: "getOtherData",
    div_cd: "206010000"
  }
};