<template>
  <div>
    <router-view />
    <modals-container />
    <dialogs-wrapper transition-name="fade"></dialogs-wrapper>
  </div>
</template>

<script>
//var g_isPostBack = false;
export default {
  name: 'app',
  data() {
    return {};
  },
  methods: {},
  created() {
    this.$store.dispatch('getCodeList', { codeDiv: 'code_div' });
  }
};
</script>

<style>
.modal {
  background: rgba(0, 0, 0, 0.5);
  /* position: absolute !important; */
}


</style>