<template>
  <div>
    <div class="bootstrap-tagsinput wrap">
      <span
        class="tag label label-primary"
        v-for="(tag, index) in tags"
        :key="index"
      >{{tag.keyword}}<span
          data-role="remove"
          @click="delTag(index)"
        ></span></span>
      <input
        type="text"
        class="tagsinput"
        placeholder=""
        v-on:keyup.13="addTag"
        v-model="tagValues"
        style="width:100%"
      >
    </div>
    <label><span class="required">*</span> 엔터키로 구분합니다.</label>
  </div>
</template>

<script>
import { getKeywordList, setKeywordList } from '../../services';

export default {
  name: 'tag',
  props: {
    job_id: {
      type: String,
      default: '',
      required: true
    },
    task_id: {
      type: String,
      default: '',
      required: true
    }
  },
  data() {
    return {
      tags: [],
      tagValues: null
    };
  },
  watch: {
    task_id(newVal) {
      this.getKeywordList();
    }
  },
  methods: {
    addTag() {
      if (!this.tagValues) {
        return;
      }
      let sameTags = this.tags.filter(
        (t, index) => t.keyword == this.tagValues
      );
      if (sameTags.length) {
        alert('중복값이 존재합니다.');
        this.tagValues = '';
        return;
      }
      this.tags.push({
        job_id: this.job_id,
        task_id: null,
        keyword: this.tagValues
      });
      this.tagValues = null;
    },
    delTag(tagIndex) {
      this.tags = this.tags.filter((t, index) => index != tagIndex);
    },
    setKeywordList(taskId) {
      this.tags.map(tag => {
        tag.job_id = this.job_id;
        tag.task_id = taskId;
        return tag;
      });
      return setKeywordList(this.tags).then(res => {
        return res.data;
      });
    },
    getKeywordList() {
      return getKeywordList({
        job_id: this.job_id,
        task_id: this.task_id
      }).then(res => {
        return (this.tags = res.data);
      });
    }
  },
  created() {
    if (this.task_id) {
      this.getKeywordList();
    }
  }
};
</script>

<style>
.bootstrap-tagsinput {
  border: 1px solid #e5e6e7;
  box-shadow: none;
  background-color: #fff;
  /* display: inline-block; */
  padding: 4px 6px;
  color: #555;
  vertical-align: middle;
  border-radius: 4px;
  max-width: 100%;
  line-height: 22px;
  cursor: text;
  width: 100%;
  /* height: auto; */
  display: -webkit-flex; /* Safari */
  -webkit-flex-wrap: wrap; /* Safari 6.1+ */
  display: flex;
  flex-wrap: wrap;
}
.tagsinput {
  border: none;
  box-shadow: none;
  outline: none;
  background-color: transparent;
  padding: 0 6px;
  margin: 0;
  width: auto;
  max-width: inherit;
}
.bootstrap-tagsinput.form-control input::-moz-placeholder {
  color: #777;
  opacity: 1;
}
.bootstrap-tagsinput.form-control input:-ms-input-placeholder {
  color: #777;
}
.bootstrap-tagsinput.form-control input::-webkit-input-placeholder {
  color: #777;
}
.bootstrap-tagsinput input:focus {
  border: none;
  box-shadow: none;
}
.bootstrap-tagsinput .tag {
  margin: 2px;
  color: white;
}
.bootstrap-tagsinput .tag [data-role='remove'] {
  margin-left: 8px;
  cursor: pointer;
}
.bootstrap-tagsinput .tag [data-role='remove']:after {
  content: 'x';
  padding: 0px 2px;
}
.bootstrap-tagsinput .tag [data-role='remove']:hover {
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2),
    0 1px 2px rgba(0, 0, 0, 0.05);
}
.bootstrap-tagsinput .tag [data-role='remove']:hover:active {
  box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
}
</style>
