import Vue from 'vue';
import { mapGetters, mapActions } from "vuex";
import Datepicker from './datepicker/Datepicker';
import { VTable } from './table';
import VPager from './pagination/Pagination';
import VDropdown from './dropdown';
import { VCheckbox, VCheckboxGroup } from './checkbox';
import { VSwitch, VRadio, VRadioGroup } from './radio';

import VFileupload from './fileupload/FileUpload';
import ElUpload from './fileupload';
import VProgress from './progress/Progress';
import VTag from './tag/Tag';
import { SearchInput, SelectionInput } from './input';
import { VTabs, VTab } from './tab';
import Tree from './tree';
import VButton from './button/Button';
import VueToastr from './toastr';
Vue.use(VueToastr, {
  defaultPosition: 'toast-top-right',
  defaultType: 'info',
  defaultTimeout: 5000
});

import { DialogsWrapper, create } from './modal';
import Alert from './alert/Alert';

const alert = create(Alert, 'title', 'content');
const confirm = create(Alert, 'title', 'content', 'confirm');

import WidgetContainer from '../views/widget/WidgetContainer';
import InfoWidgetContainer from '../views/widget/InfoWidgetContainer';
import { popUserList } from '../views/pop';
import { SelectionStaffList, Comment, TemplateLoader } from '../views/common';

import * as constants from '../constants';

import WidgetWrapper from '../views/dashboard/WidgetWrapper';
import resize from 'vue-resize-directive';
import Clickoutside from '../utils/clickoutside';

import plugin from './draggableModal';
Vue.use(plugin, {
  dynamic: true,
  injectModalsContainer: true,
  dynamicDefaults: {
    foo: 'foo'
  }
});

import {
  getUserList,
  fileDownload,
  fileDownload2,
  getSummaryStat,
  getStaffList,
  getContentMapList,
  setContentMapList,
  sendMessage
} from '../services';
import moment from 'moment'
export default {
  name: 'base',
  directives: {
    resize,
    Clickoutside
  },
  filters: {
    stateClass: className => this.stateClass(className)
  },
  data() {
    return {
      constants: constants,
      isFullScreen: false,
      jobName: {}
    };
  },
  components: {
    DialogsWrapper,
    Datepicker,
    VTable,
    VPager,
    VButton,
    VDropdown,
    VCheckbox,
    VCheckboxGroup,
    VFileupload,
    VTag,
    VTabs,
    VTab,
    VRadio,
    VRadioGroup,
    // VSwitch,
    WidgetContainer,
    SelectionStaffList,
    SearchInput,
    SelectionInput,
    Tree,
    Comment,
    WidgetWrapper,
    InfoWidgetContainer,
    TemplateLoader,
    VProgress,
    ElUpload
  },
  computed: {
    ...mapGetters(["menuList", "currentMenuInfo"]),
    loginUserInfo() {
      let loginUser = localStorage.getItem('userInfo');
      if (loginUser) {
        return JSON.parse(loginUser);
      }
      return { user_id: 'test' };
    },
    isTeamLeaderAndAdmin() {
      const authorities = this.loginUserInfo.authorities;
      if (authorities.length) {
        return (
          authorities.filter(
            item => 'team_leader admin'.indexOf(item.authority) != -1
          ).length > 0
        );
      }
      return false;
    },
    isExaminer() {
      const authorities = this.loginUserInfo.authorities;
      if (authorities.length) {
        return (
          authorities.filter(
            item => 'examiner' == item.authority
          ).length > 0
        );
      }
      return false;
    },
    isAdmin() {
      const authorities = this.loginUserInfo.authorities;
      if (authorities.length) {
        return (
          authorities.filter(
            item => 'admin' == item.authority
          ).length > 0
        );
      }
      return false;
    },
    isReqUser() {
      return 'councilor supporter'.indexOf(this.loginUserInfo.user_type) != -1;
    },
    configItemList() {
      let configInfo = localStorage.getItem('configInfo');
      if (configInfo) {
        return JSON.parse(configInfo);
      }
      return [];
    },
    userRoleType() {
      let type = 'default';
      if (this.loginUserInfo.user_type == 'member') {
        if (this.isAuthCheck(this.constants.RoleType.Admin)) {
          type = this.constants.RoleType.Admin;
        } else if (this.isAuthCheck(this.constants.RoleType.TeamLeader)) {
          type = this.constants.RoleType.TeamLeader;
        } else if (this.isAuthCheck(this.constants.RoleType.Examiner)) {
          type = this.constants.RoleType.Examiner;
        } else {
          type = this.constants.RoleType.TeamMember;
        }
      }
      return type;
    },
    userIdProp() {
      const isReqUser = this.isReqUser;
      let userType = '';
      if (isReqUser) {
        userType = this.loginUserInfo.user_type + '_id';
      } else {
        if (this.userRoleType != this.constants.RoleType.Admin && this.userRoleType != this.constants.RoleType.TeamLeader) {
          userType = this.userRoleType + '_id'
        }
      }
      return userType;
    }
  },
  methods: {
    ...mapActions({
      getMenuList: "getMenuList",
      setMenu: "setMenu"
    }),
    isImg(val) {
      return /\.(jpe?g|png|gif)$/i.test(val);
    },
    alert(title = '확인', msg, type = 'info') {
      return alert(title, msg, type).then(res => res);
    },
    confirm(title = '확인', msg, type = 'confirm') {
      return confirm(title, msg, type).then(res => res);
    },
    addMng(isMulti, filter, selectedList) {
      return popUserList(isMulti, filter, selectedList).then(res => {
        if (!res && isMulti) {
          return [];
        }
        return res;
      });
    },
    findUserList(params) {
      return getUserList(params).then(res => {
        const data = res.data;
        return data.list;
      });
    },
    commonCodeList(codeDiv) {
      let codeList = JSON.parse(localStorage.getItem('commonCodeList'));
      if (codeList && codeList.length) {
        return codeList.filter(item => item.code_div == codeDiv).map(item => {
          return { label: item.value, value: item.detail_code };
        });
      }
      return [];
    },
    commonCode(codeDiv, value) {
      let codeList = JSON.parse(localStorage.getItem('commonCodeList'));
      if (codeList && codeList.length) {
        let data = codeList.filter(
          item => item.code_div == codeDiv && item.detail_code == value
        );
        value = data.length > 0 ? data[0].value : value;
      }
      return value;
    },
    stateBtn(state) {
      if (!state) return;
      return `<span class='btn btn-xs ${this.stateClass(
        state
      )}' style='padding: 0px 3px 1px 3px;''>${state}</span>`;
    },
    getStateIndex(state, stateInfo) {
      return stateInfo.findIndex(item => item.includes(state)) + 1;
    },
    sateProress(state, preState) {
      if (!state) {
        return `<div class='progress progress-comm progress-xl'>
        <div
          class='progress-stat-temp'
          role='progressbar'          
          aria-valuemin='0'
          style='width:100%;text-align:center'
          aria-valuemax='100'>임시저장</div>
      </div>`;
      }
      //보류, 요철철회일경우 표시는 전단계를 state에, 보류 이미지로 표시한다.
      //progress-bar progress-stat-5
      const stateInfo = this.constants.userTypeStateMap[
        this.loginUserInfo.user_type
      ];
      let index = 0;
      let stateNm = '';
      let val = 0;

      if (preState) {
        index = 6;
        stateNm = this.constants.stateNameMap[state];
        val =
          (this.getStateIndex(preState, stateInfo) / stateInfo.length) * 100;
      } else {
        index = this.getStateIndex(state, stateInfo);
        stateNm = this.constants.stateNameMap[stateInfo[index - 1]];
        val = (index / stateInfo.length) * 100;

        if (val == 100) {
          index = 5;
        }
      }
      let title = this.constants.stateCommentMap[state];;


      // let stateNm = this.commonCode('req_state', state);
      return `<div class='progress progress-comm progress-xl'>
                <div
                  title='${title}'
                  class='progress-bar progress-stat-${index}'
                  role='progressbar'
                  style='width:${val}%'
                  aria-valuenow='${val}'
                  aria-valuemin='0'
                  aria-valuemax='100'>${stateNm}</div>
              </div>`;
    },
    setReqTypeStyle(reqType) {
      return `<div class='label ${
        this.constants.ReqTypeBtnClassName[reqType]
        }'>${this.commonCode('req_type', reqType)}</div>`;
    },
    isAuthCheck(authId) {
      const authorities = this.loginUserInfo.authorities;
      if (authorities && authorities.length) {
        return authorities.filter(item => item.authority == authId).length > 0;
      }
      return false;
    },
    isEditableState(state) {
      if (!state) return true;
      return 'request wait res'.indexOf(state) != -1;
    },
    fileDownload(url, fileName) {
      return fileDownload(url, fileName);
    },
    fileDownload2(url) {
      return fileDownload2(url);
    },
    getSummaryStat() {
      let userType = this.userIdProp;
      let userId = this.loginUserInfo.user_id;
      let state = "";
      if (userType == this.constants.RoleType.TeamMember + "_id") {
        state = this.constants.ReqState.COMPLETE;
      }
      return getSummaryStat({
        user_type: userType,
        user_id: userId,
        state: state
      }).then(res => {
        return res.data;
      });
    },
    getStaffList(jobId, taskId, userType) {
      return getStaffList({
        job_id: jobId,
        task_id: taskId,
        user_type: userType
      }).then(res => {
        return res.data;
      });
    },
    setContentMapList(params) {
      if (!params.length) Promise.resolve(0)
      return setContentMapList(params).then(res => {
        return res.data;
      });
    },
    getContentMapList(taskId, parentFieldNm) {
      return getContentMapList({
        task_id: taskId,
        parent_field_nm: parentFieldNm
      }).then(res => {
        return res.data;
      });
    },
    parseReqNo(reqNo) {
      if (reqNo.length == 8) {
        return reqNo.substring(0, 4) + '-' + Number(reqNo.substring(5, 8));
      } else {
        return reqNo;
      }
    },
    // 업무코드.
    // email, sms, 알림톡.
    // list 업무상태에 따른 message코드 매핑
    // 회답수신인 리스트.
    sendMessage(taskId, actType, msgTypes, receiverList) {
      let massageTempate = [];
      for (let msg of msgTypes) {
        for (let receiver of receiverList) {
          let tempate = {
            task_id: taskId,
            act_type: actType,
            msg_type: msg,
            receiver: {
              user_id: receiver.user_id
            }
          }
          massageTempate.push(tempate)
        }
      }
      return sendMessage(massageTempate).then(res => {
        return res;
      })
    },
    getCurrnetMenu(menuId, menuList, level, parent) {
      let rnt = {};
      for (let m of menuList) {
        this.menuDepth[level] = m;
        if (menuId == m.menu_id) {
          if (parent) {
            parent.expanded = true;
            m.parent = parent;
          }
          m.menuDepth = this.menuDepth;
          return (rnt = m);
        } else if (m.children) {
          rnt = this.getCurrnetMenu(menuId, m.children, ++level, m);
          if (rnt && rnt.menu_id) {
            return rnt;
          }
        }
        if (!parent) {
          level = 0;
          this.menuDepth = [];
        }
      }
      return rnt;
    },
    pdfExport() {

    },
    getDateAgo(value, type = 'days') {
      return moment().subtract(type, value).format('YYYYMMDD');
    },
    getDateAdd(value, type = 'days') {
      return moment().add(type, value).format('YYYYMMDD');
    }

  }
};
