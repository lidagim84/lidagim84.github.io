<template>
  <label class="v-checkbox-wrapper" :style="{'display':displayType}">
    <span :class="checkboxClasses">
      <input
        class="v-checkbox-input"
        type="checkbox"
        :value="value"
        v-model="model"
        @change="change"
      />

      <span class="v-checkbox-inner"></span>
    </span>
    <span>
      <slot v-if="showSlot">{{ label }}</slot>
    </span>
  </label>
</template>

<script>
import utils from "../table/mixins/utils.js";
export default {
  name: "v-checkbox",
  props: {
    value: {},
    // use in checkbox-group
    label: {
      type: [String, Number]      
    },
    disabled: {
      type: Boolean,
      default: false
    },
    // partial selection effect
    indeterminate: Boolean,
    showSlot: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      model: false,
      _checkboxGroup: null,
      useYn: false
    };
  },

  computed: {
    checkboxClasses() {
      return [
        "v-checkbox",
        {
          ["v-checkbox-checked"]: this.model,
          ["v-checkbox-disabled"]: this.disabled,
          ["v-checkbox-indeterminate"]: this.indeterminate
        }
      ];
    },

    isCheckBoxGroup() {
      this._checkboxGroup = utils.getParentCompByName(this, "v-checkbox-group");
      return this._checkboxGroup ? true : false;
    },

    displayType() {
      var style = "inline-block";

      if (this.isCheckBoxGroup) {
        style = this._checkboxGroup.isVerticalShow ? "block" : "inline-block";
      }
      return style;
    }
  },

  methods: {
    change(event) {
      if (this.disabled) {
        this.model = false;
        return false;
      }
      const checked = event.target.checked;
      this.$emit("input", event.target.value);
      this.$emit("change");
      if (this.isCheckBoxGroup) {
        this._checkboxGroup.updateModel(event.target.value, checked);
      }
    },
    initModel() {
      if (this.isCheckBoxGroup) {
        if (
          Array.isArray(this._checkboxGroup.value) &&
          this._checkboxGroup.value.length > 0
        ) {
          if (this._checkboxGroup.value.indexOf(this.value) > -1) {
            this.model = this.value;
          }
        }
      } else {
        this.model = false;
      }
    },
    updateModelBySingle() {
      if (!this.disabled) {
        this.model = this.value;
      }
    },
    updateModelByGroup(checkBoxGroup) {
      if (checkBoxGroup.indexOf(this.value) > -1) {
        if (!this.disabled) {
          this.model = this.value;
        }
      } else {
        if (!this.disabled) {
          this.model = false;
        }
      }
    }
  },

  created() {
    this.initModel();
  },

  watch: {
    value(val) {
      this.updateModelBySingle();
    }
  }
};
</script>


<style>
.v-checkbox-group .input-group {
  margin-left: -32px;
}
.v-checkbox-group .input-group label {
  margin-left: 32px;
}

.v-checkbox-wrapper {
  cursor: pointer;
  font-size: 12px;
  display: inline-block;
  position: relative;
}

.v-checkbox {
  white-space: nowrap;
  cursor: pointer;
  outline: none;
  display: inline-block;
  line-height: 1;
  position: relative;
  vertical-align: text-bottom;
}

.v-checkbox-checked:after {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 2px;
  border: 1px solid #108ee9;
  content: "";
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
  visibility: hidden;
}

.v-checkbox-input {
  position: absolute;
  left: 0;
  z-index: 1;
  cursor: pointer;
  opacity: 0;
  filter: alpha(opacity=0);
  top: 0;
  bottom: 0;
  right: 0;
  /* width: 100%;
    height: 100%;*/
}

.v-checkbox-inner {
  position: relative;
  top: 0;
  left: 0;
  display: block;
  width: 13px;
  height: 13px;
  border: 1px solid #707070;
  border-radius: 0;
  background-color: #fff;
  -webkit-transition: all 0.3s;
  transition: all 0.3s;
}

.v-checkbox-inner:after {
  -webkit-transform: rotate(45deg) scale(0);
  -ms-transform: rotate(45deg) scale(0);
  transform: rotate(45deg) scale(0);
  position: absolute;
  left: 4px;
  top: 1px;
  display: table;
  width: 5px;
  height: 8px;
  border: 2px solid #212121;
  border-top: 0;
  border-left: 0;
  content: " ";
  -webkit-transition: all 0.1s cubic-bezier(0.71, -0.46, 0.88, 0.6);
  transition: all 0.1s cubic-bezier(0.71, -0.46, 0.88, 0.6);
}

.v-checkbox-checked .v-checkbox-inner:after {
  -webkit-transform: rotate(45deg) scale(1);
  -ms-transform: rotate(45deg) scale(1);
  transform: rotate(45deg) scale(1);
  position: absolute;
  display: table;
  border: 2px solid #212121;
  border-top: 0;
  border-left: 0;
  content: " ";
  -webkit-transition: all 0.2s cubic-bezier(0.12, 0.4, 0.29, 1.46) 0.1s;
  transition: all 0.2s cubic-bezier(0.12, 0.4, 0.29, 1.46) 0.1s;
}

.v-checkbox-checked .v-checkbox-inner,
.v-checkbox-indeterminate .v-checkbox-inner {
  border-color: #26a0da;
}

.v-checkbox-input:focus + .v-checkbox-inner,
.v-checkbox-wrapper:hover .v-checkbox-inner,
.v-checkbox:hover .v-checkbox-inner {
  border-color: #108ee9;
}

.v-checkbox-disabled {
  cursor: not-allowed;
}

.v-checkbox-disabled.v-checkbox-checked .v-checkbox-inner:after {
  -webkit-animation-name: none;
  animation-name: none;
  border-color: rgba(0, 0, 0, 0.25);
}

.v-checkbox-disabled .v-checkbox-input {
  cursor: not-allowed;
}

.v-checkbox-disabled .v-checkbox-inner {
  border-color: #d9d9d9 !important;
  background-color: #f7f7f7;
}

.v-checkbox-disabled .v-checkbox-inner:after {
  -webkit-animation-name: none;
  animation-name: none;
  border-color: #f7f7f7;
}

.v-checkbox-disabled + span {
  color: rgba(0, 0, 0, 0.25);
  cursor: not-allowed;
}

.v-checkbox-indeterminate .v-checkbox-inner:after {
  content: " ";
  -webkit-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
  position: absolute;
  left: 2px;
  top: 5px;
  width: 8px;
  height: 1px;
}

.v-checkbox-indeterminate.v-checkbox-disabled .v-checkbox-inner:after {
  border-color: rgba(0, 0, 0, 0.25);
}

.v-select-items-multiple {
  display: table;
  width: 100%;
  padding: 5px;
}

.v-select-items-multiple span {
  vertical-align: middle;
  font-size: 14px;
  font-weight: normal;
  color: rgba(0, 0, 0, 0.65);
}

.v-select-items-multiple:hover {
  background-color: #e6f7ff;
}
</style>
