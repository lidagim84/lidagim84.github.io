<template>
  <div class="v-checkbox-group">
    <slot></slot>
    <div v-if="list.length" class="input-group">
      <v-checkbox
        v-for="(item, index) in list"
        :key="index"
        :value="item.value"
      >{{ item[labelField] }}</v-checkbox>
    </div>
  </div>
</template>

<script>
import utils from "../table/mixins/utils.js";

export default {
  name: "v-checkbox-group",
  props: {
    value: {
      type: Array,
      default() {
        return [];
      }
    },
    isSingleSelection: {
      type: Boolean,
      default: false
    },
    isVerticalShow: {
      type: Boolean,
      default: false
    },
    options: {
      type: Array,
      default() {
        return [];
      }
    },
    labelField: {
      type: String,
      default: "label"
    },
    code: {
      type: String,
      default: ""
    }
  },
  data: function() {
    return {
      list: []
    };
  },
  methods: {
    updateModel(value, checkedVal) {
      let list = [...this.value];
      if (this.isSingleSelection) {
        list = [];
      }
      let index = this.value.indexOf(value);
      if (index > -1 && !checkedVal) {
        list.splice(index, 1);
      } else if (checkedVal) {
        list.push(value);
      }
      this.$emit("input", list);
      this.$emit("change");
    }
  },
  watch: {
    value(newVal) {
      let children = utils.getChildCompsByName(this, "v-checkbox");
      if (newVal.length) {
        if (children.length > 0) {
          children.forEach(child => {
            let item = newVal.filter(val => val == child.value);
            if (item.length) {
              child.updateModelByGroup(item[0]);
            } else {
              child.model = false;
            }
          });
        }
      } else {
        if (children.length > 0) {
          children.forEach(child => {
            child.updateModelByGroup(newVal);
          });
        }
      }
    },
    options(newVal, oldVal) {
      if (newVal && newVal.length) {
        this.list = newVal;
      }
    },
    code(newVal, oldVal) {
      if (newVal) {
        this.list = this.commonCodeList(newVal);
      }
    }
  },
  created: function() {
    if (this.code) {
      this.list = this.commonCodeList(this.code);
    }
  }
};
</script>

