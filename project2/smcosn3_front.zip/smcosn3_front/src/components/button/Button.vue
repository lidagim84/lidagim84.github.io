
<template>

  <button
    type="button"
    class="btn btn-warning"
    :class="className"
    @click="$emit('btn-click', rowData)"
  ><i :class="iconClassName"></i></button>

</template>

<script>
export default {
  props: {
    rowData: {
      type: Object
    },
    className: {
      type: String,
      default: 'btn-circle'
    },
    iconClassName: {
      type: String,
      default: ''
    }
  },
  computed: {}
};
</script>
