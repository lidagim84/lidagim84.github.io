import Tree from './Tree.vue';
export default Tree;
