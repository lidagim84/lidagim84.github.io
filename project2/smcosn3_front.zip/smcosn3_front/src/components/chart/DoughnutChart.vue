<script>
import { Doughnut } from 'vue-chartjs';

export default {
  extends: Doughnut,
  props: {
    chartdata: {
      type: Object,
      default: () => {
        return {
          labels: [],
          datasets: [
            {
              backgroundColor: [],
              data: []
            }
          ]
        };
      },
      required: true
    },
    options: {
      type: Object,
      default: () => {
        return { responsive: true, maintainAspectRatio: false };
      }
    }
  },
  watch: {
    chartdata(newVal) {
      if (newVal.datasets[0].data.length) {
        this.renderChart(newVal, this.options);
      }
    }
  },
  mounted() {
    if (this.chartdata.datasets[0].data.length) {
      this.renderChart(this.chartdata, this.options);
    }
  }
};
</script>
