<script>
import { Line } from 'vue-chartjs';

export default {
  extends: Line,
  props: {
    chartdata: {
      type: Object,
      default: () => {
        return {
          labels: [],
          datasets: [
            {
              backgroundColor: [],
              data: []
            }
          ]
        };
      },
      required: true
    },
    options: {
      type: Object,
      default: () => {
        return { responsive: true, maintainAspectRatio: false };
      }
    }
  },
  mounted() {
    if (this.chartdata) {
      this.renderChart(this.chartdata, this.options);
    }
  }
};
</script>
