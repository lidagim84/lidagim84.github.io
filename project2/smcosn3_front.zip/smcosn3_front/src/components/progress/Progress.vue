<template>
  <div class="progress progress-xl">
    <div
      class="progress-bar progress-stat-2"
      role="progressbar"
      :style="{width: '30%'}"
      :aria-valuenow="30"
      aria-valuemin="0"
      aria-valuemax="100"
    >접수대기</div>
  </div>
</template>

<script>
export default {
  name: "table-progress",
  props: {
    rowData: {
      type: Object,
      default: {}
    }
  },
  data() {
    return {};
  },
  methods: {},
  created() {}
};
</script>

<style>
</style>                      