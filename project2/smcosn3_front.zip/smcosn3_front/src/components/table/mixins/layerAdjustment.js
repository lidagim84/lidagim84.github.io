import Utils from './utils';

let __autoAdjustment__events__ = [];
export default {
  methods: {
    layerAdjustmentOnce: function layerAdjustmentOnce(
      layerElement,
      targetElement,
      distance
    ) {
      let viewportOffset = Utils.getViewportOffset(targetElement),
        layerElemHeight =
          typeof layerElement.getBoundingClientRect !== 'undefined'
            ? layerElement.getBoundingClientRect().height
            : layerElement.clientHeight;

      if (viewportOffset.bottom < layerElemHeight) {
        layerElement.style.top =
          viewportOffset.top - layerElemHeight - distance + 'px';
      } else {
        layerElement.style.top =
          viewportOffset.top + targetElement.clientHeight + distance + 'px';
      }
      layerElement.style.left = viewportOffset.left - 13 + 'px';
    },
    layerAdjustmentBind: function layerAdjustmentBind(
      layerElement,
      targetElement,
      distance
    ) {
      let _this = this;
      let handler = function handler(e) {
        setTimeout(function(x) {
          _this.layerAdjustmentOnce(layerElement, targetElement, distance);
        });
      };
      __autoAdjustment__events__.push(handler);
      Utils.bind(window, 'scroll', handler);
      Utils.bind(window, 'resize', handler);
    }
  },
  beforeDestroy: function beforeDestroy() {
    Utils.unbind(window, 'scroll', __autoAdjustment__events__);
    Utils.unbind(window, 'resize', __autoAdjustment__events__);
  }
};
