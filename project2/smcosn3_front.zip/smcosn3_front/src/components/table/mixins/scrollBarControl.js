import Utils from './utils';

export default {
  data: function data() {
    return {
      scrollbarWidth: 0
    };
  },

  methods: {
    controlScrollBar: function controlScrollBar() {
      if (this.hasTableFooter) {
        let body = this.$el.querySelector('.v-table-rightview .v-table-body');
        body.style.overflowX = 'hidden';
      }
    },
    setScrollbarWidth: function setScrollbarWidth() {
      this.scrollbarWidth = Utils.getScrollbarWidth();
    }
  }
};
