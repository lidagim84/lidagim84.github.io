import Settings from '../settings/settings';

export default {
  computed: {
    vTableRightBody: function vTableRightBody() {
      let result = {
        'v-table-rightview-special-border': true
      };

      result[Settings.scrollbarClass] = true;

      return result;
    },
    vTableFooter: function vTableFooter() {
      let result = {
        'v-table-rightview-special-border': true
      };

      result[Settings.scrollbarClass] = true;

      return result;
    },
    vTableBodyInner: function vTableBodyInner() {
      return {
        'v-table-body-inner-pb': !this.hasTableFooter
      };
    },
    vTableBodyCell: function vTableBodyCell() {
      return {
        'vertical-border': this.showVerticalBorder,
        'horizontal-border': this.showHorizontalBorder
      };
    }
  },

  methods: {
    vTableFiltersIcon: function vTableFiltersIcon(filters) {
      let _this = this;

      return {
        'v-icon-filter': true,
        checked: filters.some(function(x) {
          return x.selected && x.value !== _this.filterSpecialValue;
        })
      };
    }
  }
};
