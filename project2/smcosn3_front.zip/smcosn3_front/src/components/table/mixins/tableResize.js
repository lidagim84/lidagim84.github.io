import Utils from './utils';

export default {
  data: function data() {
    return {
      resizeColumns: [],
      initTotalColumnsWidth: 0,
      hasContainerWidth: false,
      containerWidthCheckTimer: null
    };
  },

  methods: {
    getResizeColumns: function getResizeColumns() {
      let result = [];

      this.internalColumns.forEach(function (item) {
        if (item.isResize) {
          result.push({ width: item.width, field: item.field });
        }
      });

      this.resizeColumns = result;
    },
    initResizeColumns: function initResizeColumns() {
      this.initTotalColumnsWidth = this.totalColumnsWidth;
      this.getResizeColumns();
    },
    containerWidthCheck: function containerWidthCheck() {
      let _this = this;
      this.containerWidthCheckTimer = setTimeout(function (x) {
        let tableContainerWidth = _this.$el.clientWidth;
        if (tableContainerWidth - _this.internalWidth > 3) {
          _this.tableResize();
        }
      });
    },
    adjustHeight: function adjustHeight(hasScrollBar) {
      if (!this.$el || this.isVerticalResize) {
        return false;
      }

      let totalColumnsHeight = this.getTotalColumnsHeight(),
        scrollbarWidth = this.scrollbarWidth;

      if (this.hasTableFooter) {
        if (hasScrollBar) {
          if (this.footerTotalHeight === this.getFooterTotalRowHeight) {
            this.footerTotalHeight += scrollbarWidth;

            if (
              !(this.height && this.height > 0) ||
              this.height > totalColumnsHeight
            ) {
              this.internalHeight += scrollbarWidth;
            }
          }
        } else if (!hasScrollBar) {
          if (this.footerTotalHeight > this.getFooterTotalRowHeight) {
            this.footerTotalHeight -= scrollbarWidth;

            if (
              !(this.height && this.height > 0) ||
              this.height > totalColumnsHeight
            ) {
              this.internalHeight -= scrollbarWidth;
            }
          }
        }
      } else if (
        !(this.height && this.height > 0) ||
        this.height > totalColumnsHeight
      ) {
        if (
          hasScrollBar &&
          this.internalHeight + 2 < totalColumnsHeight + scrollbarWidth
        ) {
          this.internalHeight += scrollbarWidth;
        } else if (!hasScrollBar) {
          this.internalHeight = this.getTotalColumnsHeight();
        }
      }
      if (!this.isVerticalResize && this.maxHeight < this.internalHeight) {
        this.internalHeight = this.maxHeight
      }
    },
    tableResize: function tableResize() {
      if (!this.isHorizontalResize && !this.isVerticalResize) {
        return false;
      }
      let totalColumnsHeight = this.getTotalColumnsHeight();
      let maxWidth = this.maxWidth;
      let maxHeight = this.height && this.height > 0 ? this.height : totalColumnsHeight;
      let minWidth = this.minWidth;
      let minHeight =
        this.minHeight > totalColumnsHeight
          ? totalColumnsHeight
          : this.minHeight;

      let view = this.$el;
      let viewOffset = Utils.getViewportOffset(view);
      let currentWidth =
        view.getBoundingClientRect !== 'undefined'
          ? view.getBoundingClientRect().width
          : view.clientWidth;
      let currentHeight =
        view.getBoundingClientRect !== 'undefined'
          ? view.getBoundingClientRect().height
          : view.clientHeight;
      let bottom = (bottom =
        window.document.documentElement.clientHeight -
        currentHeight -
        viewOffset.top -
        this.resizeGabHeight);
      let bottom2 = viewOffset.bottom2;
      let scrollbarWidth = this.scrollbarWidth;

      if (
        this.isHorizontalResize &&
        this.internalWidth &&
        this.internalWidth > 0 &&
        currentWidth > 0
      ) {
        currentWidth = currentWidth > maxWidth ? maxWidth : currentWidth;
        currentWidth = currentWidth < minWidth ? minWidth : currentWidth;

        this.internalWidth = currentWidth;
      }

      if (this.isVerticalResize && currentHeight > 0) {
        bottom -= this.verticalResizeOffset;

        currentHeight = currentHeight + bottom;
        currentHeight = currentHeight > maxHeight ? maxHeight : currentHeight;
        currentHeight = currentHeight < minHeight ? minHeight : currentHeight;

        if (currentWidth <= this.initTotalColumnsWidth && !this.isTableEmpty) {
          bottom2 -= this.verticalResizeOffset;
          let differ = bottom2 - totalColumnsHeight;
          if (bottom2 > totalColumnsHeight + scrollbarWidth) {
            currentHeight += scrollbarWidth;
          } else if (differ > 0 && differ < scrollbarWidth) {
            currentHeight += differ;
          }
        }
        this.internalHeight = currentHeight;
        this.initInternalHeight = this.internalHeight;
      }
      this.changeColumnsWidth(currentWidth);
    },
    changeColumnsWidth: function changeColumnsWidth(currentWidth) {
      let _this2 = this;

      let differ = currentWidth - this.totalColumnsWidth,
        initResizeWidths = this.initTotalColumnsWidth,
        rightViewBody = this.$el.querySelector(
          '.v-table-rightview .v-table-body'
        ),
        rightViewFooter = this.$el.querySelector(
          '.v-table-rightview .v-table-footer'
        );

      if (currentWidth <= initResizeWidths && !this.isTableEmpty) {
        if (this.hasTableFooter) {
          rightViewFooter.style.overflowX = 'scroll';
        } else {
          rightViewBody.style.overflowX = 'scroll';
        }

        this.adjustHeight(true);
      } else {
        if (this.getTotalColumnsHeight() > this.internalHeight) {
          differ -= this.scrollbarWidth;
        }

        if (this.hasTableFooter) {
          rightViewFooter.style.overflowX = 'hidden';
        } else {
          rightViewBody.style.overflowX = 'hidden';
        }

        this.adjustHeight(false);
      }

      if (this.hasFrozenColumn) {
        differ -= 1;
      }

      if (currentWidth >= initResizeWidths || differ > 0) {
        this.setColumnsWidth(differ);
      } else {
        this.columns.forEach(function (col, index) {
          if (col.isResize) {
            _this2.internalColumns[index].width = col.width;
          }
        });
      }

      this.containerWidthCheck();
    },
    setColumnsWidth: function setColumnsWidth(differ) {
      let resizeColumnsLen = this.resizeColumns.length,
        average = Math.floor(differ / resizeColumnsLen),
        totalAverage = average * resizeColumnsLen,
        leftAverage = differ - totalAverage,
        leftAverageFloor = Math.floor(leftAverage),
        averageColumnsWidthArr = new Array(resizeColumnsLen).fill(average),
        index = 0;

      for (let i = 0; i < leftAverageFloor; i++) {
        averageColumnsWidthArr[i] += 1;
      }

      averageColumnsWidthArr[resizeColumnsLen - 1] +=
        leftAverage - leftAverageFloor;

      this.internalColumns.map(function (item) {
        if (item.isResize) {
          item.width += averageColumnsWidthArr[index++];
        }
        return item;
      });
    }
  },

  // mounted: function mounted() {
  //   Utils.bind(window, 'resize', this.tableResize);
  // },
  // beforeDestroy: function beforeDestroy() {
  //   Utils.unbind(window, 'resize', this.tableResize);
  //   clearTimeout(this.containerWidthCheckTimer);
  // }
};
