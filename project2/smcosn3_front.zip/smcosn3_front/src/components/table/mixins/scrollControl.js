import Utils from './utils';

export default {
  methods: {
    body1Mousewheel: function body1Mousewheel(e) {
      let body2 = this.$el.querySelector('.v-table-rightview .v-table-body');

      let e1 = e.originalEvent || window.event || e;
      let scrollHeight = e1.wheelDelta || e1.detail * -1;
      body2.scrollTop = body2.scrollTop - scrollHeight;
    },
    bodyScrollTop: function bodyScrollTop() {
      let body1 = this.$el.querySelector('.v-table-leftview .v-table-body');
      let body2 = this.$el.querySelector('.v-table-rightview .v-table-body');

      if (body1) {
        body1.scrollTop = 0;
      }
      body2.scrollTop = 0;
    },
    body2Scroll: function body2Scroll(e) {
      let view2 = this.$el.querySelector('.v-table-rightview');
      let body1 = this.$el.querySelector('.v-table-leftview .v-table-body');
      let body2 = this.$el.querySelector('.v-table-rightview .v-table-body');

      if (body1) {
        body1.scrollTop = body2.scrollTop;
      }

      view2.querySelector('.v-table-header').scrollLeft = body2.scrollLeft;
    },
    rightViewFooterScroll: function rightViewFooterScroll() {
      let view2 = this.$el.querySelector('.v-table-rightview');

      let rightViewFooter = this.$el.querySelector(
        '.v-table-rightview .v-table-footer'
      );

      view2.querySelector('.v-table-header').scrollLeft =
        rightViewFooter.scrollLeft;
      view2.querySelector('.v-table-body').scrollLeft =
        rightViewFooter.scrollLeft;
    },
    scrollControl: function scrollControl() {
      let _this = this;

      this.unbindEvents();

      setTimeout(function(x) {
        let body1 = _this.$el.querySelector('.v-table-leftview .v-table-body');
        let body2 = _this.$el.querySelector('.v-table-rightview .v-table-body');
        let rightViewFooter = _this.$el.querySelector(
          '.v-table-rightview .v-table-footer'
        );

        Utils.bind(body1, 'mousewheel', _this.body1Mousewheel);
        Utils.bind(body2, 'scroll', _this.body2Scroll);
        Utils.bind(rightViewFooter, 'scroll', _this.rightViewFooterScroll);
      });
    },
    unbindEvents: function unbindEvents() {
      let body1 = this.$el.querySelector('.v-table-leftview .v-table-body');
      let body2 = this.$el.querySelector('.v-table-rightview .v-table-body');
      let rightViewFooter = this.$el.querySelector(
        '.v-table-rightview .v-table-footer'
      );

      Utils.unbind(body1, 'mousewheel', this.body1Mousewheel);
      Utils.unbind(body2, 'scroll', this.body2Scroll);
      Utils.unbind(rightViewFooter, 'scroll', this.rightViewFooterScroll);
    },
    scrollToTop: function scrollToTop() {
      this.bodyScrollTop();
    }
  },

  beforeDestroy: function beforeDestroy() {
    this.unbindEvents();
  }
};
