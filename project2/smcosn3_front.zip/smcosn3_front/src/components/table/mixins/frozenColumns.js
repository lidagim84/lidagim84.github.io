export default {
  computed: {
    frozenCols: function frozenCols() {
      return this.internalColumns.filter(function(x) {
        return x.isFrozen === true;
      });
    },
    noFrozenCols: function noFrozenCols() {
      return this.internalColumns.filter(function(x) {
        return x.isFrozen !== true;
      });
    },
    frozenTitleCols: function frozenTitleCols() {
      let frozenTitleCols = [],
        self = this;

      if (this.internalTitleRows.length > 0) {
        let frozenFields = this.frozenCols.map(function(x) {
          return x.field;
        });

        this.internalTitleRows.forEach(function(rows) {
          let frozenTitleRows = rows.filter(function(row) {
            if (Array.isArray(row.fields)) {
              if (
                row.fields.every(function(field) {
                  return frozenFields.indexOf(field) !== -1;
                })
              ) {
                return true;
              }
            }
          });

          if (frozenTitleRows.length > 0) {
            frozenTitleCols.push(frozenTitleRows);

            let minRowspan = self.getMinRowspan(frozenTitleRows);

            if (minRowspan && minRowspan > 0) {
              for (let i = 0; i < minRowspan; i++) {
                frozenTitleCols.push([]);
              }
            }
          }
        });
      }

      return frozenTitleCols;
    },
    noFrozenTitleCols: function noFrozenTitleCols() {
      let noFrozenTitleCols = [],
        self = this;

      if (this.internalTitleRows.length > 0) {
        let noFrozenFields = this.noFrozenCols.map(function(x) {
          return x.field;
        });

        this.internalTitleRows.forEach(function(rows) {
          let noFrozenTitleRows = rows.filter(function(row) {
            if (Array.isArray(row.fields)) {
              return row.fields.every(function(field) {
                return noFrozenFields.indexOf(field) !== -1;
              });
            }
          });

          if (noFrozenTitleRows.length > 0) {
            noFrozenTitleCols.push(noFrozenTitleRows);

            let minRowspan = self.getMinRowspan(noFrozenTitleRows);

            if (minRowspan && minRowspan > 0) {
              for (let i = 0; i < minRowspan; i++) {
                noFrozenTitleCols.push([]);
              }
            }
          }
        });
      }
      return noFrozenTitleCols;
    }
  }
};
