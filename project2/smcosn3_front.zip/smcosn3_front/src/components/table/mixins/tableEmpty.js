import Utils from './utils';

export default {
  data: function data() {
    return {
      isTableEmpty: false,
      tableEmptyHeight: 0
    };
  },
  methods: {
    tableEmpty: function tableEmpty() {
      let _this = this;
      let tableData = this.internalTableData,
        tableEmptyHeight = 0;
      if (Array.isArray(tableData) && tableData.length > 0) {
        this.isTableEmpty = false;
        return false;
      }
      this.isTableEmpty = true;
      tableEmptyHeight = this.getTotalColumnsHeight() + this.errorContentHeight;
      this.tableEmptyHeight = tableEmptyHeight;
      this.$nextTick(function(x) {
        _this.tableEmptyScroll();
      });
    },
    tableEmptyScrollEvent: function tableEmptyScrollEvent(e) {
      let headerEle = this.$el.querySelector(
          '.v-table-rightview .v-table-header'
        ),
        tableEmptyEle = this.$el.querySelector(
          '.v-table-empty .v-table-empty-scroll'
        );
      if (tableEmptyEle) {
        headerEle.scrollLeft = tableEmptyEle.scrollLeft;
      }
    },
    tableEmptyScroll: function tableEmptyScroll() {
      let tableEmptyEle = this.$el.querySelector(
        '.v-table-empty .v-table-empty-scroll'
      );
      Utils.bind(tableEmptyEle, 'scroll', this.tableEmptyScrollEvent);
    }
  },
  beforeDestroy: function beforeDestroy() {
    let tableEmptyEle = this.$el.querySelector(
      '.v-table-empty .v-table-empty-scroll'
    );
    Utils.unbind(tableEmptyEle, 'scroll', this.tableEmptyScrollEvent);
  }
};
