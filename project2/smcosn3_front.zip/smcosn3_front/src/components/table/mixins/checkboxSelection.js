export default {
  data() {
    return {
      isAllChecked: false,
      checkboxGroupModel: [],
      indeterminate: false
    };
  },
  computed: {
    disabledUnChecked() {
      let result = [];
      this.internalTableData.filter(function (item, index) {
        if (item._disabled && !item.checked) {
          result.push(index);
        }
      });
      return result;
    },
    selectionColunm() {
      let target = this.internalColumns.filter(column => column.type == 'selection');
      if (target.length)
        return target[0];
      else { };
    },
    getCheckedTableRow() {
      let _this = this;
      return this.internalTableData.filter(function (item, index) {
        item.index = index;
        let target = _this.internalColumns.filter(column => column.type == 'selection');
        if (target.length) {
          return _this.checkboxGroupModel.indexOf(item[target[0].field]) > -1;
        }
        return -1;
      });
    },
    hasSelectionColumns() {
      return this.internalColumns.some(function (x) {
        return x.type && x.type === 'selection';
      });
    }
  },
  methods: {
    isSelectionCol(fileds) {
      if (Array.isArray(fileds) && fileds.length === 1) {
        return this.internalColumns.some(function (x) {
          return x.field === fileds[0] && x.type === 'selection';
        });
      }
      return false;
    },
    disabledChecked() {
      let result = [];
      this.internalTableData.filter(function (item, index) {
        if (item._disabled && item.checked) {
          result.push(item[this.selectionColunm.field]);
        }
      });
      return result;
    },
    handleCheckAll() {
      let _this2 = this;

      if (_this2.isAllChecked == "false" || !_this2.isAllChecked) {
        _this2.isAllChecked = true;
      } else {
        _this2.isAllChecked = false;
      }
      if (_this2.isAllChecked) {
        _this2.checkboxGroupModel = [];
        for (let i = 0; i < this.internalTableData.length; i++) {
          if (_this2.disabledUnChecked.indexOf(i) === -1) {
            _this2.checkboxGroupModel.push(this.internalTableData[i][_this2.selectionColunm.field]);
          }
        }
      } else {
        _this2.checkboxGroupModel = this.disabledChecked();
      }
      // this.selectAll && this.selectAll(this.getCheckedTableRow);
      this.$nextTick(() => {
        _this2.selectChange && _this2.selectChange(_this2.getCheckedTableRow);
      });
      this.setIndeterminateState();
    },
    handleCheckChange(rowData, fieldNm) {
      let _this2 = this;
      this.$nextTick(() => {
        _this2.selectChange &&
          _this2.selectChange(_this2.getCheckedTableRow, rowData);
      });
    },
    handleCheckGroupChange() {
      this.selectGroupChange && this.selectGroupChange(this.getCheckedTableRow);
      this.setCheckState();
    },
    setIndeterminateState() {
      let checkedLen = this.checkboxGroupModel.length,
        allLen = this.internalTableData.length;
      if (checkedLen > 0 && checkedLen === allLen) {
        this.indeterminate = false;
      } else if (checkedLen > 0 && checkedLen < allLen) {
        this.indeterminate = true;
      } else {
        this.indeterminate = false;
      }
    },
    setCheckState() {
      let checkedLen = this.checkboxGroupModel.length,
        allLen = this.internalTableData.length;
      if (checkedLen > 0 && checkedLen === allLen) {
        this.indeterminate = false;
        this.isAllChecked = true;
      } else if (checkedLen > 0 && checkedLen < allLen) {
        this.isAllChecked = false;
        this.indeterminate = true;
      } else {
        this.indeterminate = false;
        this.isAllChecked = false;
      }
    },
    updateCheckboxGroupModel() {
      let _this3 = this;
      if (!this.hasSelectionColumns) {
        return false;
      }
      this.checkboxGroupModel = [];
      this.internalTableData.filter((item, index) => {
        if (item.checked) {
          this.checkboxGroupModel.push(item[_this3.selectionColunm.field]);
        }
      });
      this.setCheckState();
    }
  }
};
