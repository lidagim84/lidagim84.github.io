<template>
  <div
    class="v-table-views v-table-class"
    :style="{'width': internalWidth+'px', 'height': getTableHeight+'px','background-color':tableBgColor}"
    v-resize="tableResize"
  >
    <!--左列-->
    <template v-if="frozenCols.length > 0">
      <div class="v-table-leftview" :style="{'width':leftViewWidth+'px'}">
        <div
          class="v-table-header v-table-title-class"
          :style="{'width': leftViewWidth+'px','background-color':titleBgColor}"
        >
          <div class="v-table-header-inner" style="display: block;">
            <table class="v-table-htable" border="0" cellspacing="0" cellpadding="0">
              <tbody>
                <template v-if="frozenTitleCols.length > 0">
                  <tr v-for="(row, r_index) in frozenTitleCols" :key="r_index">
                    <td
                      v-for="(col, c_index) in row"
                      :class="[col.titleCellClassName]"
                      :colspan="col.colspan"
                      :rowspan="col.rowspan"
                      :key="c_index"
                      @mousemove.stop="handleTitleMouseMove($event,col.fields)"
                      @mousedown.stop="handleTitleMouseDown($event)"
                      @mouseout.stop="handleTitleMouseOut()"
                      @click.stop="titleCellClick(col.fields,col.title);"
                      @dblclick.stop="titleCellDblClick(col.fields,col.title)"
                    >
                      <div
                        :class="['v-table-title-cell',showVerticalBorder?'vertical-border':'',showHorizontalBorder?'horizontal-border':'']"
                        :style="{'width':titleColumnWidth(col.fields)+'px','height':titleColumnHeight(col.rowspan)+'px','text-align':col.titleAlign}"
                      >
                        <span class="table-title">
                          <span v-if="!isSingleSelection && isSelectionCol(col.fields)">
                            <v-checkbox @change="handleCheckAll" v-model="isAllChecked"></v-checkbox>
                          </span>
                          <span v-else v-html="col.title"></span>
                          <span
                            @click.stop="sortControl(col.fields[0])"
                            class="v-table-sort-icon"
                            v-if="enableSort(col.orderBy)"
                          >
                            <i
                              :class="["v-icon-up-dir",getCurrentSort(col.fields[0]) ==="asc" ? "checked":""]"
                            ></i>
                            <i
                              :class="["v-icon-down-dir",getCurrentSort(col.fields[0]) ==="desc" ? "checked":""]"
                            ></i>
                          </span>
                        </span>
                        <!--filters-->
                        <v-dropdown
                          class="v-table-dropdown"
                          v-if="enableFilters(col.filters,col.fields)"
                          v-model="col.filters"
                          :show-operation="col.filterMultiple"
                          :is-multiple="col.filterMultiple"
                          @on-filter-method="filterEvent"
                          @change="filterConditionChange(col.filterMultiple)"
                        >
                          <i :class="['v-table-filter-icon',vTableFiltersIcon(col.filters)]"></i>
                        </v-dropdown>
                      </div>
                    </td>
                  </tr>
                </template>

                <template v-else>
                  <tr class="v-table-header-row">
                    <td
                      v-for="(col, c_index) in frozenCols"
                      :key="c_index"
                      :class="[col.titleCellClassName]"
                      @mousemove.stop="handleTitleMouseMove($event,col.field)"
                      @mousedown.stop="handleTitleMouseDown($event)"
                      @mouseout.stop="handleTitleMouseOut()"
                      @click.stop="titleCellClick(col.field,col.title);"
                      @dblclick.stop="titleCellDblClick(col.field,col.title)"
                    >
                      <div
                        :class="['v-table-title-cell',showVerticalBorder?'vertical-border':'',showHorizontalBorder?'horizontal-border':'']"
                        :style="{'width':col.width+'px','height':titleRowHeight+'px','text-align':col.titleAlign}"
                      >
                        <span class="table-title">
                          <span v-if="!isSingleSelection && col.type === 'selection'">
                            <v-checkbox @change="handleCheckAll" v-model="isAllChecked"></v-checkbox>
                          </span>
                          <span v-else v-html="col.title"></span>
                          <span
                            @click.stop="sortControl(col.field)"
                            class="v-table-sort-icon"
                            v-if="enableSort(col.orderBy)"
                          >
                            <i
                              :class="["v-icon-up-dir",getCurrentSort(col.field) ==="asc" ? "checked":""]"
                            ></i>
                            <i
                              :class="["v-icon-down-dir",getCurrentSort(col.field) ==="desc" ? "checked":""]"
                            ></i>
                          </span>
                        </span>
                        <!--filters-->
                        <v-dropdown
                          class="v-table-dropdown"
                          v-if="enableFilters(col.filters)"
                          v-model="col.filters"
                          :show-operation="col.filterMultiple"
                          :is-multiple="col.filterMultiple"
                          @on-filter-method="filterEvent"
                          @change="filterConditionChange(col.filterMultiple)"
                        >
                          <i :class="['v-table-filter-icon',vTableFiltersIcon(col.filters)]"></i>
                        </v-dropdown>
                      </div>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </div>
        <div
          class="v-table-body v-table-body-class"
          :style="{'width': leftViewWidth+'px', 'height': bodyViewHeight+'px'}"
        >
          <div :class="['v-table-body-inner',vTableBodyInner]">
            <v-checkbox-group
              :isSingleSelection="isSingleSelection"
              v-model="checkboxGroupModel"
              @change="handleCheckGroupChange"
            >
              <table class="v-table-btable" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr
                    v-for="(item,rowIndex) in internalTableData"
                    :key="rowIndex"
                    class="v-table-row"
                    :style="[trBgColor(rowIndex+1)]"
                    @mouseenter.stop="handleMouseEnter(rowIndex)"
                    @mouseleave.stop="handleMouseOut(rowIndex)"
                  >
                    <td
                      v-show="cellMergeInit(rowIndex,col.field,item,true)"
                      v-for="(col,colIndex) in frozenCols"
                      :key="colIndex"
                      :colSpan="setColRowSpan(rowIndex,col.field,item).colSpan"
                      :rowSpan="setColRowSpan(rowIndex,col.field,item).rowSpan"
                      :class="[setColumnCellClassName(rowIndex,col.field,item)]"
                    >
                      <div
                        v-if="isCellMergeRender(rowIndex,col.field,item)"
                        :class="['v-table-body-cell',showVerticalBorder ? 'vertical-border':'',showHorizontalBorder?'horizontal-border':'']"
                        :style="{'width':getRowWidthByColSpan(rowIndex,col.field,item)+'px','height': getRowHeightByRowSpan(rowIndex,col.field,item)+'px','line-height':getRowHeightByRowSpan(rowIndex,col.field,item)+'px','text-align':col.columnAlign}"
                        :title="col.overflowTitle ?  overflowTitle(item,rowIndex,col) :''"
                        @click.stop="rowCellClick(rowIndex,item,col);cellEditClick($event,col.isEdit,item,col.field,rowIndex)"
                        @dblclick.stop="rowCellDbClick(rowIndex,item,col)"
                      >
                        <span v-if="cellMergeContentType(rowIndex,col.field,item).isComponent">
                          <component
                            :rowData="item"
                            :field="col.field ? col.field : ''"
                            :index="rowIndex"
                            :is="cellMerge(rowIndex,item,col.field).componentName"
                            @on-custom-comp="customCompFunc"
                          ></component>
                        </span>
                        <span v-else v-html="cellMerge(rowIndex,item,col.field).content"></span>
                      </div>
                      <div
                        v-else
                        :class="['v-table-body-cell',showVerticalBorder ? 'vertical-border':'',showHorizontalBorder?'horizontal-border':'']"
                        :style="{'width':col.width+'px','height': rowHeight+'px','line-height':rowHeight+'px','text-align':col.columnAlign}"
                        :title="col.overflowTitle ?  overflowTitle(item,rowIndex,col) :''"
                        @click.stop="rowCellClick(rowIndex,item,col);cellEditClick($event,col.isEdit,item,col.field,rowIndex)"
                        @dblclick.stop="rowCellDbClick(rowIndex,item,col)"
                      >
                        <span
                          v-if="typeof col.componentName ==='string' && col.componentName.length > 0"
                        >
                          <component
                            :rowData="item"
                            :field="col.field ? col.field : ''"
                            :index="rowIndex"
                            :is="col.componentName"
                            @on-custom-comp="customCompFunc"
                          ></component>
                        </span>
                        <span
                          v-else-if="typeof col.formatter==='function'"
                          v-html="col.formatter(item,rowIndex,pagingIndex,col.field)"
                        ></span>
                        <span v-else-if="col.type === 'selection'">
                          <v-checkbox
                            @change="handleCheckChange(item)"
                            :show-slot="false"
                            :disabled="item.disabled"
                            :label="rowIndex"
                            :value="item[col.field]"
                          ></v-checkbox>
                        </span>
                        <span class="v-label" v-else>{{item[col.field]}}</span>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </v-checkbox-group>
          </div>
        </div>

        <!--footer-->
        <div
          v-if="frozenFooterCols.length > 0"
          :class="['v-table-footer','v-table-footer-class']"
          :style="{'width': leftViewWidth+'px','height':footerTotalHeight}"
        >
          <table class="v-table-ftable" cellspacing="0" cellpadding="0" border="0">
            <tr class="v-table-row" v-for="(item,rowIndex) in frozenFooterCols" :key="rowIndex">
              <td
                v-for="(col,colIndex) in item"
                :key="colIndex"
                :class="setFooterCellClassName(true,rowIndex,colIndex,col.content)"
              >
                <div
                  :style="{'height':footerRowHeight+'px','line-height':footerRowHeight+'px','width':col.width+'px','text-align':col.align}"
                  :class="['v-table-body-cell',vTableBodyCell]"
                  v-html="col.content"
                ></div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </template>
    <div class="v-table-rightview" :style="{'width': rightViewWidth+'px'}">
      <div
        class="v-table-header v-table-title-class"
        :style="{'width': (rightViewWidth-1)+'px','background-color':titleBgColor}"
      >
        <div class="v-table-header-inner" style="display: block;">
          <table class="v-table-htable" border="0" cellspacing="0" cellpadding="0">
            <tbody>
              <template v-if="noFrozenTitleCols.length > 0">
                <tr v-for="(row, r_index) in noFrozenTitleCols" :key="r_index">
                  <td
                    v-for="(col, c_index) in row"
                    :key="c_index"
                    :class="[col.titleCellClassName]"
                    :colspan="col.colspan"
                    :rowspan="col.rowspan"
                    @mousemove.stop="handleTitleMouseMove($event,col.fields)"
                    @mousedown.stop="handleTitleMouseDown($event)"
                    @mouseout.stop="handleTitleMouseOut()"
                    @click.stop="titleCellClick(col.fields,col.title);"
                    @dblclick.stop="titleCellDblClick(col.fields,col.title)"
                  >
                    <div
                      :class="['v-table-title-cell',showVerticalBorder?'vertical-border':'',showHorizontalBorder?'horizontal-border':'']"
                      :style="{'width':titleColumnWidth(col.fields)+'px','height':titleColumnHeight(col.rowspan)+'px','text-align':col.titleAlign}"
                    >
                      <span class="table-title">
                        <span v-if="isSelectionCol(col.fields)">
                          <v-checkbox @change="handleCheckAll" v-model="isAllChecked"></v-checkbox>
                        </span>
                        <span v-else v-html="col.title"></span>
                        <span
                          @click.stop="sortControl(col.fields[0])"
                          class="v-table-sort-icon"
                          v-if="enableSort(col.orderBy)"
                        >
                          <i
                            :class="["v-icon-up-dir",getCurrentSort(col.fields[0]) ==="asc" ? "checked":""]"
                          ></i>
                          <i
                            :class="["v-icon-down-dir",getCurrentSort(col.fields[0]) ==="desc" ? "checked":""]"
                          ></i>
                        </span>
                      </span>
                      <!--filters-->
                      <v-dropdown
                        class="v-table-dropdown"
                        v-if="enableFilters(col.filters,col.fields)"
                        v-model="col.filters"
                        :show-operation="col.filterMultiple"
                        :is-multiple="col.filterMultiple"
                        @on-filter-method="filterEvent"
                        @change="filterConditionChange(col.filterMultiple)"
                      >
                        <i :class="['v-table-filter-icon',vTableFiltersIcon(col.filters)]"></i>
                      </v-dropdown>
                    </div>
                  </td>
                </tr>
              </template>

              <template v-else>
                <tr class="v-table-header-row">
                  <td
                    v-for="(col,colIndex) in noFrozenCols"
                    :key="colIndex"
                    :class="[col.titleCellClassName]"
                    @mousemove.stop="handleTitleMouseMove($event,col.field)"
                    @mousedown.stop="handleTitleMouseDown($event)"
                    @mouseout.stop="handleTitleMouseOut()"
                    @click.stop="titleCellClick(col.field,col.title);"
                    @dblclick.stop="titleCellDblClick(col.field,col.title)"
                  >
                    <div
                      :class="['v-table-title-cell',showVerticalBorder?'vertical-border':'',showHorizontalBorder?'horizontal-border':'']"
                      :style="{'width':col.width+'px','height':titleRowHeight+'px','text-align':col.titleAlign}"
                    >
                      <span class="table-title">
                        <span v-if="col.type === 'selection'">
                          <v-checkbox @change="handleCheckAll" v-model="isAllChecked"></v-checkbox>
                        </span>
                        <span v-else v-html="col.title"></span>
                        <span
                          @click.stop="sortControl(col.field)"
                          class="v-table-sort-icon"
                          v-if="enableSort(col.orderBy)"
                        >
                          <i
                            :class="["v-icon-up-dir",getCurrentSort(col.field) ==="asc" ? "checked":""]"
                          ></i>
                          <i
                            :class="["v-icon-down-dir",getCurrentSort(col.field) ==="desc" ? "checked":""]"
                          ></i>
                        </span>
                        <!--filters-->
                        <v-dropdown
                          class="v-table-dropdown"
                          v-if="enableFilters(col.filters)"
                          v-model="col.filters"
                          :show-operation="col.filterMultiple"
                          :is-multiple="col.filterMultiple"
                          @on-filter-method="filterEvent"
                          @change="filterConditionChange(col.filterMultiple)"
                        >
                          <i :class="['v-table-filter-icon',vTableFiltersIcon(col.filters)]"></i>
                        </v-dropdown>
                      </span>
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
      <div
        :class="['v-table-body v-table-body-class',vTableRightBody]"
        :style="{'width': rightViewWidth+'px', 'height': bodyViewHeight+'px'}"
      >
        <v-checkbox-group v-model="checkboxGroupModel" @change="handleCheckGroupChange">
          <table class="v-table-btable" cellspacing="0" cellpadding="0" border="0">
            <tbody>
              <tr
                :key="rowIndex"
                v-for="(item,rowIndex) in internalTableData"
                class="v-table-row"
                :style="[trBgColor(rowIndex+1), trBgColorByRowData(item)]"
                @mouseenter.stop="handleMouseEnter(rowIndex)"
                @mouseleave.stop="handleMouseOut(rowIndex)"
              >
                <td
                  v-show="cellMergeInit(rowIndex,col.field,item,false)"
                  v-for="(col,colIndex) in noFrozenCols"
                  :key="colIndex"
                  :colSpan="setColRowSpan(rowIndex,col.field,item).colSpan"
                  :rowSpan="setColRowSpan(rowIndex,col.field,item).rowSpan"
                  :class="[setColumnCellClassName(rowIndex,col.field,item)]"
                >
                  <datepicker
                    v-if="col.type === 'datePicker'"
                    inputClass="form-control"
                    :style="{width:col.width+'px'}"
                    name="start_dt"
                    :disabledDates="item.disabledDates"
                    :calendarButton="false"
                    v-model="item[col.field]"
                    @input="(val)=> {
                      cellEditDone(val, item[col.field], rowIndex, item, col.field)
                    }"
                    @setInitialView="(val)=> {
                      let gab = 180 + (rowIndex + 2) * 40 - internalHeight;
                      if(gab > 0) {                        
                        internalHeight += gab;
                      }
                      }"
                    @closed="(val)=> {
                      internalHeight = initInternalHeight;
                      }"
                  ></datepicker>
                  <div
                    v-if="isCellMergeRender(rowIndex,col.field,item)"
                    :class="['v-table-body-cell',showVerticalBorder ? 'vertical-border':'',showHorizontalBorder?'horizontal-border':'']"
                    :style="{'width':getRowWidthByColSpan(rowIndex,col.field,item)+'px','height': getRowHeightByRowSpan(rowIndex,col.field,item)+'px','line-height':getRowHeightByRowSpan(rowIndex,col.field,item)+'px','text-align':col.columnAlign}"
                    :title="col.overflowTitle ?  overflowTitle(item,rowIndex,col) :''"
                    @click.stop="rowCellClick(rowIndex,item,col);cellEditClick($event,col.isEdit,item,col.field,rowIndex)"
                    @dblclick.stop="rowCellDbClick(rowIndex,item,col)"
                  >
                    <span v-if="cellMergeContentType(rowIndex,col.field,item).isComponent">
                      <component
                        :rowData="item"
                        :field="col.field ? col.field : ''"
                        :index="rowIndex"
                        :is="cellMerge(rowIndex,item,col.field).componentName"
                        @on-custom-comp="customCompFunc"
                      ></component>
                    </span>
                    <span v-else v-html="cellMerge(rowIndex,item,col.field).content"></span>
                  </div>
                  <div
                    v-else
                    :class="['v-table-body-cell',showVerticalBorder ? 'vertical-border':'', showHorizontalBorder?'horizontal-border':'' , showCursor ? 'cursor': '']"
                    :style="{'width':col.width+'px','height': col.type === 'datePicker' ? '0px' : rowHeight+'px','line-height':rowHeight+'px','text-align':col.columnAlign}"
                    :title="col.overflowTitle ?  overflowTitle(item,rowIndex,col) :''"
                    @click.stop="rowCellClick(rowIndex,item,col);cellEditClick($event,col.isEdit,item,col.field,rowIndex)"
                    @dblclick.stop="rowCellDbClick(rowIndex,item,col)"
                  >
                    <span
                      v-if="typeof col.componentName ==='string' && col.componentName.length > 0"
                    >
                      <component
                        :rowData="item"
                        :field="col.field ? col.field : ''"
                        :index="rowIndex"
                        :is="col.componentName"
                        @btn-click="col.btnClickFunc"
                        :iconClassName="col.iconClassName"
                      ></component>
                    </span>
                    <span
                      v-else-if="typeof col.formatter==='function'"
                      v-html="col.formatter(item,rowIndex,pagingIndex,col.field)"
                    ></span>
                    <span v-else-if="col.type === 'selection'">
                      <v-checkbox
                        @change="handleCheckChange(item)"
                        :show-slot="false"
                        :disabled="item.disabled"
                         :label="rowIndex"
                        :value="item[col.field]"
                      ></v-checkbox>
                    </span>
                    <span
                      v-else-if="col.type == 'code' && !col.codeDiv"
                    >{{item[col.field] | code(col.field)}}</span>
                    <span
                      v-else-if="col.type == 'code' && col.codeDiv"
                    >{{item[col.field] | code(col.codeDiv)}}</span>
                    <span
                      v-else-if="col.type == 'date'"
                    >{{item[col.field] | dspDate('YYYYMMDD', 'YYYY-MM-DD')}}</span>
                    <span v-else-if="col.type == 'datetime'">{{item[col.field] | datetime }}</span>
                    <span class="v-label" v-else>{{item[col.field]}}</span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </v-checkbox-group>
      </div>

      <!--footer-->
      <div
        v-if="noFrozenFooterCols.length > 0"
        :class="['v-table-footer','v-table-footer-class',vTableFooter]"
        :style="{'width': rightViewWidth+'px','height':footerTotalHeight}"
      >
        <table class="v-table-ftable" cellspacing="0" cellpadding="0" border="0">
          <tr class="v-table-row" v-for="(item,rowIndex) in noFrozenFooterCols" :key="rowIndex">
            <td
              v-for="(col,colIndex) in item"
              :class="setFooterCellClassName(false,rowIndex,colIndex,col.content)"
              :key="colIndex"
            >
              <div
                :style="{'height':footerRowHeight+'px','line-height':footerRowHeight+'px','width':col.width+'px','text-align':col.align}"
                :class="['v-table-body-cell',vTableBodyCell]"
                v-html="col.content"
              ></div>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <table-empty
      v-if="isTableEmpty"
      :width="internalWidth"
      :total-columns-width="totalColumnsWidth"
      :content-height="200"
      :title-height="getTotalColumnsHeight()"
      :error-content="errorContent"
      :is-loading="isLoading"
    ></table-empty>
    <loading
      v-if="isLoading"
      :loading-content="loadingContent"
      :title-rows="internalTitleRows"
      :title-row-height="titleRowHeight"
      :columns="internalColumns"
      :loading-opacity="loadingOpacity"
    ></loading>
    <div v-show="isDragging" class="v-table-drag-line"></div>
  </div>
</template>

<script>
import classesMixin from "./mixins/classes.js";
import scrollControlMixin from "./mixins/scrollControl.js";
import frozenColumnsMixin from "./mixins/frozenColumns.js";
import tableResizeMixin from "./mixins/tableResize.js";
import sortControlMixin from "./mixins/sortControl.js";
import tableEmptyMixin from "./mixins/tableEmpty.js";
import dragWidthMixin from "./mixins/dragWidth.js";
import cellEditMixin from "./mixins/cellEdit.js";
import bodyCellMergeMixin from "./mixins/bodyCellMerge.js";
import titleCellMergeMixin from "./mixins/titleCellMerge.js";
import checkboxSelectionMixin from "./mixins/checkboxSelection.js";
import tableFooterMixin from "./mixins/tableFooter.js";
import scrollBarControlMixin from "./mixins/scrollBarControl.js";
import tableRowMouseEventsMixin from "./mixins/tableRowMouseEvents";
import tableFiltersMixin from "./mixins/tableFilters";

import utils from "./mixins/utils.js";
import deepClone from "./mixins/deepClone.js";

import tableEmpty from "./TableEmpty.vue";
import loading from "./Loading.vue";
import { VCheckbox, VCheckboxGroup } from "../checkbox";
import Datepicker from "../datepicker/Datepicker";

export default {
  name: "v-table",
  mixins: [
    classesMixin,
    tableResizeMixin,
    frozenColumnsMixin,
    scrollControlMixin,
    sortControlMixin,
    tableEmptyMixin,
    dragWidthMixin,
    cellEditMixin,
    bodyCellMergeMixin,
    titleCellMergeMixin,
    checkboxSelectionMixin,
    tableFooterMixin,
    scrollBarControlMixin,
    tableRowMouseEventsMixin,
    tableFiltersMixin,
    Datepicker
  ],
  components: { tableEmpty, loading, VCheckbox, VCheckboxGroup },
  filters: {
    //'dspDate' : (value, inFormat='YYYYMMDD', outFormat='YYYY-MM-DD') => moment(value, inFormat).format(outFormat)
  },
  data() {
    return {
      internalTableData: [],
      internalWidth: 0,
      internalHeight: 0,
      initInternalHeight: 0,
      internalColumns: [],
      internalTitleRows: [],
      errorMsg: " V-Table error: ",
      maxWidth: 5000,
      hasFrozenColumn: false,
      resizeTimer: null,
      isAllChecked: false
    };
  },
  props: {
    width: [Number, String],
    minWidth: {
      type: Number,
      default: 50
    },
    height: {
      type: Number,
      default: 0,
      require: false
    },
    minHeight: {
      type: Number,
      default: 53
    },
    maxHeight: {
      type: Number,
      default: 200
    },
    titleRowHeight: {
      type: Number,
      default: 52
    },
    isHorizontalResize: {
      type: Boolean,
      default: false
    },
    isVerticalResize: {
      type: Boolean,
      default: false
    },
    verticalResizeOffset: {
      type: Number,
      default: 0
    },
    tableBgColor: {
      type: String,
      default: "#fff"
    },
    titleBgColor: {
      type: String,
      default: "#fff"
    },
    oddBgColor: {
      type: String,
      default: ""
    },
    evenBgColor: {
      type: String,
      default: ""
    },
    rowHeight: {
      type: Number,
      default: 53
    },
    multipleSort: {
      type: Boolean,
      default: true
    },
    sortAlways: {
      type: Boolean,
      default: false
    },
    columns: {
      type: Array,
      require: true
    },
    titleRows: {
      type: Array,
      require: true,
      default: function() {
        return [];
      }
    },
    tableData: {
      type: Array,
      require: true,
      default: function() {
        return [];
      }
    },
    pagingIndex: Number,
    errorContent: {
      type: String,
      default: ""
    },
    errorContentHeight: {
      type: Number,
      default: 53
    },
    isLoading: {
      type: Boolean,
      default: false
    },
    loadingContent: {
      type: String,
      default:
        '<span><i class="v-icon-spin5 animate-loading-23" style="font-size: 28px;opacity:0.6;"></i></span>'
    },
    rowHoverColor: {
      type: String
    },
    rowClickColor: {
      type: String
    },
    showVerticalBorder: {
      type: Boolean,
      default: true
    },
    showHorizontalBorder: {
      type: Boolean,
      default: true
    },
    footer: {
      type: Array,
      default: function() {
        return [];
      }
    },
    footerRowHeight: {
      type: Number,
      default: 40
    },
    columnWidthDrag: {
      type: Boolean,
      default: false
    },
    loadingOpacity: {
      type: Number,
      default: 0.6
    },
    isSingleSelection: {
      type: Boolean,
      default: false
    },
    resizeGabHeight: {
      type: Number,
      default: 100
    },
    columnCellClassName: Function,
    footerCellClassName: Function,
    rowClick: Function,
    rowDblclick: Function,
    titleClick: Function,
    titleDblclick: Function,
    rowMouseEnter: Function,
    rowMouseLeave: Function,
    cellEditDone: Function,
    cellMerge: Function,
    selectAll: Function,
    selectChange: Function,
    selectGroupChange: Function,
    filterMethod: Function
  },
  computed: {
    showCursor() {
      if (this.rowClick || this.rowDblclick || this.rowMouseEnter) return true;
      return false;
    },
    isComplexTitle() {
      return (
        Array.isArray(this.internalTitleRows) &&
        this.internalTitleRows.length > 0
      );
    },
    getTableHeight() {
      return this.isTableEmpty ? this.tableEmptyHeight : this.internalHeight;
    },
    leftViewWidth() {
      let result = 0;
      if (this.hasFrozenColumn) {
        result = this.frozenCols.reduce((total, curr) => total + curr.width, 0);
      }
      return result;
    },
    rightViewWidth() {
      let result = this.internalWidth - this.leftViewWidth;
      return this.hasFrozenColumn ? result - 2 : result;
    },
    bodyViewHeight() {
      let result;
      if (this.internalTitleRows.length > 0) {
        result =
          this.internalHeight -
          this.titleRowHeight *
            (this.internalTitleRows.length + this.getTitleRowspanTotalCount);
      } else {
        result = this.internalHeight - this.titleRowHeight;
      }
      result -= this.footerTotalHeight + 1;
      return result;
    },
    totalColumnsWidth() {
      return this.internalColumns.reduce(function(total, curr) {
        return curr.width ? total + curr.width : total;
      }, 0);
    },
    totalNoFrozenColumnsWidth() {
      return this.noFrozenCols.reduce(function(total, curr) {
        return curr.width ? total + curr.width : total;
      }, 0);
    },
    getColumnsFields() {
      return this.internalColumns.map(item => {
        return item.field;
      });
    },
    getNoFrozenColumnsFields() {
      return this.internalColumns
        .filter(x => !x.isFrozen)
        .map(item => {
          return item.field;
        });
    },
    getFrozenColumnsFields() {
      return this.internalColumns
        .filter(x => x.isFrozen)
        .map(item => {
          return item.field;
        });
    }
  },
  watch: {
    columns: {
      handler: function(newVal) {
        this.initColumns();
        // fix issue #261
        this.tableResize();
      },
      deep: true
    },
    titleRows: {
      handler: function(newVal) {
        this.initColumns();
      },
      deep: true
    },
    tableData: {
      handler: function(newVal) {
        this.internalTableData = this.initInternalTableData(newVal);
        this.skipRenderCells = [];
        this.setScrollbarWidth();
        this.updateCheckboxGroupModel();
        this.tableEmpty();
        if (this.internalTableData.length) {
          this.initView();
          this.scrollControl();
        }
        this.resize(0);
      },
      deep: true
    },
    pagingIndex: {
      handler: function() {
        this.clearCurrentRow();
        this.bodyScrollTop();
      }
    }
  },
  methods: {
    customCompFunc(params) {
      this.$emit("on-custom-comp", params);
    },
    trBgColor(num) {
      if (
        (this.evenBgColor && this.evenBgColor.length > 0) ||
        (this.oddBgColor && this.oddBgColor.length > 0)
      ) {
        return num % 2 === 0
          ? { "background-color": this.evenBgColor }
          : { "background-color": this.oddBgColor };
      }
    },
    trBgColorByRowData(rowData) {
      if (rowData.color) {
        return { "background-color": rowData.color };
      }
    },
    setColumnCellClassName(rowIndex, field, rowData) {
      return (
        this.columnCellClassName &&
        this.columnCellClassName(rowIndex, field, rowData)
      );
    },
    titleColumnWidth(fields) {
      let result = 0;
      if (Array.isArray(fields)) {
        let matchItems = this.internalColumns.filter(item => {
          return fields.some(x => x === item.field);
        });

        result = matchItems.reduce((total, curr) => total + curr.width, 0);
      } else {
        console.error(
          this.errorMsg + "the fields attribute must be a array in titleRows"
        );
      }
      return result;
    },
    titleColumnHeight(rowspan) {
      if (rowspan && rowspan > 0) {
        return this.titleRowHeight * rowspan;
      } else {
        return this.titleRowHeight;
      }
    },
    overflowTitle(row, rowIndex, col) {
      let result = "";
      if (typeof col.formatter === "function") {
        let val = col.formatter(row, rowIndex, this.pagingIndex, col.field);
        if (utils.isHtml(val)) {
          result = "";
        } else {
          result = val;
        }
      } else {
        result = row[col.field];
      }
      return result;
    },
    getTotalColumnsHeight() {
      let titleTotalHeight =
        this.internalTitleRows && this.internalTitleRows.length > 0
          ? this.titleRowHeight * this.internalTitleRows.length
          : this.titleRowHeight;
      titleTotalHeight += this.footerTotalHeight;
      return (
        titleTotalHeight + this.internalTableData.length * this.rowHeight + 1
      );
    },
    initTableWidth() {
      this.internalWidth = this.isHorizontalResize ? this.maxWidth : this.width;
    },
    initColumns() {
      if (this.maxHeight > this.height) {
        this.internalHeight = this.height;
      } else {
        this.internalHeight = this.maxHeight;
      }
      this.footerTotalHeight = this.getFooterTotalRowHeight;
      this.internalColumns = Array.isArray(this.columns)
        ? deepClone(this.columns)
        : [];
      this.internalTitleRows = Array.isArray(this.titleRows)
        ? deepClone(this.titleRows)
        : [];
      this.initColumnsFilters();
      this.initResizeColumns();
      this.hasFrozenColumn = this.internalColumns.some(x => x.isFrozen);
      this.initTableWidth();
      this.setSortColumns();

      let self = this,
        widthCountCheck = 0;

      if (self.internalWidth && self.internalWidth > 0) {
        self.internalColumns.map(function(item) {
          if (!(item.width && item.width > 0)) {
            widthCountCheck++;
            if (self.isHorizontalResize) {
              console.error(
                self.errorMsg +
                  "If you are using the isHorizontalResize property,Please set the value for each column's width"
              );
            } else {
              item.width = self.internalWidth - self.totalColumnsWidth;
            }
          }
        });
      }

      if (widthCountCheck > 1) {
        console.error(this.errorMsg + "Only allow one column is not set width");
      }
    },
    initView() {
      if (!(this.internalWidth && this.internalWidth > 0)) {
        if (this.columns && this.columns.length > 0) {
          this.internalWidth = this.columns.reduce(
            (total, curr) => total + curr.width,
            0
          );
        }
      }
      let totalColumnsHeight = this.getTotalColumnsHeight();
      if (this.isVerticalResize) {
        this.internalHeight = totalColumnsHeight;
      } else {
        if (this.maxHeight > this.height) {
          this.internalHeight = this.height;
        } else {
          this.internalHeight = this.maxHeight;
        }
      }
      this.initInternalHeight = this.internalHeight;
    },

    initInternalTableData() {
      return Array.isArray(this.tableData) ? deepClone(this.tableData) : [];
    },
    resize(time = 1000) {
      // fixed bug in IE9 #17
      this.resizeTimer = setTimeout(x => {
        this.tableResize();
      }, time);
    }
  },
  created() {
    this.internalTableData = this.initInternalTableData(this.tableData);
    if (this.columns.length) {
      this.initColumns();
    }
    this.initView();
  },
  mounted() {
    this.setScrollbarWidth();
    this.tableEmpty();
    this.tableResize();
    if (this.internalTableData.length) {
      this.scrollControl();
    }
    this.controlScrollBar();
  },
  beforeDestroy() {
    clearTimeout(this.resizeTimer);
  }
};
</script>

<style>
.table-striped tbody tr:nth-of-type(odd) {
  background-color: rgba(0, 0, 0, 0.05) !important;
}

.v-table-views *,
.v-table-views *:before,
.v-table-views *:after {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}

.v-table-views {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;

  position: relative;
  overflow: hidden;
  border: 1px solid #ddd;
  padding: 0;
  background-color:#f0f0f0;
  border-width:1px 0;
}

.tbl-wrap-type1 .v-table-views { border-top-color:#3177b4; }

.v-table-footer {
  border-top: 1px solid rgba(221, 221, 221, 1);
}

.v-table-leftview,
.v-table-rightview {
  position: absolute;
  overflow: hidden;
  top: 0px;
}

.v-table-leftview {
  left: 0px;
}

.v-table-header {
  overflow: hidden;
}

.v-table-header {
  background-position: initial;
  background-size: initial;
  background-attachment: initial;
  background-origin: initial;
  background-clip: initial;
  background-color: initial;
  background-repeat-x: repeat;
  background-repeat-y: no-repeat;
  background:#f0f0f0 !important;
}

.tbl-wrap-type1 .v-table-header { background:#f2f6f8 !important; }

.v-table-header,
.v-table-toolbar,
.v-table-pager,
.v-table-footer-inner {
  border-color: rgba(221, 221, 221, 1);
}

.v-table-header-row {
  font-weight: bold;
  /*background-color: #F5F5F6;*/
  /*background-color: #eee;*/
  background-color: #f0f0f0;
  border: 1px solid #ddd;
}

.tbl-wrap-type1 .v-table-header-row { background:#f2f6f8; }

.v-table-header-inner {
  float: left;
  width: 10000px;
}

.v-table-htable,
.v-table-btable,
.v-table-ftable {
  border-collapse: separate;
}

/*.v-table-btable tr:nth-child(even) {
        background:#f4f4f4;
    }*/

.v-table-header td,
.v-table-body td,
.v-table-footer td {
  margin: 0;
  padding: 0;
  font-size:15px;
}

.v-table-body-cell {  
  margin: 0;
  white-space: nowrap;
  word-wrap: normal;
  overflow: hidden;
  text-overflow: ellipsis;
  border: 0px solid #dddddd;
}

.v-table-body-cell .v-label {
  padding: 0 10px;
}

.tbl-wrap-type1 .v-table-body-cell { 
  border-color:#ddd;
 }

.v-table-body {
  margin: 0;
  padding: 0;
  zoom: 1;
}

.v-table-rightview .v-table-body,
.v-table-rightview .v-table-footer {
  overflow-x: auto;
  overflow-y: auto;
}

.v-table-leftview .v-table-body {
  overflow-x: hidden !important;
  overflow-y: hidden !important;
}

.v-table-leftview .v-table-body-inner {
  /* padding-bottom: 20px;*/
}

.v-table-body-inner-pb {
  padding-bottom: 20px;
}

.v-table-rightview {
  right: 0px;
}

.v-table-title-cell {
  margin: 0;
  border-width: 0;
  border-style: solid;
  border-color: #ddd;
}


.tbl-wrap-type1 .v-table-title-cell {
  border-bottom-width:2px !important;
  border-color:#3177b4;
}

.v-table-title-cell:before {
  content: "";
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  /* border: 1px solid red;*/ /* so we can see what's going on */
}

.table-title {
  display: inline-block;
  padding: 0 10px;
  vertical-align: middle;
  word-break: break-all;
  overflow: hidden;
  line-height: 1.2em;
  font-size:15px;
  font-weight:400;
  color:#4d4c4b;
}

.v-table-sort-icon {
  /* position: relative;
  display: inline-block;
  vertical-align: middle;
  font-size:16px;
  width: 16px;
  height: 19px;
  margin-left: -5px;
  overflow: hidden;
  cursor: pointer; */
  overflow: hidden;
  cursor: pointer;
  display: inline-block;
  position: relative;
  top:-2px;
  font-size:0;
  margin-left:3px;
  width: 0;
  height: 0;
  border-style: solid;
  border-width: 5px 5px 0 5px;
  border-color: #3177b4 transparent transparent transparent;
}

.v-table-sort-icon i {
  position: absolute;
  display: block;
  width: 16px;
  height: 15px;
  /*line-height: 12px;*/
  overflow: hidden;
  color: #a6a6a6;
  transition: color 0.2s ease-in-out;
}

.v-table-sort-icon i:first-child {
  top: -5px;
}

.v-table-sort-icon i:last-child {
  bottom: 1px;
}

.v-table-header .cursorPointer {
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -khtml-user-select: none;
  -ms-user-select: none;
}

.vertical-border {
  border-right-width: 1px !important;
}

.horizontal-border {
  border-bottom-width: 1px !important;
}

.v-table-rightview-special-border td:last-child .v-table-body-cell {
  border-right-width: 0 !important;
}

.v-table-dropdown {
  margin-left: -3px !important;
}

.v-table-filter-icon {
  font-size: 14px;
  cursor: pointer;
}

.v-table-empty {
}

.v-table-empty-scroll {
  position: absolute;
  overflow-y: hidden;
  text-align: center;
}

.v-table-empty-content {
  position: absolute;
  overflow-x: auto;
  overflow-y: hidden;
  text-align: center;
}

.v-table-empty-inner {
  overflow: hidden;
}

/*loading start*/

.v-table-loading {
  position: relative;
  display: block;
  z-index: 99999;
  background-color: #fff;
  height: 100%;
  width: 100%;
}

.v-table-loading-content {
  z-index: 9999999;
  position: absolute;
  left: 50%;
}

.v-table-drag-line {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 0;
  border-left: 2px dashed #ddd;
  z-index: 10;
}

</style>
