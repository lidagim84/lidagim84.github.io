import VTable from './Table';

export { VTable };
