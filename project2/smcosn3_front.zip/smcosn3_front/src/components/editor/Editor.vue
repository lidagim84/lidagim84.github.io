<template>
  <tinymce-editor
    api-key="jva9ld7ztd2n7ia264vpavhlakw06pry6f58x8zpxwlcwn2s"
    :init="config"
    v-model="content"
  ></tinymce-editor>

</template>

<script>
import Editor from '@tinymce/tinymce-vue';
import { uploadImg } from '../../services';

export default {
  name: 'editor',
  components: {
    'tinymce-editor': Editor, // <- Important part
  },
  props: {
    value: {
      required: false,
      default: '',
      disabled: Boolean,
    },
    height: {
      default: 300,
    },
  },
  watch: {
    value(newVal, oldVal) {
      if (newVal) {
        this.content = this.value;
      }
    },
    content(newVal) {
      this.$emit('input', newVal);
    },
  },
  data() {
    return {
      config: {
        height: this.height,
        images_upload_url:
          process.env.VUE_APP_API_URL + '/api/common/uploadImage',
        relative_urls: false,
        // enabled the protocol and host part of the URLs to remain (relative_urls must be false)
        remove_script_host: false,
        document_base_url: process.env.VUE_APP_API_URL,
        plugins: [
          'advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker',
          'searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking',
          'save table directionality emoticons template paste',
        ],
        toolbar:
          'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media fullpage | forecolor backcolor emoticons',
      },
      content: '',
    };
  },
  methods: {},
  created() {
    if (this.value) {
      this.content = this.value;
    }
  },
};
</script>

<style scoped>
.text-tiny {
  font-size: 0.7em;
}

.text-small {
  font-size: 0.85em;
}

.text-big {
  font-size: 1.4em;
}

.text-huge {
  font-size: 1.8em;
}
</style>
