<template>
  <div>
    <table
      v-if="listType === 'text'"
      class="table table-striped file-list"
      style="width:100%"
    >
      <thead>
        <tr>
          <!-- <th style="width:50px">순번</th> -->
          <th style="width:30%;min-width:100px">파일명</th>
          <th style="width:50px">유형</th>
          <th style="width:80px">용량</th>
          <th style="width:50px">삭제</th>
          <th style="width:50px">받기</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="file in files"
          :key="file.uid"
          tabindex="0"
          @keydown.delete="!disabled && $emit('remove', file)"
          @focus="focusing = true"
          @blur="focusing = false"
          @click="focusing = false"
        >
          <td
            :title="file.name"
            @click="handleClick(file)"
          >
            {{file.name}}
            <el-progress
              v-if="file.status === 'uploading'"
              type="line"
              :stroke-width="2"
              :percentage="parsePercentage(file.percentage)"
            >
            </el-progress>
          </td>
          <td>{{file.name | fileType}}</td>
          <td>{{file.size | prettyBytes}}</td>
          <td>
            <button
              class="btn btn-warning btn-circle"
              type="button"
              @click="$emit('remove', file)"
            >
              <i class="fa fa-times"></i>
            </button>
          </td>
          <td>
            <button
              class="btn btn-warning btn-circle"
              type="button"
              @click="downloadFile(idx)"
            >
              <i class="fa fa-download"></i>
            </button>
          </td>
        </tr>
      </tbody>
    </table>

    <transition-group
      v-if="['picture-card', 'picture'].indexOf(listType) > -1"
      tag="ul"
      :class="[
      'el-upload-list',
      'el-upload-list--' + listType,
      { 'is-disabled': disabled }
    ]"
      name="el-list"
    >
      <li
        v-for="file in files"
        :class="['el-upload-list__item', 'is-' + file.status, focusing ? 'focusing' : '']"
        :key="file.uid"
        tabindex="0"
        @keydown.delete="!disabled && $emit('remove', file)"
        @focus="focusing = true"
        @blur="focusing = false"
        @click="focusing = false"
      >
        <slot :file="file">
          <img
            class="el-upload-list__item-thumbnail"
            v-if="file.status !== 'uploading' && ['picture-card', 'picture'].indexOf(listType) > -1"
            :src="file.url"
            alt=""
          >
          <a
            class="el-upload-list__item-name"
            @click="handleClick(file)"
          >
            <i class="el-icon-document"></i>{{file.name}}
          </a>
          <label class="el-upload-list__item-status-label">
            <i :class="{
            'el-icon-upload-success': true,
            'el-icon-circle-check': listType === 'text',
            'el-icon-check': ['picture-card', 'picture'].indexOf(listType) > -1
          }"></i>
          </label>
          <i
            class="el-icon-close"
            v-if="!disabled"
            @click="$emit('remove', file)"
          ></i>
          <i
            class="el-icon-close-tip"
            v-if="!disabled"
          >{{'el.upload.deleteTip' }}</i>
          <el-progress
            v-if="file.status === 'uploading'"
            :type="listType === 'picture-card' ? 'circle' : 'line'"
            :stroke-width="listType === 'picture-card' ? 6 : 2"
            :percentage="parsePercentage(file.percentage)"
          >
          </el-progress>
          <span
            class="el-upload-list__item-actions"
            v-if="listType === 'picture-card'"
          >
            <span
              class="el-upload-list__item-preview"
              v-if="handlePreview && listType === 'picture-card'"
              @click="handlePreview(file)"
            >
              <i class="el-icon-zoom-in"></i>
            </span>
            <span
              v-if="!disabled"
              class="el-upload-list__item-delete"
              @click="$emit('remove', file)"
            >
              <i class="el-icon-delete"></i>
            </span>
          </span>
        </slot>
      </li>
    </transition-group>
  </div>
</template>
<script>
import ElProgress from './Progress';
export default {
  name: 'ElUploadList',
  data() {
    return {
      focusing: false,
    };
  },
  components: { ElProgress },
  props: {
    files: {
      type: Array,
      default() {
        return [];
      },
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    handlePreview: Function,
    listType: String,
  },
  methods: {
    parsePercentage(val) {
      return parseInt(val, 10);
    },
    handleClick(file) {
      this.handlePreview && this.handlePreview(file);
    },
  },
  created() {
  }
};
</script>
