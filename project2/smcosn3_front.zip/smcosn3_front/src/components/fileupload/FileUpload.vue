<template>
  <div>
    <div v-if="!readonly" class="fileinput fileinput-new" data-provides="fileinput">
      <button class="btn btn-strong" type="button" @click="$refs.files.click();">
        <i class="fa fa-upload"></i>&nbsp;&nbsp;
        <span class="bold">파일선택</span>
      </button>
      <!--<span class="btn btn-default btn-file"><span class="fileinput-new" @click="$refs.files.click();">파일선택</span></span>-->
      <input
        ref="files"
        name="files[]"
        @change="addFile"
        style="visibility: hidden; width:0;height:0"
        type="file"
        :multiple="multiple ? 'multiple' : null"
      />
    </div>
    <div v-if="fileList.length">
      <table class="table table-striped file-list" style="width:100%">
        <thead>
          <tr>
            <!-- <th style="width:50px">순번</th> -->
            <th style="width:30%;min-width:100px">파일명</th>
            <th style="width:50px">유형</th>
            <th style="width:80px">용량</th>
            <th style="width:50px">삭제</th>
            <th style="width:50px">받기</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(file, idx) in fileList.filter(file=> 'D' != file.mode)" :key="idx">
            <td v-if="isImg(file.file_name)">
              <div
                :style="'width:100px;height:100px;background-repeat: no-repeat; background-image: url('+file.path+'); background-size: cover;'"
              ></div>
            </td>
            <td v-if="!isImg(file.file_name)" :title="file.file_name">{{file.file_name}}</td>
            <td>{{file.file_type}}</td>
            <td>{{file.file_size | prettyBytes}}</td>
            <td>
              <button
                class="btn btn-warning btn-circle"
                type="button"
                @click="setFilter(idx, file)"
              >
                <i class="fa fa-times"></i>
              </button>
            </td>
            <td>
              <button
                v-if="!isImg(file.file_name)"
                class="btn btn-warning btn-circle"
                type="button"
                @click="downloadFile(file)"
              >
                <i class="fa fa-download"></i>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>


<script>
let FILE_UPLOAD_ID = 0;
// import axios from 'axios';
import {
  uploadFile,
  getFileList,
  setFileList,
  fileDownload
} from "../../services";
// import { resolve, Promise } from 'q';
//import NProgress from 'nprogress';
// const progress = create(Progress, 'title', 'content');
// const loading = NProgress.configure({ showSpinner: false });

export default {
  name: "v-fileupload",
  props: {
    btn_class: {
      type: String,
      required: false
    },
    tw: {
      required: false,
      default: 224
    },
    th: {
      required: false,
      default: 224
    },
    value: {
      required: false,
      default: ""
    },
    multiple: {
      required: false,
      default: false
    },
    readonly: {
      type: Boolean,
      default: false
    },
    dst_path: {
      type: String,
      default: "/"
    },
    is_imguploader: {
      required: false,
      default: false
    }
  },
  data: function() {
    return {
      file: null,
      fid: 0,
      fileList: [],
      images: [],
      path: "",
      isUploading: false
    };
  },
  watch: {
    value: function(newVal, oldVal) {
      if (newVal) {
        this.getFileList(newVal);
      }
    }
  },
  methods: {
    addFile: function() {
      this.file = this.$el.querySelector('input[type="file"]');
      let pathInfo = "";
      if (this.file.value.indexOf(",") > -1) {
        pathInfo = this.file.value.split(",")[0];
        pathInfo = pathInfo.split("\\", pathInfo.split("\\").length - 1);
      } else {
        pathInfo = this.file.value.split(
          "\\",
          this.file.value.split("\\").length - 1
        );
      }

      for (let file of this.file.files) {
        let arr = file.name.split(".");
        if (/\.(jpe?g|png|gif)$/i.test(file.name)) {
          let reader = new FileReader();
          reader.onload = e => {
            this.fileList.push({
              mode: "N",
              file_name: file.name,
              file_size: file.size,
              file_type: arr[arr.length - 1]
              // path: pathInfo.join('/') + '/' + file.name,
              //path: e.target.result
            });
            // console.log({ name: file.name, src: e.target.result });
          };
          reader.readAsDataURL(file);
        } else {
          this.fileList.push({
            mode: "N",
            file_name: file.name,
            file_size: file.size,
            file_type: arr[arr.length - 1]
            //path: pathInfo.join("/") + "/" + file.name
          });
        }
      }
    },
    setFilter(idx, file) {
      this.fileList
        .filter(item => "D" != item.mode)
        .map((item, index) => {
          if (idx == index) {
            item.mode = "D";
          }
          return item;
        });
      // this.fileList = this.fileList.filter(item => 'D' != item.mode);
      this.file = this.$el.querySelector('input[type="file"]');
      this.file.value = null;
    },
    uploadFile() {
      if (!this.file || !this.file.files || !this.file.files.length) {
        return Promise.resolve(this.fileList);
      }
      let promiseArray = [];
      Object.keys(this.file.files).map(key => {
        let formData = new FormData();
        formData.append("file", this.file.files[key]);
        const uploadPromise = uploadFile(formData, progressEvent => {
          this.percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
        }).then(res => {
          const data = res.data;
          if (data) {
            data.mode = "N";
          }
          return data;
        });
        promiseArray.push(uploadPromise);
      });
      return Promise.all([
        ...promiseArray,
        ...this.fileList.filter(item => "D" == item.mode)
      ]).then(res => res);
    },
    removeFile() {},
    downloadFile(file) {
      return fileDownload(file.path, file.file_name);
    },
    getFileList(fileMapId) {
      getFileList({ file_map_id: fileMapId }).then(res => {
        const data = res.data;
        if (data && data.length) {
          this.fileList = data.map(file => {
            return file;
          });
        }
      });
    },
    setFileList(fileMapId, fileList) {
      if (!fileList.length) return Promise.resolve(0);

      fileList.map(item => {
        item.file_map_id = fileMapId;
        return item;
      });
      return setFileList(fileList);
    }
  },
  created: function() {
    this.fid = FILE_UPLOAD_ID++;
    if (this.value) {
      this.getFileList(this.value);
    }
  }
};
</script>

<style scoped>
.btn-circle {
  width: 21px !important;
  height: 21px !important;
  padding: 0px !important;
  background: #e5917b;
  border: 0;
  border-radius: 0;
  color: #fff;
}
.table.table-striped.file-list {
  table-layout: fixed;
  border-collapse: collapse;
}

.table.table-striped.file-list td {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
</style>
