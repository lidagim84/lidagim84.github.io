<template>
  <div class="input-group">
    <input type="hidden" :name="name" class="form-control" v-model="value" />
    <input
      type="text"
      class="form-control form-control-sm cursor"
      v-model="text"
      :readonly="readonly"
      @keyup.13="clickFunction"
      @click="searchInput()"
    />
    <span class="input-group-append">
      <button type="button" class="btn btn-sm btn-primary" @click="searchInput()">
        <i class="fa fa-user-o"></i>
      </button>
      <button type="button" class="clearButton" @click="clear()"><span class="clearButtonIcon">&times;</span></button>
    </span>
  </div>
</template>


<script>
export default {
  name: "SelectionInput",
  props: {
    clickFunction: {
      type: Function
    },
    roleType: {
      type: String,
      default: ""
    },
    name: {
      type: String,
      default: ""
    },
    value: {
      default: ""
    },
    text: {
      default: ""
    },
    validate: {
      type: String,
      default: "required"
    },
    readonly: {
      type: Boolean,
      default: true
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      selectedItem: {}
    };
  },
  computed: {},
  watch: {
    text(newValue) {
      if (newValue) {
        this.text = newValue;
      }
    }
  },
  methods: {
    searchInput() {
      if (this.readonly && !this.disabled) {
        if (this.roleType) {
          this.clickFunction(this.roleType);
        } else {
          this.clickFunction();
        }
      }
    },
    clear() {
      this.text = "";
    }
  },
  created() {
    if (this.text) {
      this.text = this.text;
    }
  }
};
</script>

<style>
.wizard > .content {
  height: auto !important;
  min-height: inherit !important;
}

.input-group .input-group-append .clearButton { 
    position: absolute;
    right: 35px;
    top: 0;
    z-index: 2;
    border: 0;
    outline: 0;
    background: transparent;
    font-size: 31px;
    height: 37px;
    line-height: 35px; 
    width:30px;
  }

  .input-group .input-group-append .clearButtonIcon { 
    display:inline-block; 
    vertical-align:top; 
  }
</style>
