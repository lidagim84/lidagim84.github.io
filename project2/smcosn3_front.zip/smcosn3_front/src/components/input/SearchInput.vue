<template>
  <div class="dropdown" v-if="options">
    <!-- Dropdown Input -->
    <input
      ref="search"
      class="form-control"
      @click="showOptions()"
      @blur="exit()"
      @keyup="keyMonitor"
      v-model="searchFilter"
      :disabled="disabled"
      :placeholder="placeholder"
    />

    <!-- Dropdown Menu -->
    <ul
      v-show="optionsShown"
      class="typeahead dropdown-menu"
      style="display:block;max-height:200px;overflow:auto"
    >
      <li
        :class="{'active': index == selectedIndex}"
        @mousedown="selectOption(option, index)"
        v-for="(option, index) of filteredOptions"
        :key="index"
      >
        <a class="dropdown-item" href="#" role="option">{{ option[labelField]}}</a>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "SearchInput",
  props: {
    options: {
      type: Array,
      default: function() {
        return [];
      }
    },
    placeholder: {
      type: String,
      default: "내용을 입력하세요.",
      note: "Placeholder of dropdown"
    },
    labelField: {
      type: String,
      default: "name"
    },
    valueField: {
      type: String,
      default: "value"
    },
    disabled: {
      type: Boolean,
      default: false,
      note: "Disable the dropdown"
    },
    value: {
      type: String,
      default: null
    },
    updatable: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      selected: {},
      optionsShown: false,
      searchFilter: "",
      selectedIndex: 0
    };
  },
  computed: {
    filteredOptions() {
      const filtered = [];
      const regOption = new RegExp(this.searchFilter, "ig");
      for (const option of this.options) {
        if (
          (this.searchFilter &&
            this.searchFilter.length &&
            this.searchFilter.length < 1) ||
          String(option[this.labelField]).match(regOption)
        ) {
          filtered.push(option);
        }
      }
      return filtered;
    }
  },
  watch: {
    searchFilter() {
      if (this.filteredOptions.length == 0) {
        this.selected[this.valueField] = null;
        this.selected[this.labelField] = this.searchFilter;
      } else {
        this.selected = this.filteredOptions[0];
      }
    },
    value(newVal) {
      if (newVal) {
      }
    },
    options(newVal) {
      if (newVal.length && this.value) {
        let item = newVal.filter(
          option => option[this.valueField] == this.value
        );
        if (item.length) {
          this.selected = item[0];
          this.searchFilter = this.selected[this.labelField];
        }
      }
    }
  },
  methods: {
    selectOption(option) {
      if (option) {
        this.selected = option;
        this.searchFilter = option[this.labelField];
        this.$emit("input", option[this.valueField]);
      }
      this.optionsShown = false;
    },
    showOptions() {
      if (!this.disabled && this.filteredOptions.length > 1) {
        // this.searchFilter = '';
        this.optionsShown = true;
        if (this.value) {
          this.selectedIndex = this.filteredOptions.findIndex(
            option => option[this.valueField] === this.value
          );
        }
      }
    },
    exit() {
      if (
        this.filteredOptions.length &&
        this.filteredOptions[this.selectedIndex]
      ) {
        this.searchFilter = this.filteredOptions[this.selectedIndex][
          this.labelField
        ];
        this.$emit(
          "input",
          this.filteredOptions[this.selectedIndex][this.valueField]
        );
      }
      this.optionsShown = false;
    },
    keyMonitor: function(event) {
      if (event.key === "Enter" && this.filteredOptions[0]) {
        this.selectOption(this.filteredOptions[this.selectedIndex]);
      } else if (event.key == "ArrowUp") {
        if (this.selectedIndex > 0) {
          this.selectedIndex--;
        }
      } else if (event.key == "ArrowDown") {
        if (this.selectedIndex < this.filteredOptions.length - 1) {
          this.selectedIndex++;
        }
      } else if (this.selected && this.searchFilter) {
        if (this.updatable) {
          this.selected[this.labelField] = this.searchFilter;
        } else if (this.filteredOptions[0]) {
          // this.selected[this.labelField] = this.filteredOptions[0];
        }
        this.$emit("input", this.selected);
      }
    }
  }
};
</script>


<style>
.dropdown {
  /* position: relative; */
  /* display: block; */
  /* margin: auto; */
  /* margin: 0px; */
}
</style>
