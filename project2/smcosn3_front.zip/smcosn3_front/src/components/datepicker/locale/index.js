import en from './translations/en'
import ko from './translations/ko'


export {
  en,
  ko
}
// eslint-disable-next-line
;
