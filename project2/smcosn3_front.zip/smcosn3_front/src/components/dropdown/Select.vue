<template>
  <select :class="inputClass" v-model="selectedValue" @change="selectChange">
    <option v-if="placeholder" value>{{placeholder}}</option>
    <option
      v-for="(option, index) in list"
      :value="option[valueField]"
      :key="index"
    >{{ option[labelField] }}</option>
  </select>
</template>

<script>
export default {
  name: "Select",
  props: {
    value: {
      default: ""
    },
    options: {
      type: Array,
      default() {
        return [];
      }
    },
    labelField: {
      type: String,
      default: "label"
    },
    valueField: {
      type: String,
      default: "value"
    },
    index: {
      type: String,
      default: null
    },
    placeholder: {
      type: String,
      default: "선택하세요."
    },
    code: {
      type: String,
      default: ""
    },
    inputClass: {
      type: String,
      default: "form-control"
    }
  },
  data: function() {
    return {
      list: [],
      selectedValue: this.value ? this.value : ""
    };
  },
  watch: {
    value: function(newVal, oldVal) {
      this.selectedValue = newVal;
    },
    options(newVal, oldVal) {
      this.list = newVal;
    },
    code(newVal, oldVal) {
      if (newVal) {
        this.list = this.commonCodeList(newVal);
      }
    }
  },
  methods: {
    selectChange(e) {
      this.$emit("input", this.selectedValue);
    }
  },
  created: function() {
    if (this.code) {
      this.list = this.commonCodeList(this.code);
    }
  }
};
</script>

<style scoped>
</style>
