<template>
  <div
    :dir="dir"
    class="dropdown v-select"
    :class="dropdownClasses"
  >
    <div
      ref="toggle"
      @mousedown.prevent="toggleDropdown"
      class="dropdown-toggle"
    >
      <div
        class="vs__selected-options"
        ref="selectedOptions"
      >
        <slot
          v-for="option in valueAsArray"
          name="selected-option-container"
          :option="(typeof option === 'object')?option:{[label]: option}"
          :deselect="deselect"
          :multiple="multiple"
          :disabled="disabled"
        >
          <span
            class="selected-tag"
            v-bind:key="option.index"
          >
            <slot
              name="selected-option"
              v-bind="(typeof option === 'object')?option:{[label]: option}"
            >
              {{ getOptionLabel(option) }}
            </slot>
            <button
              v-if="multiple"
              :disabled="disabled"
              @click="deselect(option)"
              type="button"
              class="close"
              aria-label="Remove option"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </span>
        </slot>

        <input
          ref="search"
          type="search"          
          @keydown.delete="maybeDeleteValue"
          @keyup.esc="onEscape"
          @keydown.up.prevent="typeAheadUp"
          @keydown.down.prevent="typeAheadDown"
          @keydown.enter.prevent="typeAheadSelect"
          @keydown.tab="onTab"
          @blur="onSearchBlur"
          @focus="onSearchFocus"          
          class="form-control"
          autocomplete="off"
          :disabled="disabled"
          :placeholder="searchPlaceholder"
          :tabindex="tabindex"
          :readonly="!searchable"
          :id="inputId"
          role="combobox"
          :aria-expanded="dropdownOpen"
          aria-label="Search for option"
          v-model="search"
        >

      </div>
      <div class="vs__actions">
        <button
          v-show="showClearButton"
          :disabled="disabled"
          @click="clearSelection"
          type="button"
          class="clear"
          title="Clear selection"
        >
          <span aria-hidden="true">&times;</span>
        </button>

        <i
          v-if="!noDrop"
          ref="openIndicator"
          role="presentation"
          class="open-indicator"
        ></i>

        <slot name="spinner">
          <div
            class="spinner"
            v-show="mutableLoading"
          >Loading...</div>
        </slot>
      </div>
    </div>

    <transition :name="transition">
      <ul
        ref="dropdownMenu"
        v-if="dropdownOpen"
        class="dropdown-menu"
        :style="{ 'max-height': maxHeight }"
        role="listbox"
        @mousedown="onMousedown"
      >
        <li
          role="option"
          v-for="(option, index) in filteredOptions"
          v-bind:key="index"
          :class="{ active: isOptionSelected(option), highlight: index === typeAheadPointer }"
          @mouseover="typeAheadPointer = index"
        >
          <a @mousedown.prevent.stop="select(option)">
            <slot
              name="option"
              v-bind="(typeof option === 'object')?option:{[label]: option}"
            >
              {{ getOptionLabel(option) }}
            </slot>
          </a>
        </li>
        <li
          v-if="!filteredOptions.length"
          class="no-options"
          @mousedown.stop=""
        >
          <slot name="no-options">Sorry, no matching options.</slot>
        </li>
      </ul>
    </transition>
  </div>
</template>

<script type="text/babel">
import pointerScroll from './mixins/pointerScroll';
import typeAheadPointer from './mixins/typeAheadPointer';
import ajax from './mixins/ajax';

export default {
  mixins: [pointerScroll, typeAheadPointer, ajax],
  props: {
    value: {
      default: null
    },
    options: {
      type: Array,
      default() {
        return [];
      }
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: true
    },
    maxHeight: {
      type: String,
      default: '400px'
    },
    searchable: {
      type: Boolean,
      default: true
    },
    multiple: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: String,
      default: '선택하세요.'
    },
    transition: {
      type: String,
      default: 'fade'
    },
    rchOnSelect: {
      type: Boolean,
      default: true
    },
    closeOnSelect: {
      type: Boolean,
      default: true
    },
    label: {
      type: String,
      default: 'label'
    },
    index: {
      type: String,
      default: null
    },
    getOptionLabel: {
      type: Function,
      default(option) {
        if (this.index) {
          option = this.findOptionByIndexValue(option);
        }
        if (typeof option === 'object') {
          if (!option.hasOwnProperty(this.label)) {
            return console.warn(
              `[vue-select warn]: Label key "option.${this.label}" does not` +
                ` exist in options object ${JSON.stringify(option)}.\n` +
                'http://sagalbot.github.io/vue-select/#ex-labels'
            );
          }
          return option[this.label];
        }
        return option;
      }
    },
    onChange: {
      type: Function,
      default: function(selectedItem) {
        if (selectedItem && selectedItem.value) {
          this.$emit('input', selectedItem.value);
        } else {
          this.$emit('input', selectedItem);
        }
        this.$emit('seletedItem', selectedItem);
      }
    },
    onTab: {
      type: Function,
      default: function() {
        if (this.selectOnTab) {
          this.typeAheadSelect();
        }
      }
    },
    taggable: {
      type: Boolean,
      default: false
    },
    tabindex: {
      type: Number,
      default: null
    },
    pushTags: {
      type: Boolean,
      default: false
    },
    filterable: {
      type: Boolean,
      default: true
    },
    filterBy: {
      type: Function,
      default(option, label, search) {
        return (label || '').toLowerCase().indexOf(search.toLowerCase()) > -1;
      }
    },
    filter: {
      type: Function,
      default(options, search) {
        return options.filter(option => {
          let label = this.getOptionLabel(option);
          if (typeof label === 'number') {
            label = label.toString();
          }
          return this.filterBy(option, label, search);
        });
      }
    },
    createOption: {
      type: Function,
      default(newOption) {
        if (typeof this.mutableOptions[0] === 'object') {
          newOption = { [this.label]: newOption };
        }
        this.$emit('option:created', newOption);
        return newOption;
      }
    },
    resetOnOptionsChange: {
      type: Boolean,
      default: false
    },
    noDrop: {
      type: Boolean,
      default: false
    },
    inputId: {
      type: String
    },
    dir: {
      type: String,
      default: 'auto'
    },
    selectOnTab: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      search: '',
      open: false,
      mutableValue: null,
      mutableOptions: []
    };
  },
  watch: {
    value(val) {
      if (typeof val === 'object') {
        this.mutableValue = val;
      } else {
        let selectedItems = this.options.filter(option => option.value == val);
        if (selectedItems.length) {
          this.mutableValue = selectedItems[0];
        }
      }
    },
    mutableValue(val, old) {
      if (this.multiple) {
        this.onChange ? this.onChange(val) : null;
      } else {
        this.onChange && val !== old ? this.onChange(val) : null;
      }
    },
    options(val) {
      this.mutableOptions = val;
    },
    mutableOptions() {
      if (!this.taggable && this.resetOnOptionsChange) {
        this.mutableValue = this.multiple ? [] : null;
      }
    },
    multiple(val) {
      this.mutableValue = val ? [] : null;
    }
  },
  computed: {
    dropdownClasses() {
      return {
        open: this.dropdownOpen,
        single: !this.multiple,
        searching: this.searching,
        searchable: this.searchable,
        unsearchable: !this.searchable,
        loading: this.mutableLoading,
        rtl: this.dir === 'rtl', // This can be removed - styling is handled by `dir="rtl"` attribute
        disabled: this.disabled
      };
    },
    clearSearchOnBlur() {
      return this.clearSearchOnSelect && !this.multiple;
    },
    searching() {
      return !!this.search;
    },
    dropdownOpen() {
      return this.noDrop ? false : this.open && !this.mutableLoading;
    },
    searchPlaceholder() {
      if (this.isValueEmpty && this.placeholder) {
        return this.placeholder;
      }
      return '';
    },
    filteredOptions() {
      if (!this.filterable && !this.taggable) {
        return this.mutableOptions.slice();
      }
      let options = this.search.length
        ? this.filter(this.mutableOptions, this.search, this)
        : this.mutableOptions;
      if (
        this.taggable &&
        this.search.length &&
        !this.optionExists(this.search)
      ) {
        options.unshift(this.search);
      }
      return options;
    },
    isValueEmpty() {
      if (this.mutableValue) {
        if (typeof this.mutableValue === 'object') {
          return !Object.keys(this.mutableValue).length;
        }
        return !this.valueAsArray.length;
      }
      return true;
    },
    valueAsArray() {
      if (this.multiple && this.mutableValue) {
        return this.mutableValue;
      } else if (this.mutableValue) {
        return [].concat(this.mutableValue);
      }

      return [];
    },
    showClearButton() {
      return (
        !this.multiple &&
        this.clearable &&
        !this.open &&
        this.mutableValue != null
      );
    }
  },
  methods: {
    select(option) {
      if (!this.isOptionSelected(option)) {
        if (this.taggable && !this.optionExists(option)) {
          option = this.createOption(option);
        }
        if (this.index) {
          if (!option.hasOwnProperty(this.index)) {
            return console.warn(
              `[vue-select warn]: Index key "option.${this.index}" does not` +
                ` exist in options object ${JSON.stringify(option)}.`
            );
          }
          option = option[this.index];
        }
        if (this.multiple && !this.mutableValue) {
          this.mutableValue = [option];
        } else if (this.multiple) {
          this.mutableValue.push(option);
        } else {
          this.mutableValue = option;
        }
      }
      this.onAfterSelect(option);
    },
    deselect(option) {
      if (this.multiple) {
        let ref = -1;
        this.mutableValue.forEach(val => {
          if (
            val === option ||
            (this.index && val === option[this.index]) ||
            (typeof val === 'object' && val[this.label] === option[this.label])
          ) {
            ref = val;
          }
        });
        var index = this.mutableValue.indexOf(ref);
        this.mutableValue.splice(index, 1);
      } else {
        this.mutableValue = null;
      }
    },
    clearSelection() {
      this.mutableValue = this.multiple ? [] : null;
      this.search = '';
    },
    onAfterSelect() {
      if (this.closeOnSelect) {
        this.open = !this.open;
        this.$refs.search.blur();
      }
      if (this.clearSearchOnSelect) {
        this.search = '';
      }
    },
    toggleDropdown(e) {
      if (
        e.target === this.$refs.openIndicator ||
        e.target === this.$refs.search ||
        e.target === this.$refs.toggle ||
        e.target.classList.contains('selected-tag') ||
        e.target === this.$el
      ) {
        if (this.open) {
          this.$refs.search.blur(); // dropdown will close on blur
        } else {
          if (!this.disabled) {
            this.open = true;
            this.$refs.search.focus();
          }
        }
      }
    },
    isOptionSelected(option) {
      let selected = false;
      this.valueAsArray.forEach(value => {
        if (typeof value === 'object') {
          selected = this.optionObjectComparator(value, option);
        } else if (
          value === option.value ||
          value === option ||
          value === option[this.index]
        ) {
          selected = true;
        }
      });
      return selected;
    },
    optionObjectComparator(value, option) {
      if (this.index && value === option[this.index]) {
        return true;
      } else if (
        value[this.label] === option[this.label] ||
        value[this.label] === option
      ) {
        return true;
      } else if (this.index && value[this.index] === option[this.index]) {
        return true;
      }
      return false;
    },
    findOptionByIndexValue(value) {
      this.options.forEach(_option => {
        if (JSON.stringify(_option[this.index]) === JSON.stringify(value)) {
          value = _option;
        }
      });
      return value;
    },
    onEscape() {
      if (!this.search.length) {
        this.$refs.search.blur();
      } else {
        this.search = '';
      }
    },
    onSearchBlur() {
      if (this.mousedown && !this.searching) {
        this.mousedown = false;
      } else {
        if (this.clearSearchOnBlur) {
          this.search = '';
        }
        this.open = false;
        this.$emit('search:blur');
      }
    },
    onSearchFocus() {
      this.open = true;
      this.$emit('search:focus');
    },
    maybeDeleteValue() {
      if (!this.$refs.search.value.length && this.mutableValue) {
        return this.multiple
          ? this.mutableValue.pop()
          : (this.mutableValue = null);
      }
    },
    optionExists(option) {
      let exists = false;
      this.mutableOptions.forEach(opt => {
        if (typeof opt === 'object' && opt[this.label] === option) {
          exists = true;
        } else if (opt === option.value) {
          exists = true;
        }
      });

      return exists;
    },
    maybePushTag(option) {
      if (this.pushTags) {
        this.mutableOptions.push(option);
      }
    },
    onMousedown() {
      this.mousedown = true;
    }
  },
  created() {
    // if (typeof this.value === 'object') {
    //   this.mutableValue = this.value;
    // } else {
    //   let selectedItems = this.options.filter(
    //     option => option.value == this.value
    //   );
    //   if (selectedItems.length) {
    //     this.mutableValue = selectedItems[0];
    //   }
    // }
    this.mutableOptions = this.options.slice(0);
    this.mutableLoading = this.loading;

    this.$on('option:created', this.maybePushTag);
  }
};
</script>

<style>
.v-select {
  position: relative;
  font-family: inherit;
}

.v-select,
.v-select * {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}

/* Rtl support - Because we're using a flexbox-based layout, the `dir="rtl"` HTML
           attribute does most of the work for us by rearranging the child elements visually.
         */
.v-select[dir='rtl'] .vs__actions {
  padding: 0 3px 0 6px;
}

.v-select[dir='rtl'] .dropdown-toggle .clear {
  margin-left: 6px;
  margin-right: 0;
}

.v-select[dir='rtl'] .selected-tag .close {
  margin-left: 0;
  margin-right: 2px;
}

.v-select[dir='rtl'] .dropdown-menu {
  text-align: right;
}

/* Open Indicator */
.v-select .open-indicator {
  display: flex;
  align-items: center;
  cursor: pointer;
  pointer-events: all;
  transition: all 150ms cubic-bezier(1, -0.115, 0.975, 0.855);
  transition-timing-function: cubic-bezier(1, -0.115, 0.975, 0.855);
  opacity: 1;
  width: 12px; /* To account for extra width from rotating. */
}

.v-select .open-indicator:before {
  border-color: rgba(60, 60, 60, 0.5);
  border-style: solid;
  border-width: 3px 3px 0 0;
  content: '';
  display: inline-block;
  height: 10px;
  width: 10px;
  vertical-align: text-top;
  transform: rotate(133deg);
  transition: all 150ms cubic-bezier(1, -0.115, 0.975, 0.855);
  transition-timing-function: cubic-bezier(1, -0.115, 0.975, 0.855);
  box-sizing: inherit;
}

/* Open Indicator States */
.v-select.open .open-indicator:before {
  transform: rotate(315deg);
}

.v-select.loading .open-indicator {
  opacity: 0;
}

.v-select .dropdown-toggle {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  display: flex;
  padding: 2px 0 6px 0;
  background: none;
  border: 1px solid rgba(60, 60, 60, 0.26);
  border-radius: 4px;
  white-space: normal;
}

.v-select .vs__selected-options {
  display: flex;
  flex-basis: 100%;
  flex-grow: 1;
  flex-wrap: wrap;
  padding: 0 2px;
  position: relative;
}

.v-select .vs__actions {
  display: flex;
  align-items: stretch;
  padding: 0 6px 0 3px;
}

/* Clear Button */
.v-select .dropdown-toggle .clear {
  font-size: 23px;
  font-weight: 700;
  line-height: 1;
  color: rgba(60, 60, 60, 0.5);
  padding: 0;
  border: 0;
  background-color: transparent;
  cursor: pointer;
  margin-right: 5px;
  /* margin-top: 1px; */
}

/* Dropdown Toggle States */
.v-select.searchable .dropdown-toggle {
  cursor: text;
}

.v-select.unsearchable .dropdown-toggle {
  cursor: pointer;
}

.v-select.open .dropdown-toggle {
  border-bottom-color: transparent;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
}

/* Dropdown Menu */
.v-select .dropdown-menu {
  display: block;
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 1000;
  min-width: 160px;
  padding: 5px 0;
  margin: 0;
  width: 100%;
  overflow-y: scroll;
  border: 1px solid rgba(0, 0, 0, 0.26);
  box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.15);
  border-top: none;
  border-radius: 0 0 4px 4px;
  text-align: left;
  list-style: none;
  background: #fff;
}

.v-select .no-options {
  text-align: center;
}

/* Selected Tags */
.v-select .selected-tag {
  display: flex;
  align-items: center;
  background-color: #f0f0f0;
  border: 1px solid #ccc;
  border-radius: 4px;
  color: #333;
  line-height: 1.42857143; /* Normalize line height */
  margin: 4px 2px 0px 2px;
  padding: 0 0.25em;
  transition: opacity 0.25s;
}

.v-select.single .selected-tag {
  background-color: transparent;
  border-color: transparent;
}

.v-select.single.open .selected-tag {
  position: absolute;
  opacity: 0.4;
}

.v-select.single.searching .selected-tag {
  display: none;
}

.v-select .selected-tag .close {
  margin-left: 2px;
  font-size: 1.25em;
  appearance: none;
  padding: 0;
  cursor: pointer;
  background: 0 0;
  border: 0;
  font-weight: 700;
  line-height: 1;
  color: #000;
  text-shadow: 0 1px 0 #fff;
  filter: alpha(opacity=20);
  opacity: 0.2;
}

.v-select.single.searching:not(.open):not(.loading) input[type='search'] {
  opacity: 0.2;
}

/* Search Input */
.v-select input[type='search']::-webkit-search-decoration,
.v-select input[type='search']::-webkit-search-cancel-button,
.v-select input[type='search']::-webkit-search-results-button,
.v-select input[type='search']::-webkit-search-results-decoration {
  display: none;
}

.v-select input[type='search']::-ms-clear {
  display: none;
}

.v-select input[type='search'],
.v-select input[type='search']:focus {
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
  line-height: 1.42857143;
  font-size: 1em;
  display: inline-block;
  border: 1px solid transparent;
  border-left: none;
  outline: none;
  margin: 4px 0 0 0;
  padding: 0 7px;
  max-width: 100%;
  background: none;
  box-shadow: none;
  flex-grow: 1;
  width: 0;
}

.v-select.unsearchable input[type='search'] {
  opacity: 0;
}

.v-select.unsearchable input[type='search']:hover {
  cursor: pointer;
}

/* List Items */
.v-select li {
  line-height: 1.42857143; /* Normalize line height */
}

.v-select li > a {
  display: block;
  padding: 3px 20px;
  clear: both;
  color: #333; /* Overrides most CSS frameworks */
  white-space: nowrap;
}

.v-select li:hover {
  cursor: pointer;
}

.v-select .dropdown-menu .active > a {
  color: #333;
  background: rgba(50, 50, 50, 0.1);
}

.v-select .dropdown-menu > .highlight > a {
  /*
               * required to override bootstrap 3's
               * .dropdown-menu > li > a:hover {} styles
               */
  background: #5897fb;
  color: #fff;
}

.v-select .highlight:not(:last-child) {
  margin-bottom: 0; /* Fixes Bulma Margin */
}

/* Loading Spinner */
.v-select .spinner {
  align-self: center;
  opacity: 0;
  font-size: 5px;
  text-indent: -9999em;
  overflow: hidden;
  border-top: 0.9em solid rgba(100, 100, 100, 0.1);
  border-right: 0.9em solid rgba(100, 100, 100, 0.1);
  border-bottom: 0.9em solid rgba(100, 100, 100, 0.1);
  border-left: 0.9em solid rgba(60, 60, 60, 0.45);
  transform: translateZ(0);
  animation: vSelectSpinner 1.1s infinite linear;
  transition: opacity 0.1s;
}

.v-select .spinner,
.v-select .spinner:after {
  border-radius: 50%;
  width: 5em;
  height: 5em;
}

/* Disabled state */
.v-select.disabled .dropdown-toggle,
.v-select.disabled .dropdown-toggle .clear,
.v-select.disabled .dropdown-toggle input,
.v-select.disabled .selected-tag .close,
.v-select.disabled .open-indicator {
  cursor: not-allowed;
  background-color: rgb(248, 248, 248);
}

.v-select .dropdown-toggle::after {
  display: none !important;
}

/* Loading Spinner States */
.v-select.loading .spinner {
  opacity: 1;
}

/* KeyFrames */
@-webkit-keyframes vSelectSpinner {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

@keyframes vSelectSpinner {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

/* Dropdown Default Transition */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.15s cubic-bezier(1, 0.5, 0.8, 1);
}

.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>
