import ajax from './ajax';
import pointer from './typeAheadPointer';
import pointerScroll from './pointerScroll';

export default { ajax, pointer, pointerScroll };
