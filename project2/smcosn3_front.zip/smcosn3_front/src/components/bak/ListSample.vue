<template>
  <div class="container">
    <div class="page-header">
      <h3 class="page-title">입법정책조사·요청 현황 관리</h3>

      <ol class="breadcrumb">
        <li>
          <a href="https://jumpstartthemes.com/demo/v/3.0.0/templates/admin-1/">서울특별시의회</a>
        </li>
        <li>
          <a
            href="https://jumpstartthemes.com/demo/v/3.0.0/templates/admin-1/form-basic.html#"
          >입법조사요청</a>
        </li>
        <li class="active">입법정책조사·요청 현황 관리</li>
      </ol>
    </div>
    <!-- /.page-header -->

    <form class="form-horizontal">
      <fieldset class>
        <div class="portlet portlet-boxed">
          <div class="portlet-header">
            <div class="row">
              <div class="col-md-3">
                <div class="panel panel-danger panel-colorful media middle pad-all">
                  <div class="media-left">
                    <div class="pad-hor">
                      <i class="demo-pli-file-word icon-3x"></i>
                    </div>
                  </div>
                  <div class="media-body">
                    <p class="text-2x mar-no text-semibold">전체 5</p>
                    <!-- <p class="mar-no">전체</p> -->
                  </div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="panel panel-warning panel-colorful media middle pad-all">
                  <div class="media-left">
                    <div class="pad-hor">
                      <i class="demo-pli-file-zip icon-3x"></i>
                    </div>
                  </div>
                  <div class="media-body">
                    <p class="text-2x mar-no text-semibold">요청중 2</p>
                    <!-- <p class="mar-no">요청중</p> -->
                  </div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="panel panel-mint panel-colorful media middle pad-all">
                  <div class="media-left">
                    <div class="pad-hor">
                      <i class="demo-pli-camera-2 icon-3x"></i>
                    </div>
                  </div>
                  <div class="media-body">
                    <p class="text-2x mar-no text-semibold">회답중 2</p>
                    <!-- <p class="mar-no">회답중</p> -->
                  </div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="panel panel-info panel-colorful media middle pad-all">
                  <div class="media-left">
                    <div class="pad-hor">
                      <i class="demo-pli-video icon-3x"></i>
                    </div>
                  </div>
                  <div class="media-body">
                    <p class="text-2x mar-no text-semibold">완료 1</p>
                    <!-- <p class="mar-no">완료</p> -->
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- /.portlet-header -->
          <div class="portlet-body">
            <div class="form-group row">
              <div class="col-sm-6">
                <div class="dataTables_length" id="DataTables_Table_0_length">
                  <label>
                    <select
                      name="DataTables_Table_0_length"
                      aria-controls="DataTables_Table_0"
                      class="form-control input-sm"
                    >
                      <option value="10">10</option>
                      <option value="25">25</option>
                      <option value="50">50</option>
                      <option value="100">100</option>
                    </select>
                  </label>
                </div>
              </div>
              <div class="col-sm-6">
                <div id="DataTables_Table_0_filter" class="dataTables_filter">
                  <select name="select" style="height:31px;width: 100px">
                    <option value="opt1">분류</option>
                    <option value="opt2">회답수신인 1</option>
                    <option value="opt3">회답수신인 3</option>
                  </select>
                  <label>
                    <input
                      type="search"
                      class="form-control input-sm"
                      placeholder
                      aria-controls="DataTables_Table_0"
                    />
                  </label>
                  <button type="button" class="btn btn-sm btn-primary" style="height:31px">검색</button>
                </div>
              </div>
            </div>
            <div class="table-responsive">
              <!-- list 추가. -->
              <table class="table">
                <thead>
                  <tr>
                    <th class="text-center">요청분류</th>
                    <th class="text-center">요청번호</th>
                    <th class="text-center">요청제목</th>
                    <th class="text-center">담당부서</th>
                    <th class="text-center" style="width:20%">상태</th>
                    <th class="text-center">요청날짜</th>
                  </tr>
                </thead>

                <tbody>
                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-danger">법률자문</span>
                    </td>
                    <td class="text-center">2019-09-001</td>
                    <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                    <td class="text-center">지방분권지원팀</td>
                    <td class="text-center">
                      <div class="progress progress-xl">
                        <div
                          class="progress-bar bg-pink"
                          role="progressbar"
                          style="width: 30%;"
                          aria-valuenow="30"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >요청중</div>
                      </div>
                    </td>
                    <td class="text-center">7/15</td>
                  </tr>

                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-warning">입안검토</span>
                    </td>
                    <td class="text-center">2019-09-001</td>
                    <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                    <td class="text-center">지방분권지원팀</td>
                    <td class="text-center">
                      <div class="progress progress-xl">
                        <div
                          class="progress-bar bg-pink"
                          role="progressbar"
                          style="width: 60%;"
                          aria-valuenow="60"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >회답중</div>
                      </div>
                    </td>
                    <td class="text-center">7/12</td>
                  </tr>

                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-danger">법률자문</span>
                    </td>
                    <td class="text-center">2019-09-001</td>
                    <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                    <td class="text-center">지방분권지원팀</td>
                    <td class="text-center">
                      <div class="progress progress-xl">
                        <div
                          class="progress-bar bg-pink"
                          role="progressbar"
                          style="width: 40%;"
                          aria-valuenow="40"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >접수대기</div>
                      </div>
                    </td>
                    <td class="text-center">7/10</td>
                  </tr>

                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-secondary">입법조사</span>
                    </td>
                    <td class="text-center">2019-09-001</td>
                    <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                    <td class="text-center">지방분권지원팀</td>
                    <td class="text-center">
                      <div class="progress progress-xl">
                        <div
                          class="progress-bar bg-pink"
                          role="progressbar"
                          style="width: 80%;"
                          aria-valuenow="80"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >결재중</div>
                      </div>
                    </td>
                    <td class="text-center">7/09</td>
                  </tr>

                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-success">전문정보</span>
                    </td>
                    <td class="text-center">2019-09-001</td>
                    <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                    <td class="text-center">지방분권지원팀</td>
                    <td class="text-center">
                      <div class="progress progress-xl">
                        <div
                          class="progress-bar bg-pink"
                          role="progressbar"
                          style="width: 100%;"
                          aria-valuenow="100"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >회답완료</div>
                      </div>
                    </td>
                    <td class="text-center">7/05</td>
                  </tr>

                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-success">전문정보</span>
                    </td>
                    <td class="text-center">2019-09-001</td>
                    <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                    <td class="text-center">지방분권지원팀</td>
                    <td class="text-center">
                      <div class="progress progress-xl">
                        <div
                          class="progress-bar bg-pink"
                          role="progressbar"
                          style="width: 80%;"
                          aria-valuenow="80"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >결재중</div>
                      </div>
                    </td>
                    <td class="text-center">7/03</td>
                  </tr>

                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-secondary">입법조사</span>
                    </td>
                    <td class="text-center">2019-09-001</td>
                    <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                    <td class="text-center">지방분권지원팀</td>
                    <td class="text-center">
                      <div class="progress progress-xl">
                        <div
                          class="progress-bar bg-pink"
                          role="progressbar"
                          style="width: 100%;"
                          aria-valuenow="100"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >회답완료</div>
                      </div>
                    </td>
                    <td class="text-center">6/28</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- /.form-group -->
          </div>
          <!-- /.portlet-body -->
        </div>
        <!-- /.portlet -->
      </fieldset>
    </form>

    <br class="xs-60" />
  </div>
  <!-- /.container -->
</template>

<script>
export default {
  name: "HelloWorld",
  props: {
    msg: String
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}

.portlet-table .dataTables_filter,
.portlet-table .dataTables_length {
  padding-top: 13px;
  padding-bottom: 10px;
}
.portlet-table .dataTables_filter,
.portlet-table .dataTables_paginate {
  float: right;
  padding-right: 20px;
}
div.dataTables_filter {
  text-align: right;
}
</style>
