<template>
  <div class="container">
    <div class="page-header">
      <h3 class="page-title">입법정책조사·분석 요청서</h3>

      <ol class="breadcrumb">
        <li>
          <a href="https://jumpstartthemes.com/demo/v/3.0.0/templates/admin-1/">서울특별시의회</a>
        </li>
        <li>
          <a
            href="https://jumpstartthemes.com/demo/v/3.0.0/templates/admin-1/form-basic.html#"
          >입법조사요청</a>
        </li>
        <li class="active">입법정책조사·분석 요청서</li>
      </ol>
    </div>
    <!-- /.page-header -->

    <form
      class="form-horizontal"
      action="https://jumpstartthemes.com/demo/v/3.0.0/templates/admin-1/form-basic.html#"
    >
      <fieldset class>
        <div class="portlet portlet-boxed">
          <!-- <div class="portlet-header">
            <h4 class="portlet-title">입법정책조사·분석 요청서</h4>
          </div> -->
          <!-- /.portlet-header -->

          <div class="portlet-body">
            <p class></p>

            <div class="form-group">
              <label class="control-label col-md-2">1. 회답수신인</label>
              <div class="col-md-10">
                <select name="select" class="form-control">
                  <option value="opt1">회답수신인 추가</option>
                  <option value="opt2">회답수신인 1</option>
                  <option value="opt3">회답수신인 3</option>
                  <option value="opt4">회답수신인 4</option>
                  <option value="opt5">회답수신인 5</option>
                  <option value="opt6">회답수신인 6</option>
                  <option value="opt7">회답수신인 7</option>
                </select>
                <!--              </div>

              <div class="col-md-10">
                -->

                <p class="text-muted"></p>

                <div class="table-responsive">
<!--
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>성명</th>
                        <th>휴대전화</th>
                        <th>이메일</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">1</th>
                        <td>김서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td>이서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                      <tr>
                        <th scope="row">3</th>
                        <td>박서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                    </tbody>
                  </table>

                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>성명</th>
                        <th>휴대전화</th>
                        <th>이메일</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">1</th>
                        <td>김서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td>이서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                      <tr>
                        <th scope="row">3</th>
                        <td>박서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                    </tbody>
                  </table>
-->
                  <table class="table m-0 table-colored-bordered table-bordered-dark">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>성명</th>
                        <th>휴대전화</th>
                        <th>이메일</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">1</th>
                        <td>김서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td>이서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                      <tr>
                        <th scope="row">3</th>
                        <td>박서울</td>
                        <td>010-2222-1234</td>
                        <td>abcd@naver.com</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <!--
                <thead>
                  <tr role="row">
                    <th
                      class="sorting_asc"
                      tabindex="0"
                      aria-controls="datatable"
                      rowspan="1"
                      colspan="1"
                      style="width: 166.4px;"
                      aria-sort="ascending"
                      aria-label="Name: activate to sort column descending"
                    >이름</th>
                    <th
                      class="sorting"
                      tabindex="0"
                      aria-controls="datatable"
                      rowspan="1"
                      colspan="1"
                      style="width: 251.4px;"
                      aria-label="Position: activate to sort column ascending"
                    >휴대전화</th>
                    <th
                      class="sorting"
                      tabindex="0"
                      aria-controls="datatable"
                      rowspan="1"
                      colspan="1"
                      style="width: 121.4px;"
                      aria-label="Office: activate to sort column ascending"
                    >이메일</th>
                    <th
                      class="sorting"
                      tabindex="0"
                      aria-controls="datatable"
                      rowspan="1"
                      colspan="1"
                      style="width: 54.4px;"
                      aria-label="Age: activate to sort column ascending"
                    >선택</th>
                  </tr>
                </thead>
                <tbody>
                  <tr role="row" class="odd">
                    <td tabindex="0" class="sorting_1">김서울</td>
                    <td>010-2222-1234</td>
                    <td>abcd@naver.com</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr role="row" class="odd">
                    <td tabindex="0" class="sorting_1">김서울</td>
                    <td>010-2222-1234</td>
                    <td>abcd@naver.com</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr role="row" class="odd">
                    <td tabindex="0" class="sorting_1">김서울</td>
                    <td>010-2222-1234</td>
                    <td>abcd@naver.com</td>
                    <td>삭제</td>
                  </tr>
                </tbody>
                -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.form-group -->

            <div class="form-group">
              <label class="control-label col-md-2">2. 알림 설정</label>
              <div data-v-702f6ebe class="col-md-10">
                <label data-v-702f6ebe class="checkbox-inline">
                  <input data-v-702f6ebe type="checkbox" checked="checked" name="checkbox-set-2" />
                  SMS
                </label>
                <label data-v-702f6ebe class="checkbox-inline">
                  <input data-v-702f6ebe type="checkbox" name="checkbox-set-2" />
                  이메일
                </label>
                <label data-v-702f6ebe class="checkbox-inline">
                  <input data-v-702f6ebe type="checkbox" name="checkbox-set-2" />
                  받지않음
                </label>
              </div>
            </div>
            <!-- /.form-group -->

            <div class="form-group">
              <label class="control-label col-md-2">3. 요청 제목</label>

              <div class="col-md-10">
                <input type="text" class="form-control" placeholder="입력하세요" />
              </div>
              <!-- /.col -->
            </div>
            <!-- /.form-group -->

            <div class="form-group">
              <label class="control-label col-md-2">4. 요청 내용</label>
              <div class="col-md-10">
                <textarea rows="5" cols="5" class="form-control" placeholder="내용을 입력하세요"></textarea>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.form-group -->

            <div class="form-group">
              <label class="control-label col-md-2">
                5. 요청 사항
                <br />[중복체크 가능]
              </label>
              <div data-v-702f6ebe class="col-md-10">
                <label data-v-702f6ebe class="checkbox-inline">
                  <input data-v-702f6ebe type="checkbox" checked="checked" name="checkbox-set-2" />
                  시정질의, 행정사무 감사 활용 자료
                </label>
                <label data-v-702f6ebe class="checkbox-inline">
                  <input data-v-702f6ebe type="checkbox" name="checkbox-set-2" />
                  시정부의 행정상 개선 요구사항
                </label>
                <label data-v-702f6ebe class="checkbox-inline">
                  <input data-v-702f6ebe type="checkbox" name="checkbox-set-2" />
                  입법정책 관련 국내 및 해외 살례 등
                </label>
                <label data-v-702f6ebe class="checkbox-inline">
                  <input data-v-702f6ebe type="checkbox" name="checkbox-set-2" />
                  입법정책 관련 통계자료
                </label>
              </div>
            </div>
            <!-- /.form-group -->

            <div class="form-group">
              <label class="control-label col-md-2">6. 첨부파일</label>
              <div class="col-md-10">
                <input type="file" class="form-control" />
              </div>
            </div>
            <!-- /.form-group -->
          </div>
          <!-- /.portlet-body -->
        </div>
        <!-- /.portlet -->
      </fieldset>
    </form>

    <br class="xs-60" />
  </div>
  <!-- /.container -->
</template>

<script>
export default {
  name: "HelloWorld",
  props: {
    msg: String
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
