<template>
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <div class="icon-stat" style="background-color:#ffb300;">
          <div class="row">
            <div class="col-xs-8 text-left">
              <span class="icon-stat-label" style="color:#fff">요청중</span>
              <!-- /.icon-stat-label -->
              <span class="icon-stat-value" style="color:#fff">5건</span>
              <!-- /.icon-stat-value -->
            </div>
            <!-- /.col-xs-8 -->

            <div class="col-xs-4 text-center">
              <!-- <i class="fa fa-dollar icon-stat-visual bg-primary"></i> -->
              <!-- /.icon-stat-visual -->
            </div>
            <!-- /.col-xs-4 -->
          </div>
          <!-- /.row -->

          <div class="icon-stat-footer">
            <!--            <i class="fa fa-clock-o"></i> -->
          </div>
        </div>
        <!-- /.icon-stat -->
      </div>
      <!-- /.col-md-3 -->

      <div class="col-md-3 col-sm-6">
        <div class="icon-stat" style="background-color:#03a9f4;">
          <div class="row">
            <div class="col-xs-8 text-left">
              <span class="icon-stat-label" style="color:#fff">회답중</span>
              <!-- /.icon-stat-label -->
              <span class="icon-stat-value" style="color:#fff">6건</span>
              <!-- /.icon-stat-value -->
            </div>
            <!-- /.col-xs-8 -->

            <div class="col-xs-4 text-center">
              <!-- <i class="fa fa-gift icon-stat-visual bg-secondary"></i> -->
              <!-- /.icon-stat-visual -->
            </div>
            <!-- /.col-xs-4 -->
          </div>
          <!-- /.row -->

          <div class="icon-stat-footer">
            <!--            <i class="fa fa-clock-o"></i> Updated Now    -->
          </div>
        </div>
        <!-- /.icon-stat -->
      </div>
      <!-- /.col-md-3 -->

      <div class="col-md-3 col-sm-6">
        <div class="icon-stat" style="background-color:#8bc34a;">
          <div class="row">
            <div class="col-xs-8 text-left">
              <span class="icon-stat-label" style="color:#fff">회답완료</span>
              <!-- /.icon-stat-label -->
              <span class="icon-stat-value" style="color:#fff">11건</span>
              <!-- /.icon-stat-value -->
            </div>
            <!-- /.col-xs-8 -->

            <div class="col-xs-4 text-center">
              <!-- <i class="fa fa-exchange icon-stat-visual bg-tertiary"></i> -->
              <!-- /.icon-stat-visual -->
            </div>
            <!-- /.col-xs-4 -->
          </div>
          <!-- /.row -->

          <div class="icon-stat-footer">
            <!--            <i class="fa fa-clock-o"></i> Updated Now    -->
          </div>
        </div>
        <!-- /.icon-stat -->
      </div>
      <!-- /.col-md-3 -->

      <div class="col-md-3 col-sm-6">
        <div class="icon-stat" style="background-color:#ab47bc;">
          <div class="row">
            <div class="col-xs-8 text-left">
              <span class="icon-stat-label" style="color:#fff">챠트</span>
              <!-- /.icon-stat-label -->
              <span class="icon-stat-value">&nbsp;</span>
              <!-- /.icon-stat-value -->
            </div>
            <!-- /.col-xs-8 -->

            <div class="col-xs-4 text-center">
              <!-- <i class="fa fa-envelope-o icon-stat-visual bg-default"></i> -->
              <!-- /.icon-stat-visual -->
            </div>
            <!-- /.col-xs-4 -->
          </div>
          <!-- /.row -->

          <div class="icon-stat-footer">
            <!--            <i class="fa fa-clock-o"></i> Updated Now    -->
          </div>
        </div>
        <!-- /.icon-stat -->
      </div>
      <!-- /.col-md-3 -->
    </div>
    <!-- /.row -->

    <div class="row">
      <div class="col-md-9">
        <div class="portlet portlet-boxed">
          <!-- <div class="portlet-header">
            <h4 class="portlet-title">요청 진행 현황</h4>
          </div>-->
          <!-- /.portlet-header -->          
          <div class="portlet-body">
            <table class="table">
              <thead>
                <tr>
                  <th class="text-center">분류</th>
                  <th class="text-center">제목</th>
                  <th class="text-center" style="width:20%">상태</th>
                  <th class="text-center">요청날짜</th>
                </tr>
              </thead>

              <tbody>
                <tr>
                  <td class="text-center">
                    <span data-v-109177d0 class="label label-danger">법률자문</span>
                  </td>
                  <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                  <td class="text-center">
                    <div class="progress progress-xl">
                      <div
                        class="progress-bar bg-pink"
                        role="progressbar"
                        style="width: 30%;"
                        aria-valuenow="30"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      >요청중</div>
                    </div>
                  </td>
                  <td class="text-center">7/15</td>
                </tr>

                <tr>
                  <td class="text-center">
                    <span data-v-109177d0 class="label label-warning">입안검토</span>
                  </td>
                  <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                  <td class="text-center">
                    <div class="progress progress-xl">
                      <div
                        class="progress-bar bg-pink"
                        role="progressbar"
                        style="width: 60%;"
                        aria-valuenow="60"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      >회답중</div>
                    </div>
                  </td>
                  <td class="text-center">7/12</td>
                </tr>

                <tr>
                  <td class="text-center">
                    <span data-v-109177d0 class="label label-danger">법률자문</span>
                  </td>
                  <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                  <td class="text-center">
                    <div class="progress progress-xl">
                      <div
                        class="progress-bar bg-pink"
                        role="progressbar"
                        style="width: 40%;"
                        aria-valuenow="40"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      >접수대기</div>
                    </div>
                  </td>
                  <td class="text-center">7/10</td>
                </tr>

                <tr>
                  <td class="text-center">
                    <span data-v-109177d0 class="label label-secondary">입법조사</span>
                  </td>
                  <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                  <td class="text-center">
                    <div class="progress progress-xl">
                      <div
                        class="progress-bar bg-pink"
                        role="progressbar"
                        style="width: 80%;"
                        aria-valuenow="80"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      >결재중</div>
                    </div>
                  </td>
                  <td class="text-center">7/09</td>
                </tr>

                <tr>
                  <td class="text-center">
                    <span data-v-109177d0 class="label label-success">전문정보</span>
                  </td>
                  <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                  <td class="text-center">
                    <div class="progress progress-xl">
                      <div
                        class="progress-bar bg-pink"
                        role="progressbar"
                        style="width: 100%;"
                        aria-valuenow="100"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      >회답완료</div>
                    </div>
                  </td>
                  <td class="text-center">7/05</td>
                </tr>

                <tr>
                  <td class="text-center">
                    <span data-v-109177d0 class="label label-success">전문정보</span>
                  </td>
                  <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                  <td class="text-center">
                    <div class="progress progress-xl">
                      <div
                        class="progress-bar bg-pink"
                        role="progressbar"
                        style="width: 80%;"
                        aria-valuenow="80"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      >결재중</div>
                    </div>
                  </td>
                  <td class="text-center">7/03</td>
                </tr>

                <tr>
                  <td class="text-center">
                    <span data-v-109177d0 class="label label-secondary">입법조사</span>
                  </td>
                  <td class="text-left">재난 및 안전관리 기본 조례에 관한 건</td>
                  <td class="text-center">
                    <div class="progress progress-xl">
                      <div
                        class="progress-bar bg-pink"
                        role="progressbar"
                        style="width: 100%;"
                        aria-valuenow="100"
                        aria-valuemin="0"
                        aria-valuemax="100"
                      >회답완료</div>
                    </div>
                  </td>
                  <td class="text-center">6/28</td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- /.portlet-body -->
        </div>
        <!-- /.portlet -->
      </div>
      <!-- /.col -->

      <div class="col-md-3 col-sm-5">
        <div class="portlet portlet-boxed">
          <div class="portlet-header">
            <h4 class="portlet-title">공지사항</h4>
          </div>
          <!-- /.portlet-header -->

          <div class="portlet-body">
            <table class="table keyvalue-table">
              <tbody>
                <tr>
                  <td class="kv-key">입법조사회답시스템 정기점검 일정 안내</td>
                  <td class="text-right" style="width:70px">07-15</td>
                </tr>
                <tr>
                  <td class="kv-key">2019년도 주요시책사업 분석 의견 ...</td>
                  <td class="text-right">07-14</td>
                </tr>
                <tr>
                  <td class="kv-key">서울시 건강생태계 구축현황과....</td>
                  <td class="text-right">07-10</td>
                </tr>
                <tr>
                  <td class="kv-key">2019년 상반기 서울시의회</td>
                  <td class="text-right">07-08</td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- /.portlet-body -->
        </div>
        <!-- /.portlet -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container -->
</template>

<script>
export default {
  props: {
    msg: String
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
