<template>
  <div class="tabs-container">
    <ul
      class="nav nav-tabs"
      role="tablist"
    >
      <li
        v-for="(tab, index) in tabList"
        :key="index"
        v-bind="tab.dataAttrs"
        @click="select(index)"
      >
        <a
          class="nav-link"
          data-toggle="tab"          
          :class="{'active show': isActive(index), 'disabled': tab.isDisabled}"          
        >
          {{ tab.title }}</a>
      </li>

    </ul>
    <div class="tab-content">
      <slot></slot>
    </div>

  </div>
</template>

<script>
export default {
  name: 'v-tabs',
  data() {
    return {
      tabList: [],
      activeTabIndex: 0
    };
  },
  mounted() {
    this.select(0);
    this.activeTabIndex = this.getInitialActiveTab();
    this.$root.$on('select-tab', index => this.select(index));
  },
  methods: {
    isActive(index) {
      return this.activeTabIndex === index;
    },
    select(index) {
      const tab = this.tabList[index];
      if (!tab.isDisabled) {
        this.activeTabIndex = index;
      }
      this.$emit('changed', tab);
    },
    getInitialActiveTab() {
      const index = this.tabList.findIndex(tab => tab.active);
      return index === -1 ? 0 : index;
    }
  }
};
</script>
