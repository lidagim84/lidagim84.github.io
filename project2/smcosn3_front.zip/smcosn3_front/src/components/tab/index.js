import VTabs from './Tabs';
import VTab from './Tab';

export { VTabs, VTab };
