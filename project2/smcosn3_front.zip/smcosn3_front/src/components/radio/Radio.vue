<template>
  <label class="v-radio-wrapper" style="display: inline-block;">
    <span :class="radioClasses">
      <input class="v-radio-input" type="radio" :value="value" v-model="model" @change="change" />

      <span class="v-radio-inner"></span>
    </span>
    <slot v-if="showSlot">
      <label :for="value">{{ label }}</label>
    </slot>
  </label>
</template>

<script>
import utils from "../table/mixins/utils.js";

export default {
  name: "v-radio",
  props: {
    value: {
      type: String,
      default: ""
    },
    defaultValue: {
      type: String,
      default: ""
    },
    label: {
      type: String,
      default: ""
    },
    disabled: Boolean,
    // partial selection effect
    indeterminate: Boolean,
    showSlot: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      model: false,
      _radioGroup: {},
      useYn: false
    };
  },

  computed: {
    radioClasses() {
      return [
        "v-radio",
        {
          ["v-radio-checked"]: this.model,
          ["v-radio-disabled"]: this.disabled,
          ["v-radio-indeterminate"]: this.indeterminate
        }
      ];
    },
    isRadioGroup() {
      this._radioGroup = utils.getParentCompByName(this, "v-radio-group");
      return this._radioGroup ? true : false;
    },
    displayType() {
      var style = "inline-block";
      if (this._radioGroup) {
        style = this._radioGroup.isVerticalShow ? "block" : "inline-block";
      }
      return style;
    }
  },

  methods: {
    change(event) {
      const checked = event.target.checked;
      this.$emit("input", event.target.value);
      if (this.isRadioGroup) {
        this._radioGroup.updateModel(event.target.value, checked);
      }
    },
    updateModelByGroup(checkBoxGroup) {
      if (checkBoxGroup == this.value) {
        this.model = this.value;
      } else {
        this.model = false;
      }
    }
  },
  created() {
    if (this.defaultValue == this.value) {
      this.model = this.defaultValue;
    }
  },
  watch: {
    value(val) {
      this.updateModelByGroup(val);
    }
  }
};
</script>

<style>
/* [type='radio']:checked,
[type='radio']:not(:checked) {
  position: absolute;
  left: -9999px;
}
[type='radio']:checked + label,
[type='radio']:not(:checked) + label {  
  position: relative;
  padding-left: 20px;
  padding-right: 10px;
  cursor: pointer;
  line-height: 20px;
  display: inline-block;
  color: #666;
}
[type='radio']:checked + label:before,
[type='radio']:not(:checked) + label:before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  width: 16px;
  height: 16px;
  border: 1px solid #ddd;
  border-radius: 100%;
  background: #fff;
}
[type='radio']:checked + label:after,
[type='radio']:not(:checked) + label:after {
  content: '';
  width: 12px;
  height: 12px;
  background: #108ee9;
  position: absolute;
  top: 2px;
  left: 2px;
  border-radius: 100%;
  -webkit-transition: all 0.2s ease;
  transition: all 0.2s ease;
}
[type='radio']:not(:checked) + label:after {
  opacity: 0;
  -webkit-transform: scale(0);
  transform: scale(0);
}
[type='radio']:checked + label:after {
  opacity: 1;
  -webkit-transform: scale(1);
  transform: scale(1);
} */

.v-radio-group .input-group {
  margin-left: -32px;
}
.v-radio-group .input-group label {
  margin-left: 32px;
}

.v-radio-wrapper {
  cursor: pointer;
  font-size: 12px;
  display: inline-block;
  position: relative;
}

.v-radio {
  white-space: nowrap;
  cursor: pointer;
  outline: none;
  display: inline-block;
  line-height: 1;
  position: relative;
  vertical-align: text-bottom;
}

.v-radio-checked:after {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 2px;
  border: 1px solid #108ee9;
  content: "";
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
  visibility: hidden;
}

.v-radio-input {
  position: absolute;
  left: 0;
  z-index: 1;
  cursor: pointer;
  opacity: 0;
  filter: alpha(opacity=0);
  top: 0;
  bottom: 0;
  right: 0;
  /* width: 100%;
    height: 100%;*/
}

.v-radio-inner {
  position: relative;
  top: -5px;
  left: 0;
  display: block;
  width: 13px;
  height: 13px;
  border: 1px solid #707070;
  border-radius: 13px;
  background-color: #fff;
  -webkit-transition: all 0.3s;
  transition: all 0.3s;
}

.v-radio-inner:after {
  -webkit-transform: scale(0);
  -ms-transform: scale(0);
  transform: scale(0);
  position: absolute;
  left: 2px;
  top: 2px;
  display: table;
  width: 7px;
  height: 7px;
  background: #26a0da;
  border-radius: 100%;
  content: " ";
  -webkit-transition: all 0.1s cubic-bezier(0.71, -0.46, 0.88, 0.6);
  transition: all 0.1s cubic-bezier(0.71, -0.46, 0.88, 0.6);
}

.v-radio-checked .v-radio-inner:after {
  -webkit-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);

  content: " ";
  -webkit-transition: all 0.2s cubic-bezier(0.12, 0.4, 0.29, 1.46) 0.1s;
  transition: all 0.2s cubic-bezier(0.12, 0.4, 0.29, 1.46) 0.1s;
}

.v-radio-checked .v-radio-inner,
.v-radio-indeterminate .v-radio-inner {
  border-color: #26a0da;
}

.v-radio-input:focus + .v-radio-inner,
.v-radio-wrapper:hover .v-radio-inner,
.v-radio:hover .v-radio-inner {
  border-color: #108ee9;
}

.v-radio-disabled {
  cursor: not-allowed;
}

.v-radio-disabled.v-radio-checked .v-radio-inner:after {
  -webkit-animation-name: none;
  animation-name: none;
  border-color: rgba(0, 0, 0, 0.25);
}

.v-radio-disabled .v-radio-input {
  cursor: not-allowed;
}

.v-radio-disabled .v-radio-inner {
  border-color: #d9d9d9 !important;
  background-color: #f7f7f7;
}

.v-radio-disabled .v-radio-inner:after {
  -webkit-animation-name: none;
  animation-name: none;
  border-color: #f7f7f7;
}

.v-radio-disabled + span {
  color: rgba(0, 0, 0, 0.25);
  cursor: not-allowed;
}

.v-radio-indeterminate .v-radio-inner:after {
  content: " ";
  -webkit-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
  position: absolute;
  left: 2px;
  top: 5px;
  width: 8px;
  height: 1px;
}

.v-radio-indeterminate.v-radio-disabled .v-radio-inner:after {
  border-color: rgba(0, 0, 0, 0.25);
}

.v-select-items-multiple {
  display: table;
  width: 100%;
  padding: 5px;
}

.v-select-items-multiple span {
  vertical-align: middle;
  font-size: 14px;
  font-weight: normal;
  color: rgba(0, 0, 0, 0.65);
}

.v-select-items-multiple:hover {
  background-color: #e6f7ff;
}
</style>
