<template>
  <div class="switch">
    <div class="onoffswitch">
      <input
        type="checkbox"
        name="collapsemenu"
        checked="checked"
        v-model="selectedValue"
        :id="id"
        class="onoffswitch-checkbox"
      ><label
        class="onoffswitch-label"
        :for="id"
      ><span class="onoffswitch-inner"></span>
        <span class="onoffswitch-switch"></span></label>
    </div>
  </div>
</template>


<script>
export default {
  name: 'v-switch',
  props: {
    id: {
      type: String
    },
    value: {
      type: String,
      default: ''
    }
  },
  data: function() {
    return {
      selectedValue: this.value ? this.value : ''
    };
  },
  watch: {
    value: function(newVal, oldVal) {
      this.selectedValue = newVal;
    },
    selectedValue: function(newVal, oldVal) {
      this.$emit('input', newVal);
    }
  }
};
</script>
