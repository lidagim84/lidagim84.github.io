<template>
  <div class="v-radio-group">
    <slot></slot>
    <div class="input-group">
      <v-radio
        v-for="(item, index) in list"
        :id="'rdo-'+item[valueField]"
        :name="'rdo-'+code"
        :key="index"
        :value="item[valueField]"
        :defaultValue="value"
        @change="change"
      >{{ item[labelField] }}</v-radio>
    </div>
  </div>
</template>

<script>
import utils from "../table/mixins/utils.js";

export default {
  name: "v-radio-group",
  props: {
    value: {
      type: String,
      default: ""
    },
    isVerticalShow: {
      type: Boolean,
      default: false
    },
    options: {
      type: Array,
      default() {
        return [];
      }
    },
    labelField: {
      type: String,
      default: "label"
    },
    valueField: {
      type: String,
      default: "value"
    },
    code: {
      type: String,
      default: ""
    }
  },
  data: function() {
    return {};
  },
  methods: {
    change(event) {
      this.$emit("input", event.target.value);
    },
    updateModel(value, checkedVal) {
      this.$emit("input", value);
    },
    setValue(newVal) {
      let children = utils.getChildCompsByName(this, "v-radio");
      children.forEach(child => child.updateModelByGroup(newVal));
    }
  },
  watch: {
    value(newVal) {
      if (newVal) this.setValue(newVal);
    },
    options(newVal, oldVal) {
      this.list = newVal;
    },
    code(newVal, oldVal) {
      if (newVal) {
        this.list = this.commonCodeList(newVal);
      }
    }
  },
  created() {
    if (this.code) {
      this.list = this.commonCodeList(this.code);
    }
    if (this.value) {
      this.setValue(this.value);
    }
  }
};
</script>

<style>
.v-radio-group {
  margin-left: 5px;
  padding-top: 7px;
}
.v-radio-group .input-group [type="radio"] {
  margin: 5px 5px;
}
</style>
