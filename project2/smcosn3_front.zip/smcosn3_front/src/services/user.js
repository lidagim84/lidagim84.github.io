import HTTP from '../utils/http';

export const getUserList = params => HTTP.post('/api/user/getUserList', params);
export const getUser = params => HTTP.post('/api/user/getUser', params);
export const setUser = params => HTTP.post('/api/user/setUser', params);
export const getUserCheck = params => HTTP.post('/api/user/getUserCheck', params);
