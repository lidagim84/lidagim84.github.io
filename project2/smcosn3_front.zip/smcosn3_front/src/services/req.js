import HTTP from '../utils/http';

export const getReq = params => HTTP.post('/api/req/getReq', params);
export const getReqList = params => HTTP.post('/api/req/getReqList', params);

export const setReq = params => HTTP.post('/api/req/setReq', params);

export const deleteReq = params => HTTP.post('/api/req/deleteReq', params);
