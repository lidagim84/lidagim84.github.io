import HTTP from '../utils/http';

export const getMenuList = params =>
  HTTP.post('/api/settings/getMenuList', params);
export const getMenu = params => HTTP.post('/api/settings/getMenu', params);
export const setMenu = params => HTTP.post('/api/settings/setMenu', params);
export const deleteMenu = params =>
  HTTP.post('/api/settings/deleteMenu', params);

export const getAuthList = params =>
  HTTP.post('/api/settings/getAuthList', params);
export const getAuth = params => HTTP.post('/api/settings/getAuth', params);
export const setAuth = params => HTTP.post('/api/settings/setAuth', params);
export const deleteAuth = params =>
  HTTP.post('/api/settings/deleteAuth', params);

export const getAuthMenuGrp = params =>
  HTTP.post('/api/settings/getAuthMenuGrp', params);
export const setAuthMenuGrp = params =>
  HTTP.post('/api/settings/setAuthMenuGrp', params);

export const getAuthUserGrp = params =>
  HTTP.post('/api/settings/getAuthUserGrp', params);
export const setAuthUserGrp = params =>
  HTTP.post('/api/settings/setAuthUserGrp', params);

export const getCodeList = params =>
  HTTP.post('/api/settings/getCodeList', params);
export const setCode = params => HTTP.post('/api/settings/setCode', params);
export const deleteCode = params =>
  HTTP.post('/api/settings/deleteCode', params);
