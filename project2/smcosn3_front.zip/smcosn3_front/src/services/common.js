import HTTP from '../utils/http';
import axios from 'axios';

export const getList = [];
export const getMenuList = params => axios.get('/assets/api/menu.json');
export const getUserInfo = params =>
  HTTP.post('/api/common/getUserInfo', params);
export const getDeptList = params =>
  HTTP.post('/api/common/getDeptList', params);

export const setContentMapList = params =>
  HTTP.post('/api/common/setContentMapList', params);

export const getContentMapList = params =>
  HTTP.post('/api/common/getContentMapList', params);

export const setFileList = params =>
  HTTP.post('/api/common/setFileList', params);

export const getFileList = params =>
  HTTP.post('/api/common/getFileList', params);

export const getTaskInfo = params =>
  HTTP.post('/api/common/getTaskInfo', params);
export const setTaskInfo = params =>
  HTTP.post('/api/common/setTaskInfo', params);

export const getStaffList = params =>
  HTTP.post('/api/common/getStaffList', params);
export const setStaffList = params =>
  HTTP.post('/api/common/setStaffList', params);

export const setKeywordList = params =>
  HTTP.post('/api/common/setKeywordList', params);
export const getKeywordList = params =>
  HTTP.post('/api/common/getKeywordList', params);

export const setComment = params => HTTP.post('/api/common/setComment', params);

export const deleteComment = params =>
  HTTP.post('/api/common/deleteComment', params);

export const getCommentList = params =>
  HTTP.post('/api/common/getCommentList', params);

export const getIp = () => axios.get('https://api.ipify.org?format=json');


export const sendMessage = params =>
  HTTP.post('/api/common/sendMessage', params);

export const createExchangeXML = params =>
  HTTP.post('/api/common/createExchangeXML', params);

// export const NADB_SERVICE_KEY = process.env.VUE_APP_NADB_SERVICE_KEY;
//국회db검색
export const getNADBSearchResult = (queryMap) =>
  axios.get(
    `http://apis.data.go.kr/9735000/PublicationService/${queryMap.tableNm}List?serviceKey=${process.env.VUE_APP_NADB_SERVICE_KEY}&pageNo=${queryMap.pageNo}&numOfRows=${queryMap.pageSize}&resultType=json&div_cd=${queryMap.div_cd}&book_nm=${encodeURIComponent(queryMap.title)}`, {
    'Content-Type': 'text/plain;charset=UTF-8'
  }
  );

//data_cd 분류, data_id 키.
export const getNADBSearchDetailResult = (queryMap) =>
  axios.get(
    `http://apis.data.go.kr/9735000/PublicationService/${queryMap.tableNm}Item?serviceKey=${process.env.VUE_APP_NADB_SERVICE_KEY}&resultType=json&data_id=${queryMap.data_id}&data_cd=${queryMap.data_cd}`,
    {
      'Content-Type': 'text/plain;charset=UTF-8'
    }
  );


export const setNoti = params => HTTP.post('/api/common/setNoti', params);

export const getNotiList = params =>
  HTTP.post('/api/common/getNotiList', params);

export const uploadFile = (formData, callback) =>
  HTTP.post('/api/common/uploadFile', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: function (progressEvent) {
      callback(progressEvent);
    }.bind(this)
  });

export const fileDownload = (url, fileName) =>
  axios
    .get(`${process.env.VUE_APP_API_URL}${url}?fileName=${fileName}`, {
      responseType: 'arraybuffer'
    })
    .then(res => forceFileDownload(res, fileName))
    .catch(() => alert('파일 다운로드 에러발생'));

const forceFileDownload = (res, fileName) => {
  let blob = new Blob([res.data], { type: res.headers['content-type'] });

  if (window.navigator.msSaveOrOpenBlob) {
    // IE 10+
    window.navigator.msSaveOrOpenBlob(blob, fileName);
  } else {
    // not IE
    let link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.target = '_self';
    if (fileName) link.download = fileName;
    link.click();
  }
};


export const fileDownload2 = (url) => {
  let link = document.createElement('a');
  link.href = url;
  link.target = '_self';
  link.click();
};




