import HTTP from '../utils/http';

export const getSummaryStat = params => HTTP.post('/api/stat/getSummaryStat', params);
