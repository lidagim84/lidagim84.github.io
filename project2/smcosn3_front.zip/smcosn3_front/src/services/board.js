import HTTP from "../utils/http";

export const getBoardList = (params) =>
  HTTP.post(`/api/board/getBoardList`, params);

export const getBoardAllList = params =>
  HTTP.post("/api/board/getBoardAllList", params);
export const setBoard = params => HTTP.post("/api/board/setBoard", params);
export const getBoard = params => HTTP.post("/api/board/getBoard", params);
export const deleteBoard = params =>
  HTTP.post("/api/board/deleteBoard", params);
