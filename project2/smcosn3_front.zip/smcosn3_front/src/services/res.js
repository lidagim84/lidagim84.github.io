import HTTP from '../utils/http';

export const getRes = params => HTTP.post('/api/res/getRes', params);
export const getResList = params => HTTP.post('/api/res/getResList', params);
export const setRes = params => HTTP.post('/api/res/setRes', params);
export const deleteRes = params => HTTP.post('/api/res/deleteRes', params);

export const getResBillMatch = params => HTTP.post('/api/res/getResBillMatch', params);
export const getResBillMatchList = params => HTTP.post('/api/res/getResBillMatchList', params);
export const setReBillMatch = params => HTTP.post('/api/res/setResBillMatch', params);
export const deleteResBillMatch = params => HTTP.post('/api/res/deleteResBillMatch', params);
