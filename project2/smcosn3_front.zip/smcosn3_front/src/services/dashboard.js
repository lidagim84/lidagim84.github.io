import HTTP from '../utils/http';
import axios from 'axios';

export const getConfig = (type) => axios.get('/assets/api/config.json').then(res => {
  const data = res.data;
  return data[type];
});
export const setConfig = params => HTTP.post('/api/user/setConfig', params);
export const getCaseStat = params => HTTP.post('/api/getCaseStat', params);
export const getProbeStat = params => HTTP.post('/api/getProbeStat', params);
export const getProofStat = params => HTTP.post('/api/getProofStat', params);
export const getBizStat = params => HTTP.post('/api/getBizStat', params);
export const getEquipStat = params => HTTP.post('/api/getEquipStat', params);
export const getAnalysisStat = params =>
  HTTP.post('/api/getAnalysisStat', params);
export const getUserStatSummary = params =>
  HTTP.post('/api/getUserStatSummary', params);
export const getDeptStatSummary = params =>
  HTTP.post('/api/getDeptStatSummary', params);
