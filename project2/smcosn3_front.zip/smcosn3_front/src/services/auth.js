import HTTP from '../utils/http';

export const getAuthToken = params => HTTP.post('/api/auth/login', params);
