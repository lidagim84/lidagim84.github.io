import HTTP from '../utils/http';

export const getLogList = params => HTTP.post('/log/getLogList', params);
export const insertLog = params => HTTP.post('/log/insertLog', params);
export const setLog = params => HTTP.post('/log/setLog', params);
