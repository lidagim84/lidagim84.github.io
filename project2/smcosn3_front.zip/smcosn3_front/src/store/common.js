import * as types from './mutation-types';
import * as api from '../services';
import jwt from 'jsonwebtoken';

const state = {
  isAuthenticated: true,
  userInfo: { user_id: '', user_nm: '', auth_id: [] },
  currentMenuInfo: { menu_nm: null, router_name: null },
  menuList: [],
  rentInfo: {},
  codeList: [],
  userList: []
};


const VUE_APP_TOKEN_SECRET_KEY = process.env.VUE_APP_TOKEN_SECRET_KEY;

function decodeJwt(token) {
  return jwt.verify(token, new Buffer(VUE_APP_TOKEN_SECRET_KEY, 'base64'), {
    algorithms: ['HS512']
  });
}
const getters = {
  isAuthenticated: state => state.isAuthenticated,
  userInfo: state => state.userInfo,
  currentMenuInfo: state => state.currentMenuInfo,
  menuList: state => state.menuList,
  codeList: state => state.codeList,
  userList: state => state.userList
};

const actions = {
  login({ commit }, params) {
    return api.getAuthToken(params).then(res => {
      const data = res.data;
      let userInfo = data;
      // let decode = decodeJwt(data.token);
      // let userInfo = {
      //   user_id: decode.sub
      // };
      // localStorage.setItem("token", data.token);
      localStorage.setItem("userInfo", JSON.stringify(userInfo));
      return commit(types.GET_USERINFO, {
        userInfo: userInfo
      });
    });
  },
  logout({ commit }) {
    let loginUser = JSON.parse(localStorage.getItem('userInfo'));
    // if (loginUser) {
    //   api.getIp().then(ipifyl => {
    //     const ipInfo = ipifyl.data;
    //     api.setLog({
    //       log_type: 'login',
    //       action: 'logout',
    //       user_id: loginUser.user_id,
    //       ip: ipInfo.ip
    //     });
    //   });
    // }
    delete localStorage['token'];
    delete localStorage['userInfo'];
    delete localStorage['configInfo'];
    return commit(types.SET_IS_AUTHENTICATED, {
      isAuthenticated: false
    });
  },
  getMenuList({ commit }, params) {
    return api.getMenuList(params).then(res => {
      return commit(types.GET_MENU_LIST, {
        menuList: res.data[params.type]
      });
    });
  },
  getCodeList({ commit }, params) {
    return api.getCodeList(params).then(res => {
      localStorage.setItem('commonCodeList', JSON.stringify(res.data));
      return commit(types.GET_CODE_LIST, {
        codeList: res.data
      });
    });
  },
  getUserList({ commit }, params) {
    return api.getUserList(params).then(res => {
      localStorage.setItem('userList', JSON.stringify(res.data.list));
      return commit(types.GET_USER_LIST, {
        userList: res.data.list
      });
    });
  },
  setMenu({ commit }, params) {
    return commit(types.SET_MENU, {
      currentMenuInfo: params
    });
  },
  setAuthenticated({ commit }, params) {
    return commit(types.SET_IS_AUTHENTICATED, {
      isAuthenticated: params
    });
  }
};

const mutations = {
  [types.GET_USERINFO](state, { userInfo }) {
    state.userInfo = userInfo;
    state.isAuthenticated = true;
  },
  [types.GET_MENU_LIST](state, { menuList }) {
    state.menuList = menuList;
  },
  [types.GET_CODE_LIST](state, { codeList }) {
    state.codeList = codeList;
  },
  [types.GET_USER_LIST](state, { userList }) {
    state.userList = userList;
  },
  [types.SET_MENU](state, { currentMenuInfo }) {
    state.currentMenuInfo = currentMenuInfo;
  },
  [types.SET_IS_AUTHENTICATED](state, { isAuthenticated }) {
    state.isAuthenticated = isAuthenticated;
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};
