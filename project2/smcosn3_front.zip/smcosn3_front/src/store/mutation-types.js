export const GET_LIST = 'GET_LIST';
export const GET_USERINFO = 'GET_USERINFO';
export const GET_MENU_LIST = 'GET_MENU_LIST';
export const GET_CODE_LIST = 'GET_CODE_LIST';
export const GET_USER_LIST = 'GET_USER_LIST';
export const SET_MENU = 'SET_MENU';
export const SET_IS_AUTHENTICATED = 'SET_IS_AUTHENTICATED';
