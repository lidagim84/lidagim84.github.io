import 'es6-promise/auto';
import 'babel-polyfill';

import Vue from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';
import filter from './filter';
import base from './components/base';
import './validator';

Vue.mixin(base);
Vue.use(filter);


Vue.config.productionTip = false;

Vue.prototype.$EventBus = new Vue();

import underscore from 'vue-underscore';
Vue.use(underscore);

import { _ } from 'vue-underscore';
Vue.prototype._ = _;

import VueCookie from 'vue-cookie';
Vue.use(VueCookie);

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app');
