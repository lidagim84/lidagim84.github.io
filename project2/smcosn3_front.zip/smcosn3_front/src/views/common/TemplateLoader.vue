<template>
  <div>
    <div v-for="(template, index) in contentMaps" :key="index">
      <div class="form-group row">
        <label class="col-sm-2 control-label">
          {{template.label}}
          <span v-if="!readonly && template.required" class="required">*</span>
        </label>
        <div v-if="readonly" class="col-sm-10 wrap">{{setValue(template)}}</div>
        <div v-else class="col-sm-10">
          <input
            v-if="template.type === 'input'"
            type="text"
            :name="template.field_nm"
            v-validate="template.required ? 'required' : ''"
            class="form-control"
            v-model="template.value"
          />
          <textarea
            v-if="template.type === 'textarea'"
            :name="template.field_nm"
            v-validate="template.required ? 'required' : ''"
            class="form-control"
            v-model="template.value"
          />

          <v-checkbox-group
            v-if="template.type === 'checkbox-group'"
            :code="template.code"
            v-model="template.children"
          ></v-checkbox-group>

          <!--             
            <v-checkbox-group
              v-if="template.type === 'checkbox-group'"
              :options="[{label:'test',value:''},{label:'test',value:''}]"
              v-model="template.children"
          ></v-checkbox-group>-->
          <label
            v-if="template.required"
            class="error"
            v-show="errors.has(template.field_nm)"
          >{{ errors.first(template.field_nm) }}</label>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { setContentMapList, getContentMapList } from "../../services";

export default {
  name: "template-loader",
  props: {
    req_type: {
      type: String,
      default: "pl_sppt",
      required: true
    },
    task_id: {
      type: String,
      default: ""
    },
    value: {
      type: Array,
      default: function() {
        return [];
      }
    },
    enabled: {
      type: Boolean,
      default: true
    },
    readonly: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      contentMaps: []
    };
  },
  watch: {
    $route(to, from) {
      if (!to.query.req_no) {
        this.init();
      }
    },
    task_id(val) {
      if (val) this.getContentMapList();
    },
    req_type(val) {
      if (val) this.init();
    }
  },
  computed: {},
  methods: {
    setValue(template) {
      if (template.children && template.children.length) {
        return this.commonCodeList("req_map")
          .filter(
            item => template.children.filter(code => code == item.value).length
          )
          .map(code => code.label)
          .join("\r\n");
      } else {
        return template.value;
      }
    },
    setContentMapList(taskId) {
      let params = [];
      for (let map of this.contentMaps) {
        let param = {
          task_id: taskId,
          field_nm: map.field_nm,
          parent_field_nm: this.req_type,
          value: map.value
        };
        if (map.children && map.children.length) {
          param.children = map.children.map(val => {
            return {
              task_id: taskId,
              field_nm: val,
              parent_field_nm: map.field_nm,
              value: val
            };
          });
        }
        params.push(param);
      }

      return setContentMapList(params).then(res => {
        return res.data;
      });
    },
    getContentMapList() {
      return getContentMapList({
        task_id: this.task_id,
        parent_field_nm: this.req_type
      }).then(res => {
        const data = res.data;
        if (data && data.length) {
          this.contentMaps.map(map => {
            let item = data.filter(item => item.field_nm == map.field_nm)[0];
            if (item) {
              map.value = item.value;
              map.children = item.children.map(c => c.field_nm);
            }
            return map;
          });
        }
      });
    },
    init() {
      const template = this.constants.ReqTemplate[this.req_type];
      if (template && template.length) {
        this.contentMaps = template.map(map => {
          map.value = "";
          map.children = [];
          return map;
        });
      }
    }
  },
  created() {
    this.init();
    if (this.task_id) {
      this.getContentMapList();
    }
  }
};
</script>

<style>
.wizard > .content {
  height: auto !important;
  min-height: inherit !important;
}
.wrap {
  white-space: pre-wrap;
}
</style>
