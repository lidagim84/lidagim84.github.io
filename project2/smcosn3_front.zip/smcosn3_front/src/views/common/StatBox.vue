<template>
  <div class="stat-box">
    <div class="stat1" @click="filter()">
      <span class="inner">
        전체
        <span class="number">{{stat.TOTAL}}</span>건
      </span>
    </div>
    <div class="stat2" @click="filter('request_wait')">
      <span class="inner">
        접수대기
        <span class="number">{{stat.REQUEST_WAIT}}</span>건
      </span>
    </div>
    <div class="stat3" @click="filter('res')">
      <span class="inner">
        회답중
        <span class="number">{{stat.RES}}</span>건
      </span>
    </div>
    <div class="stat4" @click="filter('complete')">
      <span class="inner">
        회답완료
        <span class="number">{{stat.COMPLETE}}</span>건
      </span>
    </div>
    <div class="stat5" @click="filter('hold_retract')">
      <span class="inner">
        보류·철회
        <span class="number">{{stat.HOLD_RETRACT}}</span>건
      </span>
    </div>
  </div>
</template>

<script>
export default {
  name: "stat-box",
  props: {
    req_type: {
      type: String,
      default: ""
    }
  },
  data: function() {
    return {
      stat: {
        TOTAL: 0,
        REQUEST: 0,
        WAIT: 0,
        RES: 0,
        HOLD: 0,
        COMPLETE: 0,
        RETRACT: 0,
        REQUEST_WAIT: 0,
        HOLD_RETRACT: 0
      }
    };
  },
  methods: {
    filter(filterItem) {
      this.$emit("filter", filterItem);
    }
  },
  created() {
    this.getSummaryStat().then(res => {
      this.stat = res;
    });
  }
};
</script>
