<template>
  <div>
    <div
      class="social-comment"
      v-for="(item, index) of commentList"
      :key="index"
    >
      <div
        v-if="item.Modify"
        class="media-body"
      >
        <textarea
          class="form-control"
          placeholder="Write comment..."
          v-model="item.comment"
          v-on:keyup.13="setComment(item.comment, item.parent_id, item.id).then(res=> setState(res, 'Modify', false))"
          v-on:keyup.esc="setState(item, 'Modify', !item.Modify)"
        ></textarea>
      </div>
      <div
        v-if="!item.Modify"
        class="media-body"
      >
        <a href="#">{{item.create_user_nm}}</a> {{item.comment}} 
        <small v-if="item.create_user_idx==loginUserInfo.user_id" class="text-muted orangered"><a @click="setState(item, 'Modify', !item.Modify)">수정</a>&nbsp;<a @click="deleteComment(item)">삭제</a></small>
        <br>
        <small class="text-muted">{{item.create_date_time}} <a @click="setState(item, 'Reply', !item.Reply)">댓글</a></small>
      </div>

      <div
        class="social-comment"
        v-for="(child, c_index) of item.children"
        :key="c_index"
      >
        <div
          v-if="child.Modify"
          class="media-body"
        >
          <textarea
            class="form-control"
            placeholder="Write comment..."
            v-model="child.comment"
            v-on:keyup.13="setComment(comment, child.parend_id, child.id)"
            v-on:keyup.esc="setState(child, 'Modify', !child.Modify)"
          ></textarea>
        </div>
        <div
          v-if="!child.Modify"
          class="media-body"
        >
          <a href="#">{{child.create_user_nm}}</a> {{child.comment}} 
          <small v-if="child.create_user_idx==loginUserInfo.user_id" class="text-muted orangered"><a @click="setState(child, 'Modify', !child.Modify)">수정</a>&nbsp;<a @click="deleteComment(child)">삭제</a></small>
          <br>
          <small class="text-muted">{{child.create_date_time}}</small>
        </div>

      </div>

      <div
        class="social-comment"
        v-if="item.Reply"
      >
        <div class="media-body">
          <textarea
            class="form-control"
            placeholder="Write comment..."
            v-model="replyComment"
            v-on:keyup.13="setComment(replyComment, item.id, !item.Reply)"
          ></textarea>
        </div>
      </div>

    </div>
    <div class="social-comment">
      <div class="media-body">
        <textarea
          class="form-control"
          placeholder="Write comment..."
          v-model="comment"
          v-on:keyup.13="setComment(comment, 0)"
        ></textarea>
      </div>
    </div>
  </div>
</template>

<script>
import { getCommentList, setComment, deleteComment } from '../../services';
import { defer } from 'q';
export default {
  name: 'comment',
  props: {
    job_id: {
      type: String,
      default: ''
    },
    task_id: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      commentList: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      commentInfo: {
        id: '',
        parent_id: '',
        comment: '',
        task_id: this.task_id
      },
      replyComment: '',
      comment: ''
    };
  },
  watch: {
    task_id(newVal) {
      this.commentInfo.task_id = newVal;
      this.getCommentList();
    }
  },
  computed: {},
  methods: {
    getCommentList() {
      return getCommentList({
        task_id: this.task_id,
        page_index: this.pageIndex,
        page_size: this.pageSize
      }).then(res => {
        this.commentList = res.data;
      });
    },
    setComment(comment, parentId, id) {
      if(!comment.trim()) {
        return false;
      }
      this.commentInfo.comment = comment;
      this.commentInfo.parent_id = parentId;
      if (id) {
        this.commentInfo.id = id;
      }
      return setComment(this.commentInfo).then(res => {
        if (!id) {
          res.data.create_user_nm = this.loginUserInfo.user_nm;
          res.data.create_user_idx = this.loginUserInfo.user_id;
          if (parentId == 0) {
            this.commentList.push(res.data);
            this.comment = '';
          } else {
            this.commentList
              .filter(item => item.id == parentId)[0]
              .children.push(res.data);
            this.replyComment = '';
          }
        }
        return res.data;
      });
    },
    deleteComment(item) {
      item.task_id = this.task_id;
      return deleteComment(item).then(res => {
        if (item.parent_id == 0) {
          this.commentList = this.commentList.filter(
            comment => comment.id != item.id
          );
        } else {
          this.commentList = this.commentList.filter(comment => {
            if (comment.id == item.parent_id) {
              comment.children = comment.children.filter(
                comment => comment.id != item.id
              );
            }
            return comment;
          });
        }
      });
    },
    setState(item, state, value) {
      if (item.parent_id == 0) {
        this.commentList = this.commentList.map(comment => {
          if (item.id == comment.id) {
            comment[state] = value;
          }
          return comment;
        });
      } else {
        this.commentList = this.commentList.map(comment => {
          if (comment.id == item.parent_id) {
            comment.children.map(child => {
              if (item.id == child.id) {
                comment[state] = value;
              }
              return child;
            });
          }
          return comment;
        });
      }
    }
  },
  created() {
    // this.getCommentList();
  }
};
</script>

<style>
.text-muted.orangered {
  color: orangered !important;
}
</style>
