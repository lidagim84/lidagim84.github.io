<template>
  <div>
    <div class="tit-group">
      <h3 class="title">
        {{title}}을 선택해 주세요.
        <span class="text-warning">[선택사항 입니다.]</span>
      </h3>
      <div class="append" v-if="enabled">
        <button
          class="btn-strong"
          type="button"
          @click="addMng(true, null, staffData).then(res => {staffData = [...staffData, ...res]})"
        >
          <i class="fa fa-plus"></i> 추가
        </button>
        <button class="btn-normal" type="button" @click="delMng">
          <i class="fa fa-minus"></i> 삭제
        </button>
      </div>
    </div>
    <!--
      <div class="list-btn-group" v-if="enabled">
        <div class="float-right">
            <button
            class="btn-strong"
            type="button"
            @click="addMng(true, null, staffData).then(res => {staffData = [...staffData, ...res]})"
          >
            <i class="fa fa-plus"></i> 추가
          </button>
          <button class="btn-normal" type="button" @click="delMng">
            <i class="fa fa-minus"></i> 삭제
          </button>
        </div>
      </div>
    -->
    <v-table
      is-horizontal-resize
      style="width:100%"
      :height="(staffData.length+1)*constants.RowHeight"
      :columns="columns"
      :table-data="staffData"
      :select-change="selectChange"
      :select-all="selectList"
    ></v-table>
  </div>
</template>


<script>
import { getStaffList, setStaffList } from "../../services/common";

export default {
  name: "SelectionStaffList",
  props: {
    title: {
      type: String,
      default: "사용자"
    },
    job_id: {
      type: String,
      default: "",
      required: true
    },
    task_id: {
      type: String,
      default: "",
      required: true
    },
    user_type: {
      type: String,
      default: "",
      required: true
    },
    value: {
      type: Array,
      default: function() {
        return [];
      }
    },
    enabled: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      staffData: [],
      selectionDatas: [],
      columns: [
        {
          width: 60,
          titleAlign: "center",
          columnAlign: "center",
          type: "selection"
        },
        {
          field: "user_nm",
          title: "이름",
          width: 100,
          titleAlign: "center",
          columnAlign: "center",
          isResize: true
        },
        {
          field: "dept_nm",
          title: "상임위",
          width: 100,
          titleAlign: "center",
          columnAlign: "center",
          isResize: true
        },
        // {
        //   field: "phone_no",
        //   title: "전화번호",
        //   width: 100,
        //   titleAlign: "center",
        //   columnAlign: "center",
        //   isResize: true
        // },
        // {
        //   field: "email",
        //   title: "이메일",
        //   width: 100,
        //   titleAlign: "center",
        //   columnAlign: "left",
        //   isResize: true
        // }
      ]
    };
  },
  watch: {
    task_id() {
      if (this.task_id) {
        this.getStaffList();
      }
    }
  },
  computed: {},
  methods: {
    setStaffList(taskId) {
      if (!this.staffData.length) {
        return Promise.resolve(false);
      }
      this.staffData.map(m => {
        m.job_id = this.job_id;
        m.task_id = taskId;
        m.user_type = this.user_type;
        return m;
      });
      return setStaffList(this.staffData);
    },
    getStaffList() {
      return getStaffList({
        job_id: this.job_id,
        task_id: this.task_id,
        user_type: this.user_type
      }).then(res => {
        return (this.staffData = res.data);
      });
    },
    delMng() {
      this.staffData = this.staffData.filter(
        item =>
          !this.selectionDatas.filter(user => item.user_id == user.user_id)
            .length
      );
    },
    selectChange(selection, rowData) {
      this.selectionDatas = selection;
    },
    selectList(selection) {
      this.selectionDatas = selection;
    }
  },
  created() {
    if (this.task_id) {
      this.getStaffList();
    }
  }
};
</script>

<style>
.wizard > .content {
  height: auto !important;
  min-height: inherit !important;
}
</style>
