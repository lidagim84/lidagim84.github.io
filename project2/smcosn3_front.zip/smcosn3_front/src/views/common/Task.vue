<template>
  <div>
    <!-- <slot></slot> -->
    <template v-if="showMemo">
      <div class="tit-group">
        <h3 class="title">{{etcTitle}}</h3>
      </div>
      <div class="control-box">
        <textarea class="form-control" style="height: 100px" v-model="taskInfo.etc" maxlength="500"></textarea>
      </div>
    </template>
    <!-- 담당팀재배정> 접수대기 > 팀장 -->
    <!-- 조사관배정 > 접수대기 > 팀장 > 담당 팀만 수정.-->
    <div class="list-btn-group group-submit">
      <div class="float-left">
        <button type="button" class="btn-strong" @click="$router.go(-1)">목록으로</button>
      </div>
      <div class="float-right">
        <!-- 신규 > 요청자 -->
        <!-- 요청등록 > 알림(요청인, 회답수신인, 입법담당관실 관리자)-->
        {{taskInfo.state}} |
        받는사람:{{taskInfo.approver_id}} |
        로그인사용자:{{loginUserInfo.user_id}} |
        approver_id:{{loginUserInfo.approver_id}} |
        팀장여부:{{isAuthCheck(constants.RoleType.TeamLeader)}}
        <button
          type="button"
          class="btn-strong"
          v-if="!taskInfo || !taskInfo.state"
          @click="approveReq(constants.ReqState.REQ, '승인요청')"
        >요청등록</button>

        <button
          type="button"
          class="btn-cancel"
          v-if="!taskInfo || !taskInfo.state && task_id"
          @click="deleteItem"
        >삭제</button>

        <button
          type="button"
          class="btn-normal"
          v-if="!taskInfo || !taskInfo.state"
          @click="approveReq(null, '저장')"
        >임시저장</button>

        <!-- 요청수정 > 요청중, 접수대기, 회답중 가능 > 요청인, 입법담당관실 수정권한자 -->
        <button
          type="button"
          class="btn-strong"
          v-if="taskInfo.state && isEditableState(taskInfo.state)"
          @click="approveReq(null, '저장')"
        >저장</button>

        <!-- 회답중 > 배정조사관 자동-->
        <!-- 접수대기 > 담당조사관 -->
        <button
          type="button"
          class="btn-strong"
          v-if="job_id=='request' && taskInfo.state == constants.ReqState.REQ && isAuthCheck(constants.RoleType.TeamLeader)"
          @click="approveReq(constants.ReqState.WAIT, '배정')"
        >배정</button>

        <!-- ? -->
        <button
          type="button"
          class="btn-normal"
          v-if="job_id=='request' && taskInfo.state == constants.ReqState.WAIT"
          @click="approve(constants.ReqState.HOLD, '보류')"
        >보류</button>

        <!-- 보류중 > 동일팀, 팀장 권한 갖은사람. -->
        <button
          type="button"
          class="btn-normal"
          v-if="job_id=='request' && taskInfo.state == constants.ReqState.HOLD"
          @click="approve(constants.ReqState.COMEBACK, '재기.')"
        >재기</button>

        <!-- 결제중 > 담당 조사관 -->
        <button
          type="button"
          class="btn-strong"
          v-if="job_id=='response' && taskInfo.state == constants.ReqState.WAIT && taskInfo.approver_id== loginUserInfo.user_id"
          @click="approve(constants.ReqState.RES, '배정확정')"
        >배정확정</button>

        <!-- 재배정요청 을 한경우 현재 상태를 어떻게 보이게 해야 하는가? -->
        <!-- <button
          type="button"
          class="btn-strong"
          v-if="job_id=='response' && taskInfo.state == constants.ReqState.RES && taskInfo.approver_id== loginUserInfo.user_id"
          @click="approve(constants.ReqState.WAIT, '재배정요청')"
        >재배정요청</button>-->

        <button
          type="button"
          class="btn-strong"
          v-if="job_id=='response' && taskInfo.state == constants.ReqState.RES && taskInfo.approver_id== loginUserInfo.user_id"
          @click="approve(null, '요청수정건의')"
        >요청수정건의</button>

        <button
          type="button"
          class="btn-strong"
          v-if="job_id=='response' && taskInfo.state == constants.ReqState.RES && taskInfo.approver_id== loginUserInfo.user_id"
          @click="approve(constants.ReqState.APPROVE, '기안전송')"
        >기안전송</button>

        <button
          type="button"
          class="btn-cancel"
          v-if="job_id=='response' && taskInfo.state == constants.ReqState.APPROVE"
          @click="approve(constants.ReqState.RES, '전자결제반려.')"
        >전자결제반려(임시)</button>

        <button
          type="button"
          class="btn-strong"
          v-if="job_id=='response' && taskInfo.state == constants.ReqState.APPROVE"
          @click="approve(constants.ReqState.COMPLETE, '전자결제완료.')"
        >전자결제완료(임시)</button>

        <!-- 회답서완료 > 요청인 -->
        <button
          type="button"
          class="btn-strong"
          v-if="isReqUser && taskInfo.state == constants.ReqState.COMPLETE"
          @click="reqAddRes"
        >회답서 추가요청</button>

        <!-- 요청인 -->
        <button
          type="button"
          class="btn-cancel"
          v-if="job_id=='request' && 
          (taskInfo.state == constants.ReqState.REQ || 
          taskInfo.state == constants.ReqState.WAIT ||
          taskInfo.state == constants.ReqState.RES)
          && isReqUser"
          @click="approve(constants.ReqState.RETRACT, '요청철회')"
        >요청철회</button>
        <button type="button" class="btn btn-point btn-sm" @click="print()">인쇄하기</button>
        <button type="button" class="btn btn-save btn-sm" @click="pdfExport">PDF로 저장</button>
      </div>
    </div>
  </div>
</template>

<script>
import { getTaskInfo, setTaskInfo, setNoti, getUserList } from "../../services";

export default {
  name: "task",
  props: {
    job_id: {
      type: String,
      default: "",
      required: true
    },
    task_id: {
      type: String,
      default: "",
      required: true
    },
    dept_cd: {
      type: String,
      default: ""
    },
    req_user_id: {
      type: String,
      default: ""
    },
    showMemo: {
      type: Boolean,
      default: false
    },
    isEditable: {
      type: Boolean,
      default: false
    }
  },
  data: function() {
    return {
      taskList: [],
      processList: [],
      taskInfo: {
        job_id: this.job_id,
        task_id: this.task_id,
        sort: 0,
        req_user_id: "",
        req_user_nm: "",
        approver_id: "",
        approver_nm: "",
        etc: "",
        state: ""
      },
      correntTask: {},
      approver_id: "",
      approver_nm: "",
      etcTitle: "메모"
    };
  },
  computed: {
    isApprover() {
      return true;
    }
  },
  watch: {
    $route(to, from) {
      if (!to.query.req_no) {
        this.taskInfo = {
          job_id: this.job_id,
          task_id: this.task_id,
          sort: 0,
          req_user_id: "",
          req_user_nm: "",
          approver_id: "",
          approver_nm: "",
          etc: "",
          state: ""
        };
      }
    },
    task_id(newVal) {
      this.getTaskInfo();
    }
  },
  methods: {
    approveReq(state, title) {
      this.$emit("approveReq", state, title);
    },
    approve(state) {
      if (!state) {
        return Promise.resolve(0);
      }
      return this.setTaskInfo(this.task_id, state).then(res => {
        let taskState = this.commonCode("req_state", state);
        return this.alert(
          "확인",
          `${this.task_id} ${taskState} 했습니다.`,
          "success"
        ).then(() => {
          this.$emit("approve", state);
        });
      });
    },
    complete() {
      // let taskState = this.commonCode('task_state', state);
      this.confirm(
        this.jobName[this.job_id] + " 종료",
        this.task_id + " 종료 처리 하시겠습니까?"
      ).then(res => {
        if (res) {
          this.approve(this.constants.ReqState.COMPLETE);
        }
      });
    },
    getTaskInfo() {
      return getTaskInfo({ job_id: this.job_id, task_id: this.task_id }).then(
        res => {
          if (res.data.length) {
            this.taskList = res.data;
            this.taskInfo = this.taskList[res.data.length - 1];
            this.approver_id = this.taskInfo.approver_id;
            if (this.isApprover) {
              this.taskInfo.etc = "";
            }
            this.$emit("currentTaskInfo", this.taskInfo);
          }
          return res.data;
        }
      );
    },
    setTaskInfo(taskId, state, approverId) {
      if (!state) {
        return Promise.resolve(false);
      }
      this.taskInfo.job_id = this.job_id;
      this.taskInfo.req_user_id = this.req_user_id;
      if (approverId) {
        this.taskInfo.approver_id = approverId;
      } else {
        this.taskInfo.approver_id = this.approver_id;
      }
      this.taskInfo.task_id = taskId;

      if (
        state == this.constants.ReqState.HOLD ||
        state == this.constants.ReqState.RETRACT
      ) {
        this.taskInfo.pre_state = this.taskInfo.state;
        this.taskInfo.state = state;
      } else if (
        state == this.constants.ReqState.COMEBACK &&
        this.taskInfo.pre_state
      ) {
        this.taskInfo.state = this.taskInfo.pre_state;
        this.taskInfo.pre_state = "";
      } else if (state) {
        this.taskInfo.state = state;
        this.taskInfo.pre_state = "";
      }

      return setTaskInfo(this.taskInfo).then(res => {
        return res.data;
      });
    },
    deleteItem() {
      this.confirm("삭제", this.task_id + " 삭제 하시겠습니까?").then(res => {
        if (res) {
          this.$emit("deleteItem");
        }
      });
    },
    reqAddRes() {
      this.$router.push({
        name: "request",
        query: { parent_req_no: this.task_id }
      });
    },
    print() {
      this.$emit("print");
    }
  },
  created() {
    if (this.task_id) {
      this.getTaskInfo();
    }
  }
};
</script>

<style>
.wizard > .content {
  height: auto !important;
  min-height: inherit !important;
}
</style>
