<template>
  <div>
    <!-- 입안지원 -->
    <div class="cont-cate" v-if="req_type=='pl_sppt'">
      <div class="cate-define">의원의 입법활동 지원을 위해 의원 및 위원회에서 요청하는 입안 사항을 적극 반영한 조례안 신속 제공</div>
      <ul class="cate-info">
        <li>
          <strong class="title">의뢰대상</strong>
          <ul>
            <li>조례 제․개정안 입안 및 검토</li>
            <li>기타 법제지원</li>
          </ul>
        </li>
        <li>
          <strong class="title">소요기간</strong>
          <ul>
            <li>조례제정 및 전부개정 : 30일</li>
            <li>
              일부개정 및 기타 법제지원 : 25일
              <span class="text-warning">(※ 접수순 처리로 대기일이 발생할 수 있습니다)</span>
            </li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- //입안지원 -->
    <!-- 법안검토 -->
    <div class="cont-cate" v-if="req_type=='lm_pc'">
      <div class="cate-define">의원 의정활동 지원 강화를 위해 의원 및 상임위원회에서 요청한 입법정책 사항에 대해 신속‧정확한 조사‧분석 회답서비스 제공</div>
      <ul class="cate-info">
        <li>
          <strong class="title">의뢰대상</strong>
          <ul>
            <li>의원의 의정활동에 필요한 의안의 발굴·조사 및 연구 등에 관한 사항</li>
            <li>법령·제도개선 등에 관한 사항</li>
            <li>국내외 입법 및 정책관련 사항의 기획·연구 및 조사 등에 관한 사항</li>
          </ul>
        </li>
        <li>
          <strong class="title">소요기간</strong>
          <ul>
            <li>
              평균 20일
              <span class="text-warning">(※접수순 처리로 대기일이 발생할 수 있습니다)</span>
            </li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- //법안검토 -->

    <!-- 입법자문 -->
    <div class="cont-cate" v-if="req_type=='lg_adv'">
      <div class="cate-define">자치법규 제․개정 및 의회관련 법률쟁점사항의 자문을 통해 의원입법 활동 지원과 의회관련 쟁송을 효율적으로 수행</div>
      <ul class="cate-info">
        <li>
          <strong class="title">의뢰대상</strong>
          <ul>
            <li>자치법규의 제·개정, 법령 및 자치법규 해석 등 입법사항</li>
            <li>의회관련 법률사항</li>
          </ul>
        </li>
        <li>
          <strong class="title">소요기일</strong>
          <ul>
            <li>
              자문의뢰일 익일을 기준으로 7일 이내 검토의견 제출
              <span
                class="text-warning"
              >(※ 상임위원회로부터 공문접수 등을 고려하면 통상 8~10일 소요)</span>
            </li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- //입법자문 -->

    <!-- 전문정보 도서검색 -->
    <div class="cont-cate" v-if="req_type=='pf_info'">
      <div class="cate-define">입법·정책 및 의정활동에 필요한 정보 요구에 대해 해당 주제에 맞는 전문정보를 탐색하여 적시에 자료 제공</div>
      <ul class="cate-info">
        <li>
          <strong class="title">제공자료</strong>
          <ul>
            <li>정책보고서, 학술논문, 통계자료, 법률정보, 기사, 보도자료, 현황, 사례, 국내외 비교자료 등</li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- //입법자문 -->
  </div>
</template>

<script>
export default {
  name: "req-info",
  props: {
    req_type: {
      type: String,
      default: ""
    }
  },
  methods: {},
  created() {}
};
</script>
