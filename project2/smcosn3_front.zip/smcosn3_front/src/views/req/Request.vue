<template>
  <div class="form-horizontal">
    <widget-container>
      <request-info
        v-if="requestInfo.req_no"
        :showContent="!isEditable"
        :req_no="requestInfo.req_no"
      ></request-info>

      <response-info
        v-if="requestInfo.res_no && requestInfo.state == constants.ReqState.COMPLETE"
        :req_no="requestInfo.res_no"
      ></response-info>

      <template v-if="!requestInfo.req_no">
        <div class="tit-group">
          <h3 class="title">요청 분류</h3>
        </div>
        <div class="list-tab">
          <div class="inner">
            <ul class="tab">
              <li
                v-for="(item, index) in commonCodeList('req_type')"
                :class="item.value == requestInfo.req_type ? 'selected' : ''"
                :key="index"
              >
                <a @click="requestInfo.req_type = item.value">{{item.value | code('req_type')}}</a>
              </li>
            </ul>
          </div>
        </div>
        <req-info :req_type="requestInfo.req_type"></req-info>
      </template>
      <template v-if="isEditable">
        <p class="label-required">
          <span class="required">*</span>필수값
        </p>
        <div class="form-box">
          <!-- tamplate_loader -->
          <template-loader
            ref="tamplate_loader"
            :req_type="requestInfo.req_type"
            :task_id="requestInfo.req_no"
          ></template-loader>

          <div class="form-group row">
            <label class="col-sm-2 control-label">파일 첨부</label>
            <div class="col-sm-10">
              <v-fileupload ref="fileupload" multiple="true" v-model="requestInfo.req_no"></v-fileupload>
              <!-- <el-upload
                ref="fileupload"
                :onSuccess="fileUploadSucess"
                :file-list="uploadFiles"
                :auto-upload="false"
              >
                <span class="btn-strong">
                  <span class="fileinput-new">파일선택</span>
                </span>
              </el-upload>-->
            </div>
          </div>

          <div v-if="loginUserInfo.user_type != 'councilor'" class="form-group row">
            <label class="col-sm-2 control-label">
              담당시의원
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <selection-input
                name="councilor_id"
                v-model="requestInfo.councilor_id"
                :text="requestInfo.councilor_nm"
                v-validate="'required'"
                :roleType="constants.RoleType.Councilor"
                :clickFunction="selectedApprover"
              ></selection-input>
              <label
                id="-error"
                class="error"
                v-show="errors.has('councilor_id')"
              >{{ errors.first('councilor_id') }}</label>
            </div>
          </div>

          <div v-if="loginUserInfo.user_type != 'supporter'" class="form-group row">
            <label class="col-sm-2 control-label">지&nbsp;&nbsp;원&nbsp;&nbsp;관</label>
            <div class="col-sm-10">
              <selection-input
                name="supporter_id"
                v-model="requestInfo.supporter_id"
                :text="requestInfo.supporter_nm"
                :roleType="constants.RoleType.Supporter"
                :clickFunction="selectedApprover"
              ></selection-input>
            </div>
          </div>
        </div>

        <selection-staff-list
          ref="addressee"
          job_id="request"
          user_type="addressee"
          title="회답수신인"
          :task_id="requestInfo.req_no"
          :enabled="$refs.task && $refs.task.isEnable"
        ></selection-staff-list>

        <div class="tit-group">
          <h3 class="title">
            알림을 받으시겠습니까?
            <span class="required">*</span>&nbsp;&nbsp;&nbsp;
            <span class="text-warning">[요청하신 건의 진행 상태와 댓글 생성 때마다 알림을 보내 드립니다.]</span>
          </h3>
        </div>
        <div class="control-box">
          <span class="text-warning">중복체크가 가능합니다.</span>
          <v-checkbox-group code="noti_type" v-model="notiType"></v-checkbox-group>
        </div>

        <template
          v-if="isAuthCheck(constants.RoleType.TeamLeader) 
            && (requestInfo.state == constants.ReqState.REQ || requestInfo.state == constants.ReqState.WAIT)"
        >
          <div class="tit-group">
            <h3 class="title">
              조사관을 배정해 주세요.
              <span class="required">*</span>&nbsp;&nbsp;&nbsp;
              <span class="text-warning">[배정버튼을 클릭하시면 요청서가 조사관에게 배정됩니다.]</span>
            </h3>
          </div>
          <div class="control-box">
            <selection-input
              name="examiner_id"
              v-model="requestInfo.examiner_id"
              :text="requestInfo.examiner_nm"
              v-validate="'required'"
              :roleType="constants.RoleType.Examiner"
              :clickFunction="selectedApprover"
            ></selection-input>
            <label
              id="-error"
              class="error"
              v-show="errors.has('examiner_id')"
            >{{ errors.first('examiner_id') }}</label>
          </div>
        </template>
      </template>

      <task
        ref="task"
        job_id="request"
        :task_id="requestInfo.req_no"
        :req_type="requestInfo.req_type"
        :req_user_id="requestInfo.councilor_id"
        :is_req_user="false"
        :isEditable="isEditable"
        @approveReq="approveReq"
        @deleteItem="deleteItem"
        @approve="approve"
        @print="print"
      ></task>
    </widget-container>
  </div>
</template>

<script>
import { Task } from "../common";
import ReqInfo from "./ReqInfo";
import RequestInfo from "../req/RequestInfo";
import ResponseInfo from "../res/ResponseInfo";

import { setReq, getReq, deleteReq } from "../../services";

export default {
  name: "request",
  components: {
    Task,
    ReqInfo,
    RequestInfo,
    ResponseInfo
  },
  computed: {
    isOwner() {
      return (
        this.requestInfo.supporter_id == this.loginUserInfo.user_id ||
        this.requestInfo.councilor_id == this.loginUserInfo.user_id ||
        this.requestInfo.examiner_id == this.loginUserInfo.user_id ||
        this.requestInfo.create_user_idx == this.loginUserInfo.user_id
      );
    },
    isEditable() {
      return (
        !this.requestInfo.req_no ||
        (this.isEditableState(this.requestInfo.state) &&
          (this.isTeamLeaderAndAdmin || this.isOwner))
      );
    }
  },
  data() {
    return {
      requestInfo: {
        req_type: "pl_sppt",
        req_no: "",
        parent_req_no: "",
        res_limit_dt: "",
        open_type: "",
        noti_type: "",
        examiner_id: "",
        examiner_nm: "",
        councilor_id: "",
        req_user_nm: "",
        supporter_id: "",
        supporter_nm: "",
        dept_cd: ""
      },
      staffData: [],
      notiType: [],
      pre_examiner_id: ""
    };
  },
  watch: {
    $route(to, from) {
      if (!to.query.req_no) {
        this.requestInfo = {
          req_type: "pl_sppt",
          req_no: "",
          parent_req_no: "",
          res_limit_dt: "",
          open_type: "",
          noti_type: "",
          examiner_id: "",
          examiner_nm: "",
          councilor_id: "",
          req_user_nm: "",
          supporter_id: "",
          supporter_nm: "",
          user_type: "",
          reply_list: [],
          dept_cd: "",
          update_user_idx: "test_user_01",
          create_user_idx: "test_user_01"
        };
        this.$refs.fileupload.fileList = [];
      }
    }
  },
  methods: {
    findTeamLeader() {
      //state REQ, 팀배정, 팀장 배정.
      //해당침 팀장권한 자 id
      return this.findUserList({
        dept_cd: this.requestInfo.dept_cd,
        auth_id: this.constants.RoleType.TeamLeader
      }).then(res => {
        if (res.length) {
          return res[0].user_id;
        }
        return "";
      });
    },
    approveReq(state, title) {
      Promise.all([
        this.$validator.validateAll(),
        this.$refs.tamplate_loader.$validator.validateAll(),
        this.$refs.task.$validator.validateAll()
      ]).then(res => {
        if (res[0] && res[1]) {
          //담당시의원에 부서코드로 넣기.
          if (
            this.loginUserInfo.user_type == this.constants.RoleType.Councilor
          ) {
            this.requestInfo.councilor_dept_cd = this.loginUserInfo.dept_cd;
            this.requestInfo.councilor_id = this.loginUserInfo.user_id;
          } else if (
            this.loginUserInfo.user_type == this.constants.RoleType.Supporter
          ) {
            this.requestInfo.supporter_id = this.loginUserInfo.user_id;
          }
          //요청분류별 팀배정
          this.requestInfo.dept_cd = this.constants.TeamAssignType[
            this.requestInfo.req_type
          ];
          if (state == this.constants.ReqState.REQ) {
            //ReqTypeResLimitDate
            let dayCnt = this.constants.ReqTypeResLimitDate[
              this.requestInfo.req_type
            ];
            this.requestInfo.res_limit_dt = this.getDateAdd(dayCnt);
            this.findTeamLeader().then(res => this.setReq(state, title, res));
          } else if (state == this.constants.ReqState.WAIT) {
            this.setReq(state, title, this.requestInfo.examiner_id);
          } else {
            //조사관이 변경 된 경우 배정대기 상태
            if (this.pre_examiner_id != this.requestInfo.examiner_id) {
              this.setReq(
                this.constants.ReqState.WAIT,
                title,
                this.requestInfo.examiner_id
              );
            } else {
              this.setReq(state, title);
            }
          }
        }
      });
    },
    fileUploadSucess(files) {},
    approve(state) {
      if (
        state == this.constants.ReqState.COMEBACK ||
        state == this.constants.ReqState.HOLD ||
        state == this.constants.ReqState.RETRACT
      ) {
        // this.$router.push({ name: "requestList" });
        this.getReq();
      }
    },
    getReq() {
      getReq(this.requestInfo).then(res => {
        this.requestInfo = res.data;
        this.pre_examiner_id = this.requestInfo.examiner_id;
      });
    },
    setReq(state, title, approverId) {
      //email.
      return this.$refs.fileupload.uploadFile().then(resFileList => {
        return setReq(this.requestInfo).then(res => {
          const data = res.data;
          this.requestInfo = data;
          let replayMap = this.notiType.map(val => {
            return {
              task_id: data.req_no,
              field_nm: val,
              parent_field_nm: "noti_type",
              value: val
            };
          });
          return Promise.all([
            this.setContentMapList(replayMap),
            this.$refs.tamplate_loader.setContentMapList(data.req_no),
            this.$refs.fileupload.setFileList(data.req_no, resFileList),
            this.$refs.addressee.setStaffList(data.req_no),
            this.$refs.task.setTaskInfo(data.req_no, state, approverId)
          ]).then(() => {
            this.alert(
              title,
              `요청번호: ${this.parseReqNo(data.req_no)}\n${title} 했습니다.`,
              "success"
            ).then(() => {
              // this.sendMessage(
              //   data.req_no,
              //   state,
              //   this.notiType,
              //   this.$refs.addressee.staffData
              // );
              if (state) this.$router.push({ name: "requestList" });
            });
          });
        });
      });
    },
    deleteItem() {
      return deleteReq(this.requestInfo).then(res => {
        this.$router.push({ name: "requestList" });
        return res;
      });
    },
    selectedApprover(roleType) {
      let filter = null;
      if (roleType == this.constants.RoleType.Examiner) {
        filter = {
          auth_list: [
            { auth_id: roleType },
            { auth_id: this.requestInfo.dept_cd }
          ]
        };
      } else {
        filter = { user_type: roleType };
      }

      this.addMng(false, filter).then(res => {
        if (res) {
          this.requestInfo[roleType + "_id"] = res.user_id;
          this.requestInfo[roleType + "_nm"] = res.user_nm;
          this.requestInfo[roleType + "_dept_cd"] = res.dept_cd;
        }
        return res;
      });
    },
    print() {
      const url = `${process.env.VUE_APP_API_URL}/aireport/template/${this.requestInfo.req_type}.jsp?reportMode=HTML&task_id=${this.requestInfo.req_no}&clientURIEncoding=UTF-8`;
      window.open(url, "_blank");
    }
  },
  created() {
    const query = this.$route.query;
    if (query.req_type) {
      this.requestInfo.req_type = query.req_type;
    }
    if (query.req_no) {
      this.requestInfo.req_no = query.req_no;
      this.getReq();
      this.getContentMapList(query.req_no, "noti_type").then(res => {
        this.notiType = res.map(item => item.value);
      });
    }
  }
};
</script>

<style>
/* 요청분류 */
.cont-cate {
  padding: 0 10px 40px;
}
.cont-cate .cate-define {
  padding: 15px 20px;
  color: #4d4d4d;
  background: #e5f3ff;
}
.cont-cate ul {
  padding: 0;
  margin: 0;
  list-style: none;
}
.cont-cate .cate-info {
}
.cont-cate .cate-info > li {
  padding: 0 20px;
  margin-top: 18px;
}
.cont-cate .cate-info > li > .title {
  display: block;
  margin-bottom: 5px;
}
.cont-cate .cate-info > li > .title::before {
  content: "";
  display: inline-block;
  width: 2px;
  height: 12px;
  margin-right: 5px;
  background: #3177b4;
}
.cont-cate .cate-info > li > ul {
  margin-left: 10px;
}
.cont-cate .cate-info > li > ul > li {
  position: relative;
  padding-left: 9px;
}
.cont-cate .cate-info > li > ul > li:before {
  content: "";
  position: absolute;
  left: 0px;
  top: 10px;
  width: 3px;
  height: 1px;
  background: currentColor;
}
</style>
