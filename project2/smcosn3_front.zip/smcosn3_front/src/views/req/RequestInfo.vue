<template>
  <div class="form-box">
    <div class="form-group row">
      <label class="col-sm-2 control-label">요청번호</label>
      <div class="col-sm-4">
        <div class="desc">{{parseReqNo(requestInfo.req_no)}}</div>
      </div>
      <label class="col-sm-2 control-label">요청분류</label>
      <div class="col-sm-4">
        <div class="desc">{{requestInfo.req_type | code('req_type')}}</div>
      </div>
    </div>
    <div class="form-group row">
      <label class="col-sm-2 control-label">요청의원</label>
      <div class="col-sm-4">
        <div class="desc">{{requestInfo.councilor_nm}}</div>
      </div>
      <label class="col-sm-2 control-label">요청지원관</label>
      <div class="col-sm-4">
        <div class="desc">{{requestInfo.supporter_nm}}</div>
      </div>
    </div>
    <div class="form-group row">
      <label class="col-sm-2 control-label">담당부서</label>
      <div class="col-sm-4">
        <div class="desc">{{requestInfo.dept_cd | code('team_type')}}</div>
      </div>
      <label class="col-sm-2 control-label">담당조사관</label>
      <div class="col-sm-4">
        <div class="desc">{{requestInfo.examiner_nm}}</div>
      </div>
    </div>
    <div class="form-group row">
      <label class="col-sm-2 control-label">요청현황</label>
      <div class="col-sm-4">
        <div v-html="sateProress(requestInfo.state, requestInfo.pre_state)"></div>
      </div>
      <label class="col-sm-2 control-label">회답수신인</label>
      <div class="col-sm-4">
        <div class="desc">{{addressee}}</div>
      </div>
    </div>
    <!-- tamplate_loader -->
    <template-loader
      v-if="showContent"
      ref="tamplate_loader"
      :req_type="requestInfo.req_type"
      :task_id="requestInfo.req_no"
      :readonly="true"
    ></template-loader>
  </div>
</template>

<script>
import { getReq } from "../../services";
export default {
  name: "request-info",
  components: {},
  props: {
    req_no: {
      type: String,
      default: ""
    },
    showContent: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      requestInfo: {
        req_type: "",
        case_no: "",
        case_name: "",
        req_no: "",
        state: "",
        parent_req_no: "",
        res_limit_dt: "",
        open_type: "",
        noti_type: "",
        update_user_idx: "test_user_01",
        create_user_idx: "test_user_01"
      },
      addressee: ""
    };
  },
  watch: {
    req_no(val) {
      if (val) {
        this.getReq();
      }
    }
  },
  methods: {
    getReq() {
      getReq({ req_no: this.req_no }).then(res => {
        this.requestInfo = res.data;
      });
    }
  },
  created() {
    if (this.req_no) {
      this.getReq();
      this.getStaffList("request", this.req_no, "addressee").then(res => {
        if (res.length)
          this.addressee = res.map(item => item.user_nm).join(",");
      });
      this.getContentMapList(this.req_no, "reply").then(res => {});
    }
  }
};
</script>
