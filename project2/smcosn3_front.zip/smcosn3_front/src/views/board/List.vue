<template>
  <form class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">검색조건</label>
            <div class="col-sm-10 grid-box">
              <v-dropdown
                id="search_type"
                name="search_type"
                inputClass="form-control form-control-sm"
                v-model="search_type"
                placeholder
                :options="[{label:'제목', value:'title'},{label:'내용', value:'content'},{label:'키워드', value:'keyword'}]"
              />
              <input
                placeholder="검색어 입력"
                type="text"
                class="form-control form-control-sm"
                @keyup.13="getList"
                style="width:2000px"
                v-model="search_text"
              />
              <span class="input-group-append">
                <button type="button" class="btn btn-sm btn-primary" @click="search">검색</button>
              </span>
            </div>
          </div>
        </div>
        <!-- <div class="hr-line-dashed"></div> -->
        <div class="table-responsive tbl-wrap-type1">
          <div style="padding: 8px;white-space: nowrap;">
            <i class="fa fa-list"></i>
            검색결과 : {{this.totalCount | numberComma}} 건
          </div>
          <v-table
            is-horizontal-resize
            style="width:100%"
            :isVerticalResize="true"
            :columns="[{field: 'row_no', title: '순번', width: 100, titleAlign: 'center', columnAlign: 'center'},                                 
                      {field: 'title', title: '제목', width: 100, titleAlign: 'center', columnAlign: 'left', orderBy:'desc', isResize: true },                                 
                      {field: 'user_nm', title: '작성자', width: 100, titleAlign: 'center', columnAlign: 'center'},                                
                      {field: 'create_date_time', title: '작성일', width: 100, titleAlign: 'center', columnAlign: 'center', type: 'datetime'}]"
            :table-data="tableData"
            :row-click="selectRow"
          ></v-table>
        </div>
        <div class="row">
          <div class="col-sm-12 m-t-xs align-content-center">
            <v-pager
              v-model="pageNumber"
              :page-count="pageCount"
              @change="onChange"
              @pageSizeChange="pageSizeChange"
            ></v-pager>
          </div>
        </div>

        <div class="list-btn-group group-submit"
            v-if="isAuthCheck(constants.RoleType.TeamLeader || constants.RoleType.Examiner || constants.RoleType.Admin)">
            <!-- v-if="isAuthCheck(constants.RoleType.Councilor)"> -->
          <div class="float-right">
            <button
              type="button"
              class="btn-strong"
              @click="$router.push({name:'boardWrite', query:$route.query})"
            >등록하기</button>
          </div>
        </div>
      </widget-container>
    </fieldset>
  </form>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getBoardList, setBoard, getBoard } from "../../services";

export default {
  name: "boardlist",
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      board_type: "gongji",
      id: "",
      end_dt: "",
      user_id: "",
      user_nm: "",
      state: "",
      search_text: "",
      search_type: "title",
      user_type: "",
      vio_cd: ""
    };
  },
  watch: {
    $route(to, from) {
      if (to.query.page_index) {
        this.pageIndex = Number(to.query.page_index);
      } else {
        this.pageIndex = 1;
      }
      this.board_type = to.query.board_type;
      this.getList();
    }
  },

  methods: {
    ...mapActions(["getBoardInfo"]),
    onChange() {
      this.$router.push({
        name: "boardList",
        query: {  board_type: rowData.board_type, page_index: this.pageIndex }
      });
    },
    pageSizeChange(val) {
      this.pageNumber = 1;
      this.pageSize = val;
      this.getList();
    },
    selectRow(rowIndex, rowData) {
      this.$router.push({
        name: "boardView",
        query: { board_type: rowData.board_type, id: rowData.id }
      });
    },
    getList() {
      return getBoardList({
        board_type: this.board_type,
        page_index: this.pageIndex,
        page_size: this.pageSize,
        search_text: this.search_text,
        search_type: this.search_type
      }).then(res => {
        const data = res.data;
        this.totalCount = data.TOTAL_COUNT;
        this.pageCount = Math.ceil(data.TOTAL_COUNT / this.pageSize);
        this.tableData = data.list;
      });
    },
    search() {
      this.pageIndex = 1;
      this.getList();
    }
  },

  mounted() {
    const query = this.$route.query;
    this.pageNumber = 1;
    if (query.page_index) {
      this.pageNumber = Number(query.page_index);
    }
    this.board_type = query.board_type;
    this.getList();
  }
};
</script>
