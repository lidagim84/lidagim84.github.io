<template>
  <div class="row">
    <div class="col-lg-12">
      <widget-container>
        <div v-if="user_id==='admin1'" class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              제목
            </label>
            <div class="col-sm-10">
              <input
                type="text"
                name="case_name"
                v-validate="'required'"
                class="form-control"
                v-model="boardInfo.title"
              />
              <label
                id="error"
                class="error"
                v-show="errors.has('case_name')"
              >{{ errors.first('case_name') }}</label>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">내용</label>
            <div class="col-sm-10">
              <editor v-model="boardInfo.content"></editor>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">파일첨부</label>
            <div class="col-sm-10">
              <v-fileupload
                ref="fileupload"
                multiple="true"
                v-model="fileMapId"
                :is_imguploader="boardInfo.boardType=='gallery'"
              ></v-fileupload>
            </div>
          </div>
        </div>

        <div v-if="user_id!='admin1'" class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              제목
            </label>
            <div class="col-sm-10">
              <div class="desc">{{ boardInfo.title }}</div>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">내용</label>
              <div v-html="boardInfo.content" class="col-sm-10"></div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">파일첨부</label>
            <div class="col-sm-10">
              <v-fileupload
                ref="fileupload"
                multiple="true"
                v-model="fileMapId"
                :is_imguploader="boardInfo.boardType=='gallery'"
              ></v-fileupload>
            </div>
          </div>
        </div>
        <div class="list-btn-group group-submit">
          <div class="float-right">
            <button type="button" class="btn-strong" @click="$router.push({name:'boardList', query:$route.query})">목록으로</button>
            <!-- <button type="button" class="btn-normal">삭제</button> -->
          </div>
        </div>
      </widget-container>
    </div>
  </div>
</template>

<script>
import { getBoard, setBoard } from '../../services';
import Editor from '../../components/editor/Editor';
export default {
  name: 'view',
  components: {
    Editor,
  },
  data() {
    return {
      currentPage: 1,
      boardInfo: {
        board_type: this.$route.query.board_type,
        id: this.$route.query.id,
        title: '',
        content: '',
        update_user_idx: '',
        create_user_idx: '',
      },
      fileMapId: '',
    };
  },
  methods: {
    setCookieClose() {
      this.$cookie.set('ann1DCache', 'One day later', { expires: '1D' });
       window.self.close()
    },
    getBoard() {
      this.boardInfo.board_type = this.$route.query.board_type;
      this.boardInfo.id = this.$route.query.id;
      return getBoard(this.boardInfo).then(boardRes => {
        this.boardInfo = boardRes.data;
        this.fileMapId = this.$route.query.board_type + '' + this.$route.query.id;
      });
    },
    goList() {
      this.$router.push({ name: "boardList"});
    }    
  },
  created() {
    if (this.$route.query.id) {
      this.getBoard();
    }
  },
};
</script>
