<template>
  <div class="row">
    <div class="col-lg-12">
      <widget-container>
        <h5 slot="title">
          Comment.
        </h5>
        <comment
          name="qna-comment"
          :menu_id="$route.query.menu_id"
          :target_id="$route.query.target_id"
        ></comment>
      </widget-container>

    </div>
  </div>
</template>

<script>
export default {
  name: 'Qna',
  data: function() {
    return {};
  },
  computed: {},
  methods: {},
  created() {},
  mounted() {}
};
</script>
