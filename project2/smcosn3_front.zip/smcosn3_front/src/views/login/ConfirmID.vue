<template>
  <div class="account-wrapper login-form">
    <div class="account-body">
      <h2 class="title">ID 확인</h2>
      <p class="desc-login">ID를 찾았습니다.</p>

      <form class="login-form-box" role="form">
        <table class="tbl-login">
            <colgroup>
            <col style="width:90px;">
            <col>
          </colgroup>
          <tbody>
            <tr>
              <th scope="row">성명</th>
              <td>
                <input
                  id="user_nm"
                  name="user_nm"
                  type="text"
                  class="form-control"
                  placeholder="성명"
                  v-validate="'required'"
                  v-model="loginInfo.user_nm"
                />
                <label class="error" v-show="errors.has('user_nm')">{{ errors.first('user_nm') }}</label>
                <!-- <input class="form-control" placeholder="성명" required v-model="loginInfo.user_nm" /> -->
              </td>
            </tr>
          </tbody>
        </table>

        <p class="check">님의 ID는 입니다.</p>

        <div class="list-btn-group">
          <button class="btn-strong" @click="login">로그인</button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getUserCheck } from "../../services";

export default {
  name: "forget-id",
  data() {
    return {
      loginInfo: {
        user_nm: "",
        hp_no: "",
        email: ""
      }
    };
  },
  methods: {
    login() {
      console.log("cancle");
      this.$router.push({ name: 'login' });
    }
  },
  created() {}
};
</script>

<style>
.center {
  margin: auto;
  margin-top: 15vh;
}

.logo-image {
  width: auto !important; /*Keep the aspect ratio of the image*/
  /*height: 140px !important;*/
  margin: 0 auto 1em auto; /*Center the image*/
}
.logo-name {
  /*width: 500px;*/
  height: 120px;
  margin-bottom: 15px;
  background: url("/assets/logo.png") no-repeat center;
  background-size: contain;
  /*border: 1px solid #AAA;*/
}
.logo-title {
  position: absolute;
  top: 210px;
  left: 90px;
  /* margin-right: -50%; */
  /* transform: translate(-50%, -50%) ; */
  white-space: pre-wrap;
  color: #ffffff;
  font-family: "Helvetica Neue", sans-serif;
  font-size: 24px;
  font-weight: bold;
  letter-spacing: -2px;
  line-height: 1;
  text-align: center;
  /* text-shadow: 2px 2px 2px gray; */
}

.loginscreen.middle-box {
  /* width: 100% !important;   */
}
.middle-box {
  max-width: 520px !important;
}
</style>
