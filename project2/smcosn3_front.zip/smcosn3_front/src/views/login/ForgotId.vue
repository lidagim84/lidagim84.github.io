<template>
  <div class="account-wrapper login-form">
    <div class="account-body">
      <h2 class="title">ID 찾기</h2>
      <div class="login-form-box" role="form" v-if="!confirm">
        <p class="desc-login">
          ID가 기억나지 않으실 땐,
          <br />서울특별시의회 의사담당관실 02-2180-7846, 7842로
          <br />전화하여 문의하실 수 있습니다.
        </p>
        <table class="tbl-login">
          <colgroup>
            <col style="width:90px;" />
            <col />
          </colgroup>
          <tbody>
            <tr>
              <th scope="row">성명</th>
              <td>
                <input
                  id="user_nm"
                  name="user_nm"
                  type="text"
                  class="form-control"
                  placeholder="성명"
                  v-validate="'required'"
                  v-model="loginInfo.user_nm"
                />
                <label class="error" v-show="errors.has('user_nm')">{{ errors.first('user_nm') }}</label>
              </td>
            </tr>
            <tr>
              <th scope="row">휴대전화</th>
              <td>
                <input
                  id="hp_no"
                  name="hp_no"
                  type="text"
                  class="form-control"
                  placeholder="휴대전화"
                  v-validate="'required'"
                  v-model="loginInfo.hp_no"
                />
                <label class="error" v-show="errors.has('hp_no')">{{ errors.first('hp_no') }}</label>
                <!-- <input class="form-control" placeholder="휴대폰" required v-model="loginInfo.hp_no" /> -->
              </td>
            </tr>
            <tr>
              <th scope="row">이메일</th>
              <td>
                <input
                  id="email"
                  name="email"
                  type="email"
                  class="form-control"
                  placeholder="이메일"
                  v-validate="'required'"
                  v-model="loginInfo.email"
                />
                <label class="error" v-show="errors.has('email')">{{ errors.first('email') }}</label>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="list-btn-group">
          <button class="btn-strong" @click="findID">확인</button>
          <button class="btn-normal" @click="goLogin">로그인</button>
        </div>
      </div>

      <div v-if="confirm" class="login-form-box">
        <p
          v-if="loginInfo.user_id"
          class="desc-login"
        >{{loginInfo.user_nm}}님의 ID는 {{loginInfo.user_id}}입니다.</p>
        <p v-if="!loginInfo.user_id" class="desc-login">확인된 사용자가 없습니다.</p>
      </div>
      <div v-if="confirm" class="list-btn-group">
        <button v-if="!loginInfo.user_id" class="btn-strong" @click="findID2">다시찾기</button>
        &nbsp;
        <button v-if="loginInfo.user_id" class="btn-strong" @click="goLogin">로그인</button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getUserCheck } from "../../services";

export default {
  name: "forget-id",
  data() {
    return {
      loginInfo: {
        user_id: null,
        user_nm: "",
        hp_no: "",
        email: ""
      },
      confirm: false
    };
  },
  methods: {
    findID() {
      // if (!this.loginInfo.user_nm) {
      //   alert("성명을 입력하세요.");
      //   return;
      // }
      // if (!this.loginInfo.hp_no) {
      //   alert("휴대전화 번호를 입력하세요.");
      //   return;
      // }
      // if (!this.loginInfo.email) {
      //   alert("이메일을 입력하세요.");
      //   return;
      // }
      this.$validator.validateAll().then(res => {
        if (res) {
          getUserCheck(this.loginInfo).then(res => {
            const data = res.data;
            this.confirm = true;
            if (data) {
              this.loginInfo = data;
            }
            return data;
          });
        }
      });
    },
    findID2() {
      this.confirm = false;
      this.$router.push({ name: "forgotId" });
    },
    goLogin() {
      this.$router.push({ name: "login" });
    }
  },
  created() {}
};
</script>

<style>
.center {
  margin: auto;
  margin-top: 15vh;
}

.logo-image {
  width: auto !important; /*Keep the aspect ratio of the image*/
  /*height: 140px !important;*/
  margin: 0 auto 1em auto; /*Center the image*/
}
.logo-name {
  /*width: 500px;*/
  height: 120px;
  margin-bottom: 15px;
  background: url("/assets/logo.png") no-repeat center;
  background-size: contain;
  /*border: 1px solid #AAA;*/
}
.logo-title {
  position: absolute;
  top: 210px;
  left: 90px;
  /* margin-right: -50%; */
  /* transform: translate(-50%, -50%) ; */
  white-space: pre-wrap;
  color: #ffffff;
  font-family: "Helvetica Neue", sans-serif;
  font-size: 24px;
  font-weight: bold;
  letter-spacing: -2px;
  line-height: 1;
  text-align: center;
  /* text-shadow: 2px 2px 2px gray; */
}

.loginscreen.middle-box {
  /* width: 100% !important;   */
}
.middle-box {
  max-width: 520px !important;
}
</style>
