<template>
  <div class="account-wrapper login-form">
    <div class="account-body">
      <h2 class="title">사용자 등록 신청</h2>
      <p class="desc-login">서울특별시의회 입법조사회답시스템은 사용자 등록 신청을 별도로 받지 않습니다.</p>
      <p class="desc-login">
        다만, 특별한 사유가 있어 임시적으로 홈페이지를 사용하시고자 할 때에는 등록 신청을 하실 수 있으며, 시스템 관리자가 신청 내역을 확인한 후에 사용허가를 해야만 사용하실 수 있습니다.<br>
        시스템 관리자가 신청 내역을 확인한 후에 사용허가를 해야만 사용하실 수 있습니다.
      </p>
      <p class="desc-login">
        등록신청을 하시더라도, 바로 홈페이지를 사용하실 수 없으므로 이점 유의하시기 바랍니다.
      </p>

      <div class="login-form-box" role="form">
          <table class="tbl-login">
            <colgroup>
              <col style="width:115px;">
              <col>
            </colgroup>
            <tbody>
              <tr>
                <th scope="row">신청ID</th>
                <td>
                  <div class="grid-box btn-group">
                    <input
                      id="user_id"
                      name="user_id"
                      type="text"
                      class="form-control flex1"
                      placeholder="아이디"
                      v-validate="'required'"
                      v-model="loginInfo.user_id"
                      @change="()=>check_id=false"
                    />
                    
                    <button class="btn-strong" @click="ID_Check">중복확인</button>
                    <label class="error" v-show="errors.has('user_id')">{{ errors.first('user_id') }}</label>
                    <p>ID는 6~12자(영문 또는 숫자를 사용해주세요)</p>
                  </div>
                </td>
              </tr>
              <tr>
                <th scope="row">비밀번호</th>
                <td>
                  <input
                    id="password1"
                    name="password1"
                    type="password"
                    class="form-control"
                    placeholder="비밀번호"
                    v-validate="'required'"
                    v-model="loginInfo.password1"
                  />
                  <label class="error" v-show="errors.has('password1')">{{ errors.first('password1') }}</label>
                  <p>비밀번호는 8~16자(영문, 숫자, 특수기호를 함께 사용해주세요)</p>
                </td>
              </tr>
              <tr>
                <th scope="row">비밀번호 확인</th>
                <td>
                  <input
                    id="password_confirmed"
                    name="password_confirmed"
                    type="password"
                    class="form-control"
                    placeholder="비밀번호 확인"
                    v-validate="'required'"
                    v-model="loginInfo.password_confirmed"
                  />
                  <label class="error" v-show="errors.has('password_confirmed')">{{ errors.first('password_confirmed') }}</label>
                </td>
              </tr>

              <tr>
                <th scope="row">이름</th>
                <td>
                  <input
                    id="user_nm"
                    name="user_nm"
                    type="text"
                    class="form-control"
                    placeholder="성명"
                    v-validate="'required'"
                    v-model="loginInfo.user_nm"
                  />
                  <label class="error" v-show="errors.has('user_nm')">{{ errors.first('user_nm') }}</label>
                </td>
              </tr>

              <tr>
                <th scope="row">소속 위원회</th>
                <td>
                  <input
                    id="dept_cd"
                    name="dept_cd"
                    type="text"
                    class="form-control"
                    placeholder="소속 위원회"
                    v-validate="'required'"
                    v-model="loginInfo.dept_cd"
                  />
                  <label class="error" v-show="errors.has('dept_cd')">{{ errors.first('dept_cd') }}</label>
                </td>
              </tr>

              <tr>
                <th scope="row">휴대전화</th>
                <td>
                    <input
                    id="hp_no"
                    name="hp_no"
                    type="text"
                    class="form-control"
                    placeholder="휴대전화"
                    v-validate="'required'"
                    v-model="loginInfo.hp_no"
                  />
                  <label class="error" v-show="errors.has('hp_no')">{{ errors.first('hp_no') }}</label>
                </td>
              </tr>

              <tr>
                <th scope="row">사무실 전화</th>
                <td>
                  <input
                  id="phone_no"
                  name="phone_no"
                  type="text"
                  class="form-control"
                  placeholder="사무실 전화"
                  v-validate="'required'"
                  v-model="loginInfo.phone_no"
                />
                <label class="error" v-show="errors.has('phone_no')">{{ errors.first('phone_no') }}</label>
                </td>
              </tr>

              <tr>
                <th scope="row">이메일</th>
                <td>
                  <input
                  id="email"
                  name="email"
                  type="email"
                  class="form-control"
                  placeholder="이메일"
                  v-validate="'required'"
                  v-model="loginInfo.email"
                  />
                  <label class="error" v-show="errors.has('email')">{{ errors.first('email') }}</label>
                </td>
              </tr>
            </tbody>
          </table>
            
          <div class="list-btn-group">
            <button class="btn-strong" @click="Register">등록신청</button>
            <button class="btn-normal" @click="goRegister">다시 입력</button>
          </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getUser, setUser, getUserCheck } from "../../services";

export default {
  name: "register",
  data() {
    return {
      loginInfo: {
        user_id: "",
        password: "",
        password1: "",
        password_confirmed: "",
        user_nm: "",
        dept_cd: "",
        hp_no: "",
        phone_no: "",
        email: ""
      },
      check_id: false
    };
  },
  methods: {
    ID_Check() {
      console.log("ID 중복 확인");
      // debugger;
      if (!this.loginInfo.user_id) {
        alert("ID를 입력하세요.");
        return;
      }

      this.loginInfo.password = null;
      getUser(this.loginInfo).then(res => {
        const data = res.data;
        if (data.user_id) {
          alert("이미 사용한 아이디입니다.");
          this.check_id = false;
        } else {
          alert("사용가능한 아이디입니다.");
          this.check_id = true;
        }
        // return res;
      });
    },
    Register() {
      console.log("사용자 등록 신청");
      // if (!this.check_id) {
      //   alert("ID 중복 확인을 하세요.");
      //   return;
      // }
      // if (this.loginInfo.password1 != this.loginInfo.password_confirmed) {
      //   alert("암호가 일치하지않습니다.");
      //   return;
      // }
      // this.loginInfo.password = this.loginInfo.password1;

      this.$validator.validateAll().then(res => {
        if (res) {

          if (!this.check_id) {
            alert("ID 중복 확인을 하세요.");
            return;
          }
          if (this.loginInfo.password1 != this.loginInfo.password_confirmed) {
            alert("암호가 일치하지않습니다.");
            return;
          }
          this.loginInfo.password = this.loginInfo.password1;

          setUser(this.loginInfo).then(res => {
            this.alert(
              "사용자 등록 신청",
              `사용자 아이디 : ${res.data.user_id}\n 등록 신청되었습니다.\n 시스템 관리자가 조회·검토 후 처리하도록 하겠습니다.`,
              "success"
            ).then(() => this.$router.push({ name: "login" }));
            // ).then(() => this.$router.push({ name: 'userList' }));
          });
        }
      });

      // setUser(this.loginInfo).then(res => {
      //   this.alert(
      //     "사용자 계정 추가",
      //     `사용자 아이디 : ${res.data.user_id}\n 등록 신청되었습니다.`,
      //     "success"
      //   ).then(() => this.$router.push({ name: "login" }));
      //   // ).then(() => this.$router.push({ name: 'userList' }));
      // });
    },
    Register2() {
      console.log("사용자 등록 다시 입력");
      //document.form.reset();
      this.$router.push({ name: 'register' });
    },
    goRegister() {
      console.log("사용자 등록 다시 입력");
      this.loginInfo = "";
      this.$router.push({ name: 'register', });
    }
  },
  created() {}
};
</script>

<style>
.center {
  margin: auto;
  margin-top: 15vh;
}

.logo-image {
  width: auto !important; /*Keep the aspect ratio of the image*/
  /*height: 140px !important;*/
  margin: 0 auto 1em auto; /*Center the image*/
}
.logo-name {
  /*width: 500px;*/
  height: 120px;
  margin-bottom: 15px;
  background: url("/assets/logo.png") no-repeat center;
  background-size: contain;
  /*border: 1px solid #AAA;*/
}
.logo-title {
  position: absolute;
  top: 210px;
  left: 90px;
  /* margin-right: -50%; */
  /* transform: translate(-50%, -50%) ; */
  white-space: pre-wrap;
  color: #ffffff;
  font-family: "Helvetica Neue", sans-serif;
  font-size: 24px;
  font-weight: bold;
  letter-spacing: -2px;
  line-height: 1;
  text-align: center;
  /* text-shadow: 2px 2px 2px gray; */
}

.loginscreen.middle-box {
  /* width: 100% !important;   */
}
.middle-box {
  max-width: 520px !important;
}
</style>
