<template>
    <div class="account-wrapper login-form">
      <div class="account-body">
        <h2 class="title">비밀번호 재설정</h2>
        <div class="login-form-box" role="form" v-if="!confirm">
            <p class="desc-login">{{loginInfo.user_nm}} 의원님!<br> 입법조사요청회담시스템에 방문하신 것을 환영합니다.</p>
            <p class="desc-login">안정적이고 안전한 시스템 사용을 위해 비밀번호를 설정하여 관리하여 주십시오.</p>
            <table class="tbl-login">
              <colgroup>
              <col style="width:115px;">
              <col>
            </colgroup>
              <tbody>
                <tr>
                  <th scope="row">ID</th>
                  <td>
                    <input
                      id="user_id"
                      name="user_id"
                      type="text"
                      class="form-control"
                      placeholder="성명"
                      v-validate="'required'"
                      v-model="loginInfo.user_id"
                    />
                    <label class="error" v-show="errors.has('user_id')">{{ errors.first('user_id') }}</label>
                  </td>
                </tr>
                <tr>
                  <th scope="row">비밀번호</th>
                  <td>
                    <input
                      id="password1"
                      name="password1"
                      type="password"
                      class="form-control"
                      placeholder="비밀번호"
                      v-validate="'required'"
                      v-model="loginInfo.password1"
                    />
                    <label class="error" v-show="errors.has('password1')">{{ errors.first('password1') }}</label>
                  </td>
                </tr>
                <tr>
                    <th scope="row">비밀번호 확인</th>
                    <td>
                      <input
                        id="password2"
                        name="password2"
                        type="password"
                        class="form-control"
                        placeholder="비밀번호 확인"
                        v-validate="'required'"
                        v-model="loginInfo.password2"
                      />
                      <label class="error" v-show="errors.has('password2')">{{ errors.first('password2') }}</label>
                    </td>
                </tr>
              </tbody>
            </table>

            <div class="list-btn-group">
                <button class="btn-strong" @click="setPassword">비밀번호 변경</button>
            </div>
          </div>

          <div v-if="confirm" class="form-group">
              <label v-if="loginInfo.user_id">{{loginInfo.user_nm}}님의 ID는 {{loginInfo.user_id}}입니다.</label>
              <label v-if="!loginInfo.user_id">확인된 사용자가 없습니다.</label>
            </div>
          
          <div v-if="confirm" class="list-btn-group">
              <button v-if="!loginInfo.user_id" class="btn-primary" @click="findID2">다시찾기</button>
              <button v-if="loginInfo.user_id" class="btn-primary" @click="login">로그인</button>
          </div>
      </div>
    </div>
  </template>
  
  <script>
  // import { mapGetters, mapActions } from "vuex";
  // import { getUser, setUser, getUserCheck } from "../../services";
  import { getUser, setUser } from "../../services";
  
  export default {
    name: "forget-password",
    data() {
      return {
        loginInfo: {
          user_id: "",
          user_nm: "",
          password: "",
          password1: "",
          password2: ""
        },
        confirm: false
      };
    },
    methods: {
      setPassword() {
        if (!this.loginInfo.password1) {
          alert("비밀번호를 입력하세요.");
          this.loginInfo.password1 = "";
          this.loginInfo.password2 = "";
          return;
        }
        if (this.loginInfo.password1 != this.loginInfo.password2) {
          alert("암호가 일치하지않습니다.");
          this.loginInfo.password1 = "";
          this.loginInfo.password2 = "";
          return;
        }
        this.loginInfo.password = this.loginInfo.password1;
        this.loginInfo.password1 = "";
        this.loginInfo.password2 = "";

        setUser(this.loginInfo).then(res => {
          this.alert(
            "비밀번호 변경",
            `사용자 계정: ${res.data.user_id}\n 비밀번호가 설정되었습니다.`,
            "success"
          ).then(() => this.$router.push({ name: "main" }));
        });
      },
      // main() {
      //   this.$router.push({ name: "main" });
      // }
    },
    created() {
      // this.getUser();
          this.loginInfo.password1 = "";
          this.loginInfo.password2 = "";
      if (this.$route.query.user_id) {
        getUser(this.$route.query).then(res => {
          this.loginInfo.user_id = res.data.user_id;
          this.loginInfo.user_nm = res.data.user_nm;
          this.loginInfo.password1 = "";
          this.loginInfo.password2 = "";
        });
      }
    }
  };
  </script>
  
  <style>
  .center {
    margin: auto;
    margin-top: 15vh;
  }
  
  .logo-image {
    width: auto !important; /*Keep the aspect ratio of the image*/
    /*height: 140px !important;*/
    margin: 0 auto 1em auto; /*Center the image*/
  }
  .logo-name {
    /*width: 500px;*/
    height: 120px;
    margin-bottom: 15px;
    background: url("/assets/logo.png") no-repeat center;
    background-size: contain;
    /*border: 1px solid #AAA;*/
  }
  .logo-title {
    position: absolute;
    top: 210px;
    left: 90px;
    /* margin-right: -50%; */
    /* transform: translate(-50%, -50%) ; */
    white-space: pre-wrap;
    color: #ffffff;
    font-family: "Helvetica Neue", sans-serif;
    font-size: 24px;
    font-weight: bold;
    letter-spacing: -2px;
    line-height: 1;
    text-align: center;
    /* text-shadow: 2px 2px 2px gray; */
  }
  
  .loginscreen.middle-box {
    /* width: 100% !important;   */
  }
  .middle-box {
    max-width: 520px !important;
  }
  </style>
  