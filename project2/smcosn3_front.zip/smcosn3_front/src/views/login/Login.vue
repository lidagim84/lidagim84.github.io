<template>
  <div class="account-wrapper login-main">
    <div class="account-body">
      <h1 class="logo">
        <img src="/assets/images/logo.png" alt="서울특별시의회 입법조사회답시스템" />
      </h1>

      <h2 class="blind">로그인</h2>
      <p class="txt-login">
        입법조사회답시스템에 오신걸 환영합니다.
        <br />아이디와 비밀번호를 입력해주세요.
      </p>

      <div class="login-input-box">
        <ul class="form">
          <li>
            <div class="text-field id">
              <input
                id="user_id"
                name="user_id"
                type="text"
                placeholder="아이디"
                v-validate="'required'"
                v-model="loginInfo.user_id"
                @change="saveId"
              />
            </div>
            <label class="error" v-show="errors.has('user_id')">{{ errors.first('user_id') }}</label>
          </li>
          <li>
            <div class="text-field password">
              <input
                id="password"
                name="password"
                type="password"
                placeholder="비밀번호"
                v-validate="'required'"
                v-model="loginInfo.password"
                v-on:keyup.13="goLogin"
              />
            </div>
            <label class="error" v-show="errors.has('password')">{{ errors.first('password') }}</label>
          </li>
        </ul>

        <div class="check">
          <div class="input-group">
            <v-checkbox v-model="isSavedId" @change="saveId">ID 저장</v-checkbox>
          </div>
        </div>

        <button type="button" class="btn-login" @click="goLogin">로그인</button>

        <div class="list-append">
          <a href="#" class="link" @click="goForgotId">ID 찾기</a>
          <a href="#" class="link" @click="goForgotPassword">비밀번호 재설정</a>
          <a href="#" class="link" @click="goRegister">사용자등록 신청</a>
        </div>

        <ul class="list-login-append">
          <li>서울시 의원님은 「의정플러스+」를 통해 로그인할 수 있습니다.</li>
          <li>서울시 직원은 「행정포털」SSO를 통해 로그인해 주세요.</li>
          <li>문의전화 : 서울특별시의회 의사담당관 02-2180-7843</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getIp, insertLog } from "../../services";

export default {
  name: "login",
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      loginInfo: {
        isSavedId: false,
        user_id: "",
        password: "",
        ip: ""
      }
    };
  },
  methods: {
    ...mapActions(["login", "setAuthenticated"]),
    goLogin() {
      this.$validator.validateAll().then(res => {
        if (res) {
          // getIp().then(ipifyl => {
          //   if (ipifyl.data) {
          //     this.loginInfo.ip = ipifyl.data.ip;
          //   }

          // });
          return this.setAuthenticated(true)
            .then(() => {
              this.login(this.loginInfo).then(res => {
                // insertLog({
                //   user_id: this.loginInfo.user_id,
                //   log_type: 'login',
                //   action: 'login',
                //   ip: ipifyl.data.ip
                // });
                this.$router.push({ name: "main" });
              });
            })
            .catch(err => {
              alert("사용자 로그인 실패했습니다.");
            });
        }
      });

      // this.loginInfo.ip = '';
    },
    goForgotId() {
      this.$router.push({ name: "forgotId" });
    },
    goForgotPassword() {
      this.$router.push({ name: "forgotPassword" });
    },
    goRegister() {
      this.$router.push({ name: "register" });
    },
    saveId() {
      if (this.isSavedId == "Y")
        localStorage.setItem("saveId", this.loginInfo.user_id);
      else localStorage.removeItem("saveId");
    }
  },
  created() {
    const userId = localStorage.getItem("saveId");
    if (userId) {
      this.isSavedId = "Y";
      this.loginInfo.user_id = userId;
    }
  }
};
</script>

<style>
.center {
  margin: auto;
  margin-top: 15vh;
  color: #f3f3f4;
}

.logo-image {
  width: auto !important; /*Keep the aspect ratio of the image*/
  /*height: 140px !important;*/
  margin: 0 auto 1em auto; /*Center the image*/
}
.logo-name {
  /*width: 500px;*/
  height: 120px;
  margin-bottom: 15px;
  background: url("/assets/logo_bigsize.png") no-repeat center;
  background-size: contain;
  /*border: 1px solid #AAA;*/
}
.logo-title {
  position: absolute;
  top: 210px;
  left: 90px;
  /* margin-right: -50%; */
  /* transform: translate(-50%, -50%) ; */
  white-space: pre-wrap;
  color: #ffffff;
  font-family: "Helvetica Neue", sans-serif;
  font-size: 24px;
  font-weight: bold;
  letter-spacing: -2px;
  line-height: 1;
  text-align: center;
  /* text-shadow: 2px 2px 2px gray; */
}

.loginscreen.middle-box {
  /* width: 100% !important;   */
}
.middle-box {
  max-width: 520px !important;
}
</style>
