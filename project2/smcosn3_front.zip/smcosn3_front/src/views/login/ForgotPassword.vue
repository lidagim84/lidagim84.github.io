<template>
  <div class="account-wrapper login-form">
    <div class="account-body">
      <h2 class="title">비밀번호 찾기</h2>

      <p class="desc-login">ID가 기억나지 않으실 땐, 서울특별시의회 의사담당관실 02-2180-7846, 7842로 전화하여 문의하실 수 있습니다.</p>
      <p
        class="desc-login"
      >비밀번호가 기억나지 않으실 땐, 기존 비밀번호를 자동삭제한 후, 새로 발급된 임시비밀번호를 SMS 또는 이메일을 통해서 알려드립니다.</p>
      <p class="desc-login">기억하시는 ID와 새로 발급받으신 비밀번호로 로그인하신 후에 정보수정 페이지에서 비밀번호를 수정하실 수 있습니다.</p>
      <div class="login-form-box" role="form">
        <table class="tbl-login">
          <colgroup>
            <col style="width:90px;" />
            <col />
          </colgroup>
          <tbody>
            <tr>
              <th scope="row">ID</th>
              <td>
                <input
                  id="user_id"
                  name="user_id"
                  type="text"
                  class="form-control"
                  placeholder="아이디"
                  v-validate="'required'"
                  v-model="loginInfo.user_id"
                />
                <label class="error" v-show="errors.has('user_id')">{{ errors.first('user_id') }}</label>
                <!-- <input class="form-control" placeholder="ID" required v-model="loginInfo.user_id" /> -->
              </td>
            </tr>
            <tr>
              <th scope="row">성명</th>
              <td>
                <input
                  id="user_nm"
                  name="user_nm"
                  type="text"
                  class="form-control"
                  placeholder="성명"
                  v-validate="'required'"
                  v-model="loginInfo.user_nm"
                />
                <label class="error" v-show="errors.has('user_nm')">{{ errors.first('user_nm') }}</label>
                <!-- <input class="form-control" placeholder="성명" required v-model="loginInfo.user_nm" /> -->
              </td>
            </tr>
            <tr v-if="(picked === 'sms')">
              <th scope="row">휴대전화</th>
              <td>
                <div class="grid-box">
                  <select class="form-control" v-model="hp_no_1">
                    <option disabled value></option>
                    <option>010</option>
                    <option>011</option>
                    <option>016</option>
                    <option>017</option>
                    <option>018</option>
                    <option>019</option>
                  </select>
                  <!-- <span>선택함: {{ selected }}</span> -->
                  <input
                    id="hp_no_2"
                    name="hp_no_2"
                    type="text"
                    class="form-control"
                    v-validate="'required'"
                    v-model="hp_no_2"
                  />
                  <input
                    id="hp_no_3"
                    name="hp_no_3"
                    type="text"
                    class="form-control"
                    v-validate="'required'"
                    v-model="hp_no_3"
                  />
                  <!-- <label class="error" v-show="errors.has('hp_no')">{{ errors.first('hp_no') }}</label> -->
                  <!-- <input class="form-control" placeholder="휴대폰" required v-model="loginInfo.hp_no" /> -->
                </div>
              </td>
            </tr>
            <tr v-if="picked === 'email'">
              <th scope="row">이메일</th>
              <td>
                <input
                  id="email"
                  name="email"
                  type="email"
                  class="form-control"
                  placeholder="이메일"
                  v-validate="'required'"
                  v-model="loginInfo.email"
                />
                <label class="error" v-show="errors.has('email')">{{ errors.first('email') }}</label>
              </td>
            </tr>
          </tbody>
        </table>
        <div id="send" class="check">
          알림 받는 방법을 선택해 주세요.
          <div class="input-group">
            <div class="v-radio-group">
              <v-radio-group
                code="send_type"
                v-model="picked"
              ></v-radio-group>           
            </div>
          </div>
        </div>

        <div class="list-btn-group">
          <button class="btn-strong" @click="sendEmail">전송</button>
          <button class="btn-normal" @click="goLogin">로그인</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getUserCheck } from "../../services";

export default {
  name: "forget-password",
  data() {
    return {
      loginInfo: {
        user_id: "",
        user_nm: "",
        hp_no: "",
        email: ""
      },
      picked: "sms",
      hp_no_1: "",
      hp_no_2: "",
      hp_no_3: ""
    };
  },
  methods: {
    sendEmail() {
      this.loginInfo.hp_no = this.hp_no_1 + this.hp_no_2 + this.hp_no_3;
      if (!this.loginInfo.user_id) {
        alert("ID를 입력하세요.");
        return;
      }
      if (!this.loginInfo.user_nm) {
        alert("성명을 입력하세요.");
        return;
      }
      if (!this.loginInfo.hp_no && !this.loginInfo.email) {
        alert("휴대전화(이메일)를  입력하세요.");
        return;
      }
      getUserCheck(this.loginInfo).then(res => {
        const data = res.data;
        if (data) {
          if (this.picked === "sms") {
            alert("SMS로 비밀번호를 전송합니다.");
          } else {
            alert("email로 비밀번호를 전송합니다.");
          }

          this.alert(
            "비밀번호 전송",
            `비밀번호가 정상적으로 전송되었습니다.`,
            "success"
          ).then(() => this.$router.push({ name: "login" }));

          // this.$router.push({ name: "login" });
        }
        return res;
      });
    },
    goLogin() {
      this.$router.push({ name: "login" });
    }
  },
  created() {}
};
</script>

<style>
.center {
  margin: auto;
  margin-top: 15vh;
}

.logo-image {
  width: auto !important; /*Keep the aspect ratio of the image*/
  /*height: 140px !important;*/
  margin: 0 auto 1em auto; /*Center the image*/
}
.logo-name {
  /*width: 500px;*/
  height: 120px;
  margin-bottom: 15px;
  background: url("/assets/logo.png") no-repeat center;
  background-size: contain;
  /*border: 1px solid #AAA;*/
}
.logo-title {
  position: absolute;
  top: 210px;
  left: 90px;
  /* margin-right: -50%; */
  /* transform: translate(-50%, -50%) ; */
  white-space: pre-wrap;
  color: #ffffff;
  font-family: "Helvetica Neue", sans-serif;
  font-size: 24px;
  font-weight: bold;
  letter-spacing: -2px;
  line-height: 1;
  text-align: center;
  /* text-shadow: 2px 2px 2px gray; */
}

.loginscreen.middle-box {
  /* width: 100% !important;   */
}
.middle-box {
  max-width: 520px !important;
}
</style>
