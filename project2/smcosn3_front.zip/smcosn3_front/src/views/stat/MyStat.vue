<template>
  <div class="form-horizontal">
    <widget-container>
      <div class="tit-group">
        <h3 class="title">통계 조회</h3>
      </div>
      <div class="list-tab">
        <div class="inner">
          <ul class="tab">            
            <li :class="currentTab==0 ? 'selected' : ''">
              <a @click="changeTab(0)">의원별</a>
            </li>
            <li :class="currentTab==1 ? 'selected' : ''">
              <a @click="changeTab(1)">조사관별</a>
            </li>
            <li :class="currentTab==2 ? 'selected' : ''">
              <a @click="changeTab(2)">요청현황별</a>
            </li>
          </ul>
        </div>
      </div>

      <div class="form-box">
        <div class="form-group">
          <label class="col-sm-2 control-label">검색조건</label>
          <div class="col-sm-10 grid-box date-group">
            <datepicker
              inputClass="form-control form-control-sm"
              name="start_dt"
              v-model="start_dt"
              class="datepicker-comm"
            ></datepicker>
            <span class="txt-dash">~</span>
            <datepicker
              inputClass="form-control form-control-sm"
              name="end_dt"
              v-model="end_dt"
              class="datepicker-comm"
            ></datepicker>
            <span class="input-group-append">
              <button type="button" class="btn btn-sm btn-primary" @click="search">검색</button>
            </span>
          </div>
        </div>
      </div>
      <div class="table-responsive tbl-wrap-type1">
        <div style="padding: 8px;white-space: nowrap;">
          <i class="fa fa-list"></i>
          검색결과 : {{this.totalCount}} 건
        </div>
        <template v-if="currentTab==0">
          <v-table
            id="stat1"
            is-horizontal-resize
            style="width:100%"
            :isVerticalResize="true"
            :columns="[{field: 'log_type', title: '분류', width: 150, titleAlign: 'center', columnAlign: 'center', type:'code'},
                    {field: 'action', title: '입법정책 조사분석', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'target', title: '입안지원', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'user_id', title: '법률자문', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'user_nm', title: '전문정보 도서검색', width: 150, titleAlign: 'center', columnAlign: 'center'},                                                
                    {field: 'create_date_time', title: '계', width: 150, titleAlign: 'center', columnAlign: 'center', isResize: true}]"
            :table-data="tableData"
          ></v-table>
        </template>
        <template v-if="currentTab==1">
          <v-table
            id="stat2"
            is-horizontal-resize
            style="width:100%"
            :isVerticalResize="true"
            :columns="[{field: 'log_type', title: '분류', width: 150, titleAlign: 'center', columnAlign: 'center', type:'code'},
                    {field: 'action', title: '입법정책 조사분석', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'target', title: '입안지원', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'user_id', title: '법률자문', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'user_nm', title: '전문정보 도서검색', width: 150, titleAlign: 'center', columnAlign: 'center'},                                                
                    {field: 'create_date_time', title: '계', width: 150, titleAlign: 'center', columnAlign: 'center', isResize: true}]"
            :table-data="tableData"
          ></v-table>
        </template>
        <template v-if="currentTab==2">
          <v-table
            id="stat3"
            is-horizontal-resize
            style="width:100%"
            :isVerticalResize="true"
            :columns="[{field: 'log_type', title: '분류', width: 150, titleAlign: 'center', columnAlign: 'center', type:'code'},
                    {field: 'action', title: '요청중', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'target', title: '접수대기', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'user_id', title: '회답중', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'user_nm', title: '결재중', width: 150, titleAlign: 'center', columnAlign: 'center'},                                                
                    {field: 'ip', title: '회답완료', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'ip', title: '보류', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'ip', title: '요청철회', width: 150, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'create_date_time', title: '계', width: 150, titleAlign: 'center', columnAlign: 'center', isResize: true}]"
            :table-data="tableData"
          ></v-table>
        </template>
      </div>
    </widget-container>
  </div>
</template>

<script>
export default {
  name: "myStat",
  components: {},
  data() {
    return {
      start_dt: "",
      end_dt: "",
      totalCount: 0,
      currentTab: 0,
      tableData: []
    };
  },
  methods: {
    search() {},
    changeTab(val) {
      this.currentTab = val;
    }
  },
  created() {}
};
</script>
