<template>
  <div class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">검색조건</label>
            <div class="col-sm-10 grid-box">
              <v-dropdown
                id="publication"
                name="publication"
                inputClass="form-control form-control-sm"
                v-model="publication"
                placeholder="분류 선택"
                code="publication"
              />
              <input
                placeholder="검색어 입력"
                type="text"
                class="form-control form-control-sm"
                @keyup.13="getList"
                v-model="search_text"
              />
              <span class="input-group-append">
                <button type="button" class="btn btn-sm btn-primary" @click="search">검색</button>
              </span>
            </div>
          </div>
        </div>

        <div class="search-result">
          <div class="state-result">
            총
            <span class="number">{{totalCount}}</span>건의 검색결과가 있습니다.
          </div>

          <div class="list-result">
            <!-- 국회자료 검색결과 : 발간물 검색 -->
            <div class="result-cont" v-for="(item, index) in list" :key="index">
              <div class="tit-cont">
                <strong class="title">
                  <a href="#" @click="goDetail(item)">{{ item.BOOK_NM}}</a>
                </strong>
                <!-- <div class="control">
                  <button type="button" class="btn-strong">등록하기</button>
                  <button type="button" class="btn-normal">다운로드</button>
                </div>-->
                <div class="append">
                  <span class="date">등록일 : {{ item.INSERT_DT}}</span>
                </div>
              </div>
              <dl class="info-cont">
                <dt>분류 :</dt>
                <dd>{{ item.DIV_NM}}</dd>
                <dt>파일 :</dt>
                <dd>{{ item.PDF_FILE_NM}}</dd>
                <button
                  type="button"
                  class="btn-normal"
                  @click="fileDownload2(item.PDF_FILE_URL, item.PDF_FILE_NM)"
                >다운로드</button>
              </dl>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-12 m-t-xs align-content-center">
            <v-pager
              v-model="pageIndex"
              :page-count="pageCount"
              @change="onChange"
              @pageSizeChange="pageSizeChange"
            ></v-pager>
          </div>
        </div>
      </widget-container>
    </fieldset>
  </div>
</template>

<script>
import { setReq, getReq, deleteReq, getNADBSearchResult } from "../../services";

export default {
  name: "nadb-search-result",
  computed: {},
  data() {
    return {
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      publication: "",
      list: []
    };
  },
  watch: {
    $route(to, from) {
      this.requestInfo = {
        search_type: "1",
        req_type: "t1",
        req_no: "",
        parent_req_no: "",
        res_limit_dt: "",
        open_type: "",
        noti_type: "",
        examiner_id: "",
        examiner_nm: "",
        councilor_id: "",
        req_user_nm: "",
        supporter_id: "",
        supporter_nm: "",
        user_type: "",
        reply_list: [],
        dept_cd: "",
        update_user_idx: "test_user_01",
        create_user_idx: "test_user_01"
      };
    }
  },
  methods: {
    search() {
      if (!this.publication) {
          alert("분류를 선택해 주세요.");
          return;
        }
      this.pageIndex = 1;
      this.getList();
    },
    onChange() {
      this.getList();
    },
    pageSizeChange(val) {
      this.pageIndex = 1;
      this.pageSize = val;
      this.getList();
    },
    getList() {
      let param = this.constants.queryMap[this.publication];
      param.title = this.search_text;
      param.pageNo = this.pageIndex;
      param.pageSize = this.pageSize;
      getNADBSearchResult(param).then(res => {
        const data =
          res.data[this.constants.queryMap[this.publication].tableNm + "List"];
        this.list = data.item;
        this.totalCount = data.totalCount;
        
        if (this.totalCount==0) {
          alert("검색된 자료가 없습니다.");
          return;
        }

        this.pageCount = Math.ceil(data.totalCount / this.pageSize);
      });
    },
    goDetail(item) {
      this.$router.push({
        name: "nadbSearchResult2",
        query: {
          data_cd: item.DIV_CD,
          data_id: item.DATA_ID
        }
      });
    }
  },
  created() {
    // this.search();
  }
};
</script>
