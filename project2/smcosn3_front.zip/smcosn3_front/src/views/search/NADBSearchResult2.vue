<template>
  <div class="form-horizontal">
    <widget-container>
      <div class="search-result">
        <!-- 국회자료 검색결과 : 발간물 검색 -->
        <div class="result-cont">
          <div class="tit-cont">
            <!-- <strong class="title">{{ resultInfo.BOOK_NM}}</strong> -->
            <div class="append">
              <span class="date">등록일 : {{ resultInfo.INSERT_DT}}</span>
            </div>
          </div>
          <div class="form-box">
            <div class="form-group row">
              <label class="col-sm-2 control-label">분류</label>
              <div class="col-sm-2">
                <div class="desc">{{ resultInfo.DIV_NM}}</div>
              </div>
              <label class="col-sm-2 control-label">자료명</label>
              <div class="col-sm-6">
                <div class="desc">{{ resultInfo.BOOK_NM}}</div>
              </div>
              <!-- <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-2">
                      <div class="desc"></div>
              </div>-->
              <!-- <label class="col-sm-2 control-label">자료ID</label>
                    <div class="col-sm-4">
                      <div class="desc">{{ item.DIV_NM}}</div>
              </div>-->
            </div>
            <div class="form-group row">
              <label class="col-sm-2 control-label">PDF파일</label>
              <div class="col-sm-10">
                <div class="desc">
                  {{ resultInfo.PDF_FILE_NM}}
                  &nbsp;
                  <!-- <button type="button" class="btn-strong">미리보기</button>{{	item.VIEWER_URL}} -->
                  <button
                    type="button"
                    class="btn-normal"
                    @click="fileDownload2(resultInfo.PDF_FILE_URL)"
                  >다운로드</button>
                  <!-- {{	item.PDF_FILE_URL}} -->
                </div>
              </div>
            </div>
            <!-- <div class="form-group row">
                    <label class="col-sm-2 control-label">분류명</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.DIV_NM}}</div>
                    </div>
                    <label class="col-sm-2 control-label">분류코드</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.DIV_CD}}</div>
                    </div>
                    <label class="col-sm-2 control-label">자료명</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.BOOK_NM}}</div>
                    </div>
            </div>-->
            <div class="form-group row">
              <label class="col-sm-2 control-label">저자명</label>
              <div class="col-sm-2">
                <div class="desc">{{ resultInfo.WRITER_NM}}</div>
              </div>
              <label class="col-sm-2 control-label">저자소속</label>
              <div class="col-sm-2">
                <div class="desc">{{ resultInfo.WRITER_DEPT_NM}}</div>
              </div>
              <label class="col-sm-2 control-label">출처명</label>
              <div class="col-sm-2">
                <div class="desc">{{ resultInfo.SRC_DATA_NM}}</div>
              </div>
            </div>
            <!-- <div class="form-group row">
                    <label class="col-sm-2 control-label">출처명</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.SRC_DATA_NM}}</div>
                    </div>
                    <label class="col-sm-2 control-label">출처URL</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.SRC_LINK_URL}}</div>
                    </div>
                    <label class="col-sm-2 control-label">주제</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.CHARGE_NM}}</div>
                    </div>
                    <label class="col-sm-2 control-label">출처발행기관URL</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.SRC_ORG_URL}}</div>
                    </div>
            </div>-->
            <div class="form-group row">
              <label class="col-sm-2 control-label">출처발행기관</label>
              <div class="col-sm-2">
                <div class="desc">{{ resultInfo.SRC_PUBLIC_INSTT}}</div>
              </div>
              <label class="col-sm-2 control-label">출처발행일</label>
              <div class="col-sm-2">
                <div class="desc">{{ resultInfo.SRC_PUBLIC_DT}}</div>
              </div>
              <label class="col-sm-2 control-label">출처발행주기</label>
              <div class="col-sm-2">
                <div class="desc">{{ resultInfo.SRC_PUBLIC_CYCLE_NM}}</div>
              </div>
            </div>
            <!-- <div class="form-group row">
                    <label class="col-sm-2 control-label">키워드</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.KEY_WORD}}</div>
                    </div>
                    <label class="col-sm-2 control-label">등록일</label>
                    <div class="col-sm-2">
                      <div class="desc">{{	item.INSERT_DT}}</div>
                    </div>
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-2">
                      <div class="desc"></div>
                    </div>
            </div>-->
          </div>
          <!-- 내용 -->
          <div v-html="resultInfo.CONTENTS" class="content"></div>
          <!-- //내용 -->
        </div>
      </div>
      <div class="list-btn-group group-submit">
        <div class="float-right">
          <button type="button" class="btn-strong" @click="$router.push({name:'nadbSearchResult'})">목록으로</button>
          <!-- <button type="button" class="btn-normal" @click="goList">목록으로</button> -->
          <!-- <button type="button" class="btn-normal">삭제</button> -->
        </div>
      </div>
    </widget-container>
  </div>
</template>

<script>
import {
  setReq,
  getReq,
  deleteReq,
  getNADBSearchDetailResult
} from "../../services";

export default {
  name: "nadb-search-result",
  computed: {},
  data() {
    return {
      resultInfo: {}
    };
  },
  methods: {
    goDetail(item) {
      getNADBSearchDetailResult({
        ...this.constants.queryMap[item.data_cd],
        data_id: item.data_id,
        data_cd: item.data_cd
      }).then(res => {
        const data =
          res.data[this.constants.queryMap[item.data_cd].tableNm + "Item"];
        if (data.item && data.item.length) {
          this.resultInfo = data.item[0];
        }
      });
    }
  },
  created() {
    const query = this.$route.query;
    if (query) {
      this.goDetail(query);
    }
  }
};
</script>
