<template>
  <form class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">기간</label>
            <div class="col-sm-4">
              <div class="input-group">
                <div class="v-radio-group">
                  <div class="input-group">
                    <label class="v-radio-wrapper" style="display: inline-block;">
                      <span class="v-radio"><input type="radio" class="v-radio-input" value=""><span class="v-radio-inner"></span></span>
                      <span>1일</span>
                    </label>
                    <label class="v-radio-wrapper" style="display: inline-block;">
                      <span class="v-radio"><input type="radio" class="v-radio-input" value=""><span class="v-radio-inner"></span></span>
                      <span>1주일</span>
                    </label>
                    <label class="v-radio-wrapper" style="display: inline-block;">
                      <span class="v-radio"><input type="radio" class="v-radio-input" value=""><span class="v-radio-inner"></span></span>
                      <span>1개월</span>
                    </label>
                    <label class="v-radio-wrapper" style="display: inline-block;">
                      <span class="v-radio"><input type="radio" class="v-radio-input" value=""><span class="v-radio-inner"></span></span>
                      <span>1년</span>
                    </label>
                    <label class="v-radio-wrapper" style="display: inline-block;">
                      <span class="v-radio"><input type="radio" class="v-radio-input" value=""><span class="v-radio-inner"></span></span>
                      <span>직접선택</span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="grid-box date-group"><!-- 직접선택시 나타남 -->
                <datepicker
                  inputClass="form-control form-control-sm"
                  name="start_dt"
                  v-model="start_dt"
                  class="datepicker-comm"
                ></datepicker>
                <span class="txt-dash">~</span>
                <datepicker
                  inputClass="form-control form-control-sm"
                  name="end_dt"
                  v-model="end_dt"
                  class="datepicker-comm"
                ></datepicker>
              </div>
            </div>

            <label class="col-sm-2 control-label">영역</label>
            <div class="col-sm-4">
              <v-dropdown
                id="state"
                name="state"
                inputClass="form-control form-control-sm"
                v-model="state"
                placeholder="전체"
                code="task_state"
              />
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 control-label">검색어 설정</label>
            <div class="col-sm-10 grid-box search-group">
              <div class="text-field">
                <span class="tf-title">기본검색어</span>
                <input
                  type="text"
                  class="form-control"
                  placeholder="제목을 입력하세요"
                />
              </div>
              <div class="text-field">
                <span class="tf-title">AND검색어</span>
                <input
                  type="text"
                  class="form-control"
                  placeholder="같이 검색하는 포함 단어"
                />
              </div>
              <div class="text-field">
                <span class="tf-title">BUT 검색어</span>
                <input
                  type="text"
                  class="form-control"
                  placeholder="제외하여 검색하는 단어"
                />
              </div>
              <span class="input-group-append">
                <button
                  type="button"
                  class="btn btn-sm btn-primary"
                  @click="search"
                >검색</button>
              </span>
            </div>
          </div>
        </div>

        <div class="search-result">
          <div class="state-result">
              검색어 <strong class="keyword">지방분권</strong> 총 <span class="number">10</span>건의 검색결과가 있습니다.
          </div>
          <div class="list-result">                
            <div class="result-cont">
              <div class="tit-cont">
                <strong class="title"><a href="#">지방재정 및 예산 편성 위원회 활동 보고서 자료분석 요청</a></strong>
                <div class="append">
                  <span class="date">2019.10.22</span>
                </div>
              </div>
              <ul class="attach-cont">
                <li><a href="#none" class="link">지역아동센터 지원사업의현황과 과제.PDF</a></li>
                <li><a href="#none" class="link">기술평가제도 활성화를 위한 과제.PDF</a></li>
              </ul>
            </div>
            <div class="result-cont">
              <div class="tit-cont">
                <strong class="title"><a href="#">지방재정 및 예산 편성 위원회 활동 보고서 자료분석 요청</a></strong>
                <div class="append">
                  <span class="date">2019.10.22</span>
                </div>
              </div>
              <ul class="attach-cont">
                <li><a href="#none" class="link">지역아동센터 지원사업의현황과 과제.PDF</a></li>
                <li><a href="#none" class="link">기술평가제도 활성화를 위한 과제.PDF</a></li>
              </ul>
            </div>
          </div>
        </div>


        <div class="row">
          <div class="col-sm-12 m-t-xs align-content-center">
            <v-pager
              v-model="pageIndex"
              :page-count="pageCount"
              @change="onChange"
              @pageSizeChange="pageSizeChange"
            ></v-pager>
          </div>
        </div>
      </widget-container>
    </fieldset>
  </form>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getIp, insertLog } from "../../services";

export default {
  name: "search-result",
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      loginInfo: {
        user_id: "",
        password: "",
        ip: ""
      }
    };
  },
  methods: {
    ...mapActions(["login", "setAuthenticated"]),
    goLogin() {
      this.$validator.validateAll().then(res => {
        if (res) {
          getIp().then(ipifyl => {
            if (ipifyl.data) {
              this.loginInfo.ip = ipifyl.data.ip;
            }
            return this.setAuthenticated(true).then(() => {
              this.login(this.loginInfo).then(() => {
                insertLog({
                  user_id: this.loginInfo.user_id,
                  log_type: "login",
                  action: "login",
                  ip: ipifyl.data.ip
                });
                this.$router.push({ name: "main" });
              });
            });
          });
        }
      });

      // this.loginInfo.ip = '';
    }
  },
  created() {}
};
</script>

<style>
.search-form .input-group .form-control {
  height: 46px;
}
</style>
