<template>
  <form class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-1 control-label">상태</label>
            <div class="col-sm-2">
              <v-dropdown
                id="state"
                name="state"
                inputClass="form-control form-control-sm"
                v-model="state"
                placeholder="전체"
                code="task_state"
              />
            </div>
            <label class="col-sm-1 control-label">날짜</label>
            <div class="col-sm-2 grid-box date-group">
              <datepicker
                inputClass="form-control form-control-sm"
                name="start_dt"
                v-model="start_dt"
                class="datepicker-comm"
              ></datepicker>
              <span class="txt-dash">~</span>
              <datepicker
                inputClass="form-control form-control-sm"
                name="end_dt"
                v-model="end_dt"
                class="datepicker-comm"
              ></datepicker>
            </div>
            <label class="col-sm-1 control-label">분류</label>
            <div class="col-sm-5 grid-box">
              <v-dropdown
                id="vio_cd"
                name="vio_cd"
                inputClass="form-control form-control-sm"
                v-model="vio_cd"
                style="width:100px"
                placeholder="전체"
                code="vio_cd"
              />
              <v-dropdown
                id="search_type"
                name="search_type"
                inputClass="form-control form-control-sm"
                v-model="search_type"
                style="width:100px"
                placeholder
                :options="[{label:'제목+내용', value:'case_name'},{label:'담당부서', value:'case_no'},{label:'회답인', value:'keyword'}]"
              />
              <input
                placeholder="검색어 입력"
                type="text"
                class="form-control form-control-sm"
                @keyup.13="getList"
                v-model="search_text"
              />
              <span class="input-group-append">
                <button type="button" class="btn btn-sm btn-primary" @click="search">검색</button>
              </span>
            </div>
          </div>
        </div>
        <!-- <div class="hr-line-dashed"></div> -->
        <div class="table-responsive tbl-wrap-type1">
          <div style="padding: 8px;white-space: nowrap;">
            <i class="fa fa-list"></i>
            검색결과 : {{this.totalCount | numberComma}} 건
          </div>
          <v-table
            is-horizontal-resize
            style="width:100%"
            :isVerticalResize="true"
            :columns="[ {field: 'match_id', width: 60, titleAlign: 'center',columnAlign:'center',type: 'selection',isFrozen:true},
                        {field: 'match_id', title: '매칭번호', width: 100, titleAlign: 'center', columnAlign: 'center', orderBy:'desc'},                      
                        {field: 'req_type', title: '요청분류', width: 80, titleAlign: 'center', columnAlign: 'center', formatter: (rowData,rowIndex,pagingIndex,field) => this.setReqTypeStyle(rowData.req_type)},                        
                        {field: 'match_title', title: 'Matching제목', width: 100, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'req_title', title: '요청제목', width: 100, titleAlign: 'center', columnAlign: 'left', isResize: true},                        
                        {field: 'councilor_nm', title: '요청자', width: 80, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'bill_title', title: '의안발의제목', width: 100, titleAlign: 'center', columnAlign: 'left', isResize: true},                        
                        {field: 'bill_nm', title: '대표발의자', width: 80, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'bill_date', title: '매칭일자', width: 100, titleAlign: 'center', columnAlign: 'center', type: 'datetime'},
                        {field: 'examiner_nm', title: '조사관', width: 80, titleAlign: 'center', columnAlign: 'center'}]"
            :table-data="tableData"
            :select-change="selectChange"
            :select-all="selectList"
            :row-click="selectRow"
          ></v-table>
        </div>
        <div class="row">
          <div class="col-sm-12 m-t-xs align-content-center">
            <v-pager
              v-model="pageIndex"
              :page-count="pageCount"
              @change="onChange"
              @pageSizeChange="pageSizeChange"
            ></v-pager>
          </div>
        </div>

        <div class="list-btn-group group-submit">
          <div class="float-right">
            <button type="button" class="btn-strong" @click="$router.push('responseInitMatching')">신규매칭</button>
            <button type="button" class="btn-strong" @click="deleteItem2">선택삭제</button>
          </div>
        </div>
      </widget-container>
    </fieldset>
  </form>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getResBillMatchList, getResList, deleteResBillMatch } from "../../services";
import { StatBox } from "../common";

export default {
  name: "responseInitMatchingList",
  components: {
    StatBox
  },
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      start_dt: "",
      end_dt: "",
      user_id: "",
      user_nm: "",
      state: "",
      search_text: "",
      search_type: "case_name",
      user_type: "",
      vio_cd: ""
    };
  },
  watch: {
    $route(to, from) {
      if (to.query.page_index) {
        this.pageIndex = Number(to.query.page_index);
      } else {
        this.pageIndex = 1;
      }
      this.state = to.query.state;
      this.getList();
    }
  },
  methods: {
    ...mapActions(["getUserInfo"]),
    onChange() {
      this.$router.push({
        name: "requestList",
        query: { page_index: this.pageIndex }
      });
    },
    pageSizeChange(val) {
      this.pageIndex = 1;
      this.pageSize = val;
      this.getList();
    },
    selectRow(rowIndex, rowData) {
      this.$router.push({
        name: "responseInitMatchiingDetail",
        query: { req_no: rowData.req_no, match_id: rowData.match_id }
      });
    },
    getList() {
      const isReqUser = this.isReqUser;
      this.user_type = "";
      this.user_id = "";
      if (isReqUser) {
        this.user_type = this.loginUserInfo.user_type + "_ID";
        this.user_id = this.loginUserInfo.user_id;
      } else if (isReqUser && !this.isTeamLeaderAndAdmin) {
        this.user_type = this.constants.RoleType.Examiner + "_ID";
        this.user_id = this.loginUserInfo.user_id;
      }
      return getResBillMatchList({
//      return getResList({

        page_index: this.pageIndex,
        page_size: this.pageSize,
        user_type: this.user_type,
        user_id: this.user_id,
        state: this.state,
        search_text: this.search_text,
        search_type: this.search_type
      }).then(res => {
        const data = res.data;
        this.totalCount = data.TOTAL_COUNT;
        this.pageCount = Math.ceil(data.TOTAL_COUNT / this.pageSize);
        this.tableData = data.list;
      });
    },
    deleteItem(rowIndex, rowData) {
      allert("삭제합니다.");
      return deleteResBillMatch(this.rowData.match_id).then(res => {
        this.$router.push({ name: "responseInitMatchingList" });
        return res;
      });
    },    
    deleteItem2() {
      // if (!this.loginInfo.user_nm) {
      //   alert("성명을 입력하세요.");
      //   return;
      // }
      // if (!this.loginInfo.hp_no) {
      //   alert("휴대전화 번호를 입력하세요.");
      //   return;
      // }
      // if (!this.loginInfo.email) {
      //   alert("이메일을 입력하세요.");
      //   return;
      // }
      // this.$validator.validateAll().then(res => {
      //   if (res) {
          alert("삭제하자.");
          deleteResBillMatch(this.tableData.match_id).then(res => {
            this.$router.push({ name: "responseInitMatchingList" });
            return res;

            // const data = res.data;
            // this.confirm = true;
            // if (data) {
            //   this.loginInfo = data;
            // }
            // return data;
          });
    },
    sortChange(params) {},
    search() {
      this.pageIndex = 1;
      this.getList();
    }
  },
  mounted() {
    const query = this.$route.query;
    if (query.state) {
      this.state = query.state;
    }
    if (query.page_index) {
      this.pageIndex = Number(query.page_index);
    }
    this.getList();
  }
};
</script>
