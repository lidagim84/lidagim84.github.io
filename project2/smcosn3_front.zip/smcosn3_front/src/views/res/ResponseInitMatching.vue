<template>
  <form class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">Matching 제목</label>
            <div class="col-sm-10">
                <input
                type="text"
                class="form-control"
                placeholder="제목을 입력하세요"
              />
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 control-label">입법조사요청</label>
            <div class="col-sm-10 grid-box">
                <input
                placeholder="검색어 입력"
                type="text"
                class="form-control form-control-sm"
                @keyup.13="getList"
              />
              <span class="input-group-append">
                <button type="button" class="btn btn-sm btn-primary" @click="search">검색</button>
              </span>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">의안발의</label>
            <div class="col-sm-10 grid-box">
                <input
                placeholder="검색어 입력"
                type="text"
                class="form-control form-control-sm"
                @keyup.13="getList"
              />
              <span class="input-group-append">
                <button type="button" class="btn btn-sm btn-primary" @click="search">검색</button>
              </span>
            </div>
          </div>
        </div>

        <div class="list-btn-group group-submit">
            <div class="float-right">
              <button type="button" class="btn-strong" @click="setMatch">등록</button>
              <button type="button" class="btn-normal" @click="$router.push('responseInitMatchingList')">목록</button>
            </div>
          </div>
      </widget-container>
    </fieldset>
  </form>
</template>

<script>

import { getRes, setResBillMatch } from "../../services";

export default {
  name: "responseInitMatching",
  data() {
    return {
      billInfo: {
        match_id: "7",
        req_no: "2019-0028",
        bill_id: "5",
        bill_title: "발의 제목",
        bill_nm: "발의자",
        bill_date: "2019.01.01",
        match_title: "",
        bill_div: "",
        bill_type: "",
        bill_nm2: "",
        com_nm: "",
        com_date: "",
        com_result: "",
        bon_date: "",
        bon_result: "",
        update_user_idx: "",
        create_user_idx: ""
      },
      equipData: [],
      staffData: [],
      selectedEquip: []
    };
  },
  methods: {
    approve() {},
    approveReq(state, title) {
      Promise.all([
        this.$validator.validateAll(),
        this.$refs.task.$validator.validateAll()
      ]).then(res => {
        if (res[0] && res[1]) {
          this.setRes(state, title);
        }
      });
    },
    getRes() {
      getRes(this.responseInfo).then(res => {
        this.responseInfo = res.data;
      });
    },
    setMatch() {
      alert(this.billInfo.match_id);
      setResBillMatch(this.billInfo).then(res => {
        this.alert(
          "매칭완료",
          `매칭번호: \n 저장 했습니다.`,
          "success"
        ).then(() => {
          // if (this.isAdmin) this.$router.push({ name: "userList" });
          this.$router.push({ name: "responseInitMatchingList" });
        });
      });
    },    
    setMatch2() {
      alert("매칭하자");
        debugger;
      return setResBillMatch(this.billInfo).then(res => {
        const data = res.data;
        // //fileupload
        // return Promise.all([
        //   this.$refs.task.setTaskInfo(data.res_no, state)
        // ]).then(() => {
        this.alert(
          "매칭완료",
          `매칭번호: ${data.match_id}\n${data.match_title} 매칭 했습니다.`,
          "success"
        ).then(() =>
          this.$router.push({ name: "responseInitMatchingList" })
        );
      });
    },
    setCurrentTaskInfo(task) {
      this.responseInfo.state = task.state;
    }
  },
  created() {
  }
};
</script>
