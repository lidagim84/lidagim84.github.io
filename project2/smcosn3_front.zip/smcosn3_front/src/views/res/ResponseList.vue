<template>
  <form class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-1 control-label">분류</label>
            <div class="col-sm-2">
              <v-dropdown
                id="req_type"
                name="req_type"
                style="width:100px"
                inputClass="form-control form-control-sm"
                v-model="req_type"
                placeholder="전체"
                code="req_type"
              />
            </div>
            <label class="col-sm-1 control-label">요청일</label>
            <div class="col-sm-4 grid-box date-group">
              <datepicker
                inputClass="form-control form-control-sm"
                name="start_dt"
                v-model="start_dt"
                class="datepicker-comm"
              ></datepicker>
              <span class="txt-dash">~</span>
              <datepicker
                inputClass="form-control form-control-sm"
                name="end_dt"
                v-model="end_dt"
                class="datepicker-comm"
              ></datepicker>
            </div>
            <label class="col-sm-1 control-label">검색어</label>
            <div class="col-sm-4 grid-box">
              <v-dropdown
                id="search_type"
                name="search_type"
                inputClass="form-control form-control-sm"
                v-model="search_type"
                style="width:200px"
                placeholder
                :options="[{label:'제목', value:'m.value'},{label:'담당팀', value:'dept_cd'}]"
              />
              <input
                placeholder="검색어 입력"
                type="text"
                class="form-control form-control-sm"
                @keyup.13="getList"
                v-model="search_text"
              />
              <span class="input-group-append">
                <button type="button" class="btn btn-sm btn-primary" @click="search()">검색</button>
              </span>
            </div>
          </div>
        </div>
        <!-- <div class="hr-line-dashed"></div> -->
        <div class="table-responsive">
          <div style="padding: 8px;white-space: nowrap;">
            <i class="fa fa-list"></i>
            검색결과 : {{this.totalCount | numberComma}} 건
          </div>
          <div class="tbl-wrap-type1">
            <v-table
              is-horizontal-resize
              style="width:100%"
              :isVerticalResize="true"
              :columns="[{field: 'row_no', title: '번호', width: 50, titleAlign: 'center', columnAlign: 'center'},                      
                          {field: 'req_type', title: '요청분류', width: 90, titleAlign: 'center', columnAlign: 'center', formatter: (rowData,rowIndex,pagingIndex,field) => this.setReqTypeStyle(rowData.req_type)},                        
                          {field: 'req_no', title: '요청번호', width: 90, titleAlign: 'center', columnAlign: 'center', formatter: (rowData,rowIndex,pagingIndex,field) => this.parseReqNo(rowData.req_no)},
                          {field: 'req_title', title: '요청제목', width: 150, titleAlign: 'center', columnAlign: 'left', isResize: true},                        
                          {field: 'councilor_nm', title: '요청자', width: 70, titleAlign: 'center', columnAlign: 'center'},
                          {field: 'dept_cd', title: '담당팀', width: 90, titleAlign: 'center', columnAlign: 'center', type:'code'},                        
                          {field: 'examiner_nm', title: '조사관', width: 70, titleAlign: 'center', columnAlign: 'center'},
                          {field: 'state', title: '상태', width: 290, titleAlign: 'center', columnAlign: 'center', formatter: (rowData,rowIndex,pagingIndex,field) => this.sateProress(rowData.state, rowData.pre_state)},                                    
                          {field: 'create_date_time', title: '요청일', width: 90, titleAlign: 'center', columnAlign: 'center', type: 'datetime'},
                          {field: 'res_limit_dt', title: '회답기한', width: 90, titleAlign: 'center', columnAlign: 'center', type: 'datetime'},
                          {field: 'res_dt', title: '회답일', width: 90, titleAlign: 'center', columnAlign: 'center', type: 'datetime'}]"
              :table-data="tableData"
              :row-click="selectRow"
            ></v-table>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 m-t-xs align-content-center">
            <v-pager
              v-model="pageIndex"
              :page-count="pageCount"
              @change="onChange"
              @pageSizeChange="pageSizeChange"
            ></v-pager>
          </div>
        </div>
      </widget-container>
    </fieldset>
  </form>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getResList } from "../../services";

export default {
  name: "responseList",
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      start_dt: this.getDateAgo(6, "month"),
      end_dt: "",
      user_id: "",
      user_nm: "",
      state: "",
      search_text: "",
      search_type: "m.value",
      user_type: "",
      user_id: ""
    };
  },
  watch: {
    $route(to, from) {
      if (to.query.page_index) {
        this.pageIndex = Number(to.query.page_index);
      } else {
        this.pageIndex = 1;
      }
      this.state = to.query.state;
      this.getList();
    }
  },
  methods: {
    ...mapActions(["getUserInfo"]),
    onChange() {
      this.$router.push({
        name: "responseList",
        query: { page_index: this.pageIndex }
      });
    },
    pageSizeChange(val) {
      this.pageIndex = 1;
      this.pageSize = val;
      this.getList();
    },
    selectRow(rowIndex, rowData) {
      this.$router.push({
        name: "response",
        query: {
          req_type: rowData.req_type,
          req_no: rowData.req_no,
          res_no: rowData.res_no
        }
      });
    },
    getList() {
      this.user_type = this.userIdProp;
      this.user_id = this.loginUserInfo.user_id;
      if (this.user_type == this.constants.RoleType.TeamMember + "_id") {
        this.state = this.constants.ReqState.COMPLETE;
      }
      return getResList({
        page_index: this.pageIndex,
        page_size: this.pageSize,
        req_type: this.req_type,
        start_dt: this.start_dt,
        end_dt: this.end_dt,
        user_type: this.user_type,
        user_id: this.user_id,
        search_text: this.search_text,
        search_type: this.search_type,
        state: this.state,
        state_list: this.state_list
      }).then(res => {
        const data = res.data;
        this.totalCount = data.TOTAL_COUNT;
        this.pageCount = Math.ceil(data.TOTAL_COUNT / this.pageSize);
        this.tableData = data.list;
      });
    },
    sortChange(params) {},
    selectManager() {
      this.addMng(false).then(res => {
        if (res) {
          this.user_id = res.user_id;
          this.user_nm = res.user_nm;
        }
        return res;
      });
    },
    search(filterItem) {
      if (filterItem) {
        this.state_list = filterItem.split("_");
      } else {
        this.state_list = [];
      }
      this.pageIndex = 1;
      this.getList();
    }
  },
  mounted() {
    const query = this.$route.query;
    if (query.state) {
      this.state = query.state;
    }
    if (query.page_index) {
      this.pageIndex = Number(query.page_index);
    }
    this.getList();
  }
};
</script>