<template>
  <div class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="tit-group">
          <h3 class="title">요청서</h3>
        </div>
        <request-info :req_no="responseInfo.req_no" :showContent="true"></request-info>
        <response-info :req_no="responseInfo.req_no" v-if="responseInfo.res_no && !isEditable"></response-info>
        <template v-if="isEditable">
          <div class="tit-group">
            <h3 class="title">회답서</h3>
          </div>
          <p class="label-required">
            <span class="required">*</span>필수값
          </p>
          <div class="form-box">
            <div class="form-group row">
              <label class="col-sm-2 control-label">회답서 제목</label>
              <div class="col-sm-10">
                <input
                  id="res_title"
                  name="res_title"
                  type="text"
                  class="form-control"
                  v-validate="required"
                  v-model="responseInfo.res_title"
                />
                <label
                  class="error"
                  v-show="errors.has('res_title')"
                >{{ errors.first('res_title') }}</label>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 text-sm-right control-label">회답 파일</label>
              <div class="col-sm-10">
                <v-fileupload ref="fileupload" multiple="true" v-model="responseInfo.res_no"></v-fileupload>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 control-label">메모</label>
              <div class="col-sm-10">
                <textarea
                  id="res_content"
                  name="res_content"
                  class="form-control"
                  v-validate="required"
                  v-model="responseInfo.res_content"
                />
                <label
                  class="error"
                  v-show="errors.has('res_content')"
                >{{ errors.first('res_content') }}</label>
              </div>
            </div>
          </div>
        </template>
        <task
          ref="task"
          job_id="response"
          :task_id="responseInfo.req_no"
          :user_id="responseInfo.create_user_idx"
          @approveReq="approveReq"
          @deleteItem="deleteItem"
          @approve="approve"
        ></task>
        <!-- <comment slot="footer"></comment> -->
      </widget-container>
    </fieldset>
  </div>
</template>

<script>
import { Task } from "../common";
import RequestInfo from "../req/RequestInfo";
import ResponseInfo from "./ResponseInfo";
import { setRes, getRes, deleteRes, createExchangeXML } from "../../services";

export default {
  name: "response",
  components: {
    Task,
    RequestInfo,
    ResponseInfo
  },
  data() {
    return {
      responseInfo: {
        req_no: "",
        req_type: "",
        res_title: "",
        res_content: "",
        state: "",
        examiner_id: "",
        examiner_nm: "",
        update_user_idx: "",
        create_user_idx: ""
      },
      equipData: [],
      staffData: [],
      selectedEquip: []
    };
  },
  computed: {
    isEditable() {
      return (
        this.isEditableState(this.responseInfo.state) &&
        (this.isTeamLeaderAndAdmin ||
          this.responseInfo.examiner_id == this.loginUserInfo.user_id)
      );
    }
  },
  methods: {
    approve(state) {
      // this.getRes();
      if (constants.ReqState.APPROVE == state) {
        //기안전송.
        createExchangeXML(this.responseInfo).then(res => {});
      }
    },
    approveReq(state, title) {
      Promise.all([
        this.$validator.validateAll(),
        this.$refs.task.$validator.validateAll()
      ]).then(res => {
        if (res[0] && res[1]) {
          this.setRes(state, title);
        }
      });
    },
    getRes() {
      getRes(this.responseInfo).then(res => {
        this.responseInfo = res.data;
      });
    },
    setRes(state, title) {
      return this.$refs.fileupload.uploadFile().then(resFileList => {
        return setRes(this.responseInfo).then(res => {
          const data = res.data;
          this.responseInfo = data;
          return Promise.all([
            this.$refs.fileupload.setFileList(data.res_no, resFileList),
            this.$refs.task.setTaskInfo(data.res_no, state)
          ]).then(() => {
            this.alert(
              title,
              `요청번호: ${this.parseReqNo(data.req_no)}\n회답 처리했습니다.`,
              "success"
            ).then(() => this.$router.push({ name: "responseList" }));
          });
        });
      });
    },
    deleteItem() {
      return deleteRes(this.responseInfo).then(res => {
        this.$router.push({ name: "responseList" });
        return res;
      });
    },
    selectedApprover(roleType) {
      let filter = null;
      if (roleType != "examiner") {
        filter = { user_type: roleType };
      }
      this.addMng(false, filter).then(res => {
        if (res) {
          this.responseInfo[roleType + "_id"] = res.user_id;
          this.responseInfo[roleType + "_nm"] = res.user_nm;
          this.responseInfo[roleType + "_dept_cd"] = res.dept_cd;
        }
        return res;
      });
    }
  },
  created() {
    if (this.$route.query.req_no) {
      this.responseInfo.req_no = this.$route.query.req_no;
      this.getRes();
    }
  }
};
</script>
