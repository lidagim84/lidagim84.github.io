<template>
  <div class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="tit-group">
          <h3 class="title">요청서</h3>
        </div>
        <request-info :req_no="responseInfo.req_no" :showContent="true"></request-info>
        <!-- <response-info :req_no="responseInfo.req_no" v-if="isEditable"></response-info> -->
        <!-- <template v-if="!isEditable"> -->
        <template>  
          <div class="tit-group">
            <h3 class="title">의안 발의</h3>
          </div>
          <div class="form-box">
            <div class="form-group row">
              <label class="col-sm-2 control-label">의안번호</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.bill_id}}</div>
              </div>
              <label class="col-sm-2 control-label">제안일</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.bill_date}}</div>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 control-label">의안구분</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.bill_div}}</div>
              </div>
              <label class="col-sm-2 control-label">의안종류</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.bill_type}}</div>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 control-label">대표발의자</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.bill_nm}}</div>
              </div>
              <label class="col-sm-2 control-label">상임위명</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.com_nm}}</div>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 control-label">상임위 상정일</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.com_date}}</div>
              </div>
              <label class="col-sm-2 control-label">상임위 결과</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.com_result}}</div>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 control-label">본회의 상정일</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.bon_date}}</div>
              </div>
              <label class="col-sm-2 control-label">본회의 결과</label>
              <div class="col-sm-4">
                <div class="desc">{{billInfo.bon_result}}</div>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 control-label">의안발의 제목</label>
              <div class="col-sm-10">
                <div class="desc">{{billInfo.bill_title}}</div>
              </div>
            </div>
          </div>
        </template>
        <div class="list-btn-group group-submit">
          <div class="float-right">
            <button type="button" class="btn-strong" @click="deleteItem">삭제</button>
            <button type="button" class="btn-strong" @click="$router.push('responseInitMatchingList')">목록으로</button>
          </div>
        </div>

        <!-- <task
          ref="task"
          job_id="response"
          :task_id="responseInfo.req_no"
          :user_id="responseInfo.create_user_idx"
          @approveReq="approveReq"
          @deleteItem="deleteItem"
          @approve="approve"
        ></task> -->
        <!-- <comment slot="footer"></comment> -->
      </widget-container>
    </fieldset>
  </div>
</template>

<script>
import { Task } from "../common";
import RequestInfo from "../req/RequestInfo";
import ResponseInfo from "./ResponseInfo";
import { setRes, getRes, deleteRes, getResBillMatch, deleteResBillMatch } from "../../services";

export default {
  name: "response",
  components: {
    Task,
    RequestInfo,
    ResponseInfo
  },
  data() {
    return {
      responseInfo: {
        req_no: "",
        req_type: "",
        res_title: "",
        res_content: "",
        state: "",
        examiner_id: "",
        examiner_nm: "",
        update_user_idx: "",
        create_user_idx: ""
      },
      billInfo: {
        bill_id: "",
        bill_title: "",
        bill_nm: "",
        bill_date: "",
        bill_div: "",
        bill_type: "",
        bill_nm2: "",
        com_nm: "",
        com_date: "",
        com_result: "",
        bon_date: "",
        bon_result: ""
      },
      equipData: [],
      staffData: [],
      selectedEquip: []
    };
  },
  computed: {
    isEditable() {
      return (
        this.isEditableState(this.responseInfo.state) &&
        (this.isAdmin ||
          this.responseInfo.examiner_id == this.loginUserInfo.user_id)
      );
    }
  },
  methods: {
    approve(state) {
      this.getRes();
    },
    approveReq(state, title) {
      Promise.all([
        this.$validator.validateAll(),
        this.$refs.task.$validator.validateAll()
      ]).then(res => {
        if (res[0] && res[1]) {
          this.setRes(state, title);
        }
      });
    },
    getRes() {
      getRes(this.responseInfo).then(res => {
        this.responseInfo = res.data;
      });
    },
    getResBillMatch() {
      getResBillMatch(this.billInfo).then(res => {
        this.billInfo = res.data;
      });
    },
    setRes(state, title) {
      return setRes(this.responseInfo).then(res => {
        const data = res.data;
        this.responseInfo = data;
        return Promise.all([
          this.$refs.task.setTaskInfo(data.res_no, state)
        ]).then(() => {
          this.alert(
            title,
            `회답번호: ${data.res_no}\n${title} 했습니다.`,
            "success"
          ).then(() => this.$router.push({ name: "responseList" }));
        });
      });
    },
    deleteItem() {
      alert("매칭 데이터가 삭제됩니다.");
      return deleteResBillMatch(this.billInfo).then(res => {
        this.$router.push({ name: "responseInitMatchingList" });
        return res;
      });
    },
    selectedApprover(roleType) {
      let filter = null;
      if (roleType != "examiner") {
        filter = { user_type: roleType };
      }
      this.addMng(false, filter).then(res => {
        if (res) {
          this.responseInfo[roleType + "_id"] = res.user_id;
          this.responseInfo[roleType + "_nm"] = res.user_nm;
          this.responseInfo[roleType + "_dept_cd"] = res.dept_cd;
        }
        return res;
      });
    }
  },
  created() {
    if (this.$route.query.match_id) {
      this.billInfo.match_id = this.$route.query.match_id;
      this.getResBillMatch();
    }
    if (this.$route.query.req_no) {
      this.responseInfo.req_no = this.$route.query.req_no;
      this.getRes();
    }
  }
};
</script>
