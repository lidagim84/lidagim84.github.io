<template>
  <div>
    <div class="tit-group">
      <h3 class="title">회답서</h3>
    </div>
    <div class="form-box">
      <div class="form-group row">
        <label class="col-sm-2 control-label">회답서 제목</label>
        <div class="col-sm-10">{{responseInfo.res_title}}</div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 text-sm-right control-label">파일 첨부</label>
        <div class="col-sm-10">
          <v-fileupload ref="fileupload" multiple="true" v-model="req_no" :readonly="true"></v-fileupload>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 control-label">메모</label>
        <div class="col-sm-10" v-html="responseInfo.res_content"></div>
      </div>
    </div>
  </div>
</template>

<script>
import { getRes } from "../../services";

export default {
  name: "response-info",
  props: {
    req_no: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      responseInfo: {
        req_no: "",
        req_type: "",
        res_title: "",
        res_content: "",
        state: "",
        examiner_id: "",
        examiner_nm: "",
        update_user_idx: "",
        create_user_idx: ""
      }
    };
  },
  watch: {
    req_no(val) {
      if (val) {
        this.getRes();
      }
    }
  },
  methods: {
    getRes() {
      getRes({ req_no: this.req_no }).then(res => {
        this.responseInfo = res.data;
      });
    }
  },
  created() {
    if (this.req_no) {
      this.getRes();
    }
  }
};
</script>
