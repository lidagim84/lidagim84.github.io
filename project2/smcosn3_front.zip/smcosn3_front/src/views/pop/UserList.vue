<template>
  <div id="basicModal" class="modal fade in" style="display: block; padding-right: 17px;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h3>
            사용자 리스트
            <button type="button" class="close" data-dismiss="modal" @click="$close(false)">
              <span aria-hidden="true">×</span>
              <span class="sr-only">Close</span>
            </button>
          </h3>

          <!-- <h4 class="modal-title">사용자 조회</h4> -->
        </div>
        <div class="modal-body">
          <div class="row">
            <div v-if="showDeptTree" class="col-sm-4 m-b-xs">
              <tree
                :style="{height: treeHeight + 'px', overflow: 'auto'}"
                :data="deptList"
                show-checkbox
                default-expand-all
                @check-change="handleCheckChange"
                :props="{label:'ld_nm'}"
              ></tree>
            </div>
            <div :class="[bodyClassName, 'm-b-xs']">
              <div class="row">
                <div class="col-sm-12 m-b-xs">
                  <div class="form-group">
                    <div class="grid-box">
                      <v-dropdown
                        name="search_type"
                        inputClass="form-control form-control-sm"
                        style="width:200px"
                        v-model="search_type"
                        placeholder
                        :options="[{label:'이름', value:'user_nm'},{label:'아이디', value:'user_id'}]"
                      />
                      <input
                        placeholder="검색어 입력"
                        type="text"
                        class="form-control form-control-sm"
                        @keyup.13="getList"                        
                        v-model="search_text"
                      />
                      <span class="input-group-append">
                        <button type="button" class="btn btn-sm btn-primary" @click="search">검색</button>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="table-responsive">
                <div style="padding: 8px;white-space: nowrap;">
                  <i class="fa fa-list"></i>
                  검색결과 : {{this.totalCount | numberComma}} 건
                </div>
                <v-table
                  is-horizontal-resize
                  style="width:100%"
                  :isVerticalResize="true"
                  :isSingleSelection="isSingleSelection"
                  :columns="[
                      {field: 'user_id', width: 60, titleAlign: 'center',columnAlign:'center',type: 'selection',isFrozen:true},
                      { field: 'user_nm', title: '이름', width: 100, titleAlign: 'center', columnAlign: 'center'},                      
                      { field: 'phone_no', title: '전화번호', width: 150, titleAlign: 'center', columnAlign: 'center'},
                      { field: 'email', title: '이메일', width: 250, titleAlign: 'center', columnAlign: 'left'}]"
                  :table-data="tableData"
                  :select-change="selectChange"
                  :select-all="selectList"
                  :resizeGabHeight="140"
                  row-hover-color="#eee"
                  row-click-color="#edf7ff"
                ></v-table>
              </div>
              <div class="row">
                <div class="col-sm-12 m-t-xs align-content-center">
                  <v-pager
                    v-model="pageIndex"
                    :page-count="pageCount"
                    @change="onChange"
                    @pageSizeChange="pageSizeChange"
                  ></v-pager>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-strong" @click="close()">확인</button>
          <button
            type="button"
            class="btn btn-normal"
            data-dismiss="modal"
            @click="$close(false)"
          >취소</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getUserList, getDeptList } from "../../services";

export default {
  name: "userList",
  props: {
    showDeptTree: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      deptList: [],
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      filter: null,
      selectionDatas: [],
      selectionData: null,
      selectedData: [],
      dept_no: "",
      search_text: "",
      search_type: "user_nm",
      isSingleSelection: false,
      treeHeight: 0,
      selectDeptList: []
    };
  },
  computed: {
    bodyClassName() {
      return this.showDeptTree ? "col-sm-8" : "col-sm-12";
    }
  },
  methods: {
    getList(Supporter) {
      if (
        this.$options.propsData &&
        this.$options.propsData.arguments &&
        this.$options.propsData.arguments.length
      ) {
        this.isSingleSelection = !this.$options.propsData.arguments[0];
      }
      if (
        this.$options.propsData &&
        this.$options.propsData.arguments &&
        this.$options.propsData.arguments.length &&
        this.$options.propsData.arguments[1]
      ) {
        this.filter = this.$options.propsData.arguments[1];
        if (this.filter.dept_no) {
          this.dept_no = this.filter.dept_no;
        }
      } else if (
        this.$options.propsData &&
        this.$options.propsData.arguments &&
        this.$options.propsData.arguments.length &&
        this.$options.propsData.arguments[2]
      ) {
        this.selectedData = this.$options.propsData.arguments[2];
      }
      this.tableData = [];

      let param = {
        page_index: this.pageIndex,
        page_size: this.pageSize,
        search_text: this.search_text,
        search_type: this.search_type,
        dept_list: this.selectDeptList,
        ...this.filter
      };

      return getUserList(param).then(res => {
        const data = res.data;
        this.totalCount = data.TOTAL_COUNT;
        this.pageCount = Math.ceil(data.TOTAL_COUNT / this.pageSize);
        this.tableData = data.list.map(item => {
          item.disabled =
            this.selectedData.filter(user => user.user_id == item.user_id)
              .length == true;
          item.checked =
            this.selectionDatas.filter(user => user.user_id == item.user_id)
              .length == true;
          return item;
        });
      });
    },
    search() {
      this.pageIndex = 1;
      this.getList();
    },
    pageSizeChange(val) {
      this.pageIndex = 1;
      this.pageSize = val;
      this.getList();
    },
    selectChange(selection, rowData) {
      if (
        this.$options.propsData &&
        this.$options.propsData.arguments.length &&
        this.$options.propsData.arguments[0]
      ) {
        this.selectionDatas = [
          ...this.selectionDatas.filter(
            user => rowData.checked && rowData.user_id != user.user_id
          ),
          ...selection.filter(
            item =>
              !this.selectionDatas.filter(user => item.user_id == user.user_id)
                .length
          )
        ];
      } else {
        if (selection.length) {
          this.selectionData = rowData;
        } else {
          this.selectionData = null;
        }
      }
    },
    close() {
      if (
        this.$options.propsData &&
        this.$options.propsData.arguments.length &&
        this.$options.propsData.arguments[0] &&
        this.selectionDatas.length
      ) {
        this.$close(this.selectionDatas);
        this.$emit("input", this.selectionDatas);
      } else {
        if (this.selectionData) {
          this.$close(this.selectionData);
        } else {
          alert("선택된 사용자가 없습니다.");
        }
      }
    },
    selectList(selection) {
      this.selectionDatas = [
        ...this.selectionDatas,
        ...selection.filter(
          item =>
            !this.selectionDatas.filter(user => item.user_id == user.user_id)
              .length
        )
      ];
    },
    selectGroupChange(selection) {},
    onChange() {
      this.getList();
    },
    getDeptList() {
      return getDeptList({}).then(res => {
        this.deptList = res.data;
        return res.data;
      });
    },
    handleCheckChange(v, checked) {
      this.selectDeptList = this.deptList[0].children
        .filter(item => item.checked)
        .map(item => item.ld_cd);
      this.search();
    }
  },
  created() {
    this.getDeptList();
  },
  mounted() {
    this.treeHeight = this.$el.clientHeight - 240;
  }
};
</script>

<style>
.modal-header h3 {
  text-align: left;
  margin: 5px 0px;
  padding: 5px 0 0 20px;
}
.modal-header .close {
  padding: 5px 1rem;
}
</style>
