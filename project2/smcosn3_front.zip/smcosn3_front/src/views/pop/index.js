import UserList from './UserList';

import { create } from '../../components/modal';

const popUserList = create(UserList, 'title', 'content');

export { popUserList };
