<template>
  <div>
    <div class="container dashboard">
      <div class="row stat-today">
        <div class="icon-stat stat-1 col-md-6">
          <div class="text-left">
            <span class="icon-stat-label">전체</span>
            <p class="icon-stat-text">최근 3개월간의 조사요청입니다.</p>
            <span class="icon-stat-value"><span class="number">5</span>건</span>
          </div>
        </div>
        
        <div class="icon-stat stat-2 col-md-6">
          <div class="text-left">
            <span class="icon-stat-label">접수대기</span>
            <p class="icon-stat-text">요청후 접수를 기다리고 있습니다.</p>
            <span class="icon-stat-value"><span class="number">5</span>건</span>
          </div>
       </div>
        
        <div class="icon-stat stat-3 col-md-6">
          <div class="text-left">
            <span class="icon-stat-label">회답중</span>
            <p class="icon-stat-text">현재 회답 진행중입니다.</p>
            <span class="icon-stat-value"><span class="number">5</span>건</span>
            <span class="mark-exclam">미처리</span>
          </div>
       </div>
        
        <div class="icon-stat stat-4 col-md-6">
          <div class="text-left">
            <span class="icon-stat-label">회답완료</span>
            <p class="icon-stat-text">조사회답이 완료되었습니다.</p>
            <span class="icon-stat-value"><span class="number">5</span>건</span>
          </div>
       </div>

       <div class="icon-stat stat-5 col-md-6">
          <div class="text-left">
            <span class="icon-stat-label">보류·철회</span>
            <p class="icon-stat-text">보류중 또는 철회된 요청입니다.</p>
            <span class="icon-stat-value"><span class="number">5</span>건</span>
          </div>
        </div>
        
        <div class="icon-stat stat-6 col-md-6">
          <div class="text-left">
            <span class="icon-stat-label">철회</span>
            <p class="icon-stat-text">철회된 요청입니다.</p>
            <span class="icon-stat-value"><span class="number">5</span>건</span>
          </div>
        </div>
        
      </div>
      <!-- /.row -->

      <div class="row">
        <div class="col-md-9">
          <div class="portlet portlet-boxed">
            <div class="portlet-header">
              <h2 class="portlet-title">진행 현황</h2>
            </div>
            <!-- /.portlet-header -->
            <div class="portlet-body">
              <table class="table tbl-dash">
                <colgroup>
                    <col style="width:86px;">
                    <col>
                    <col style="width:40%;">
                    <col>
                </colgroup>
                <thead>
                  <tr> 
                    <th class="text-center">분류</th>
                    <th class="text-center">제목</th>
                    <th class="text-center">상태</th>
                    <th class="text-center">요청날짜</th>
                  </tr>
                </thead>

                <tbody>
                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-danger">법률</span>
                    </td>
                    <td class="text-left"><p class="ellipsis">재난 및 안전관리 기본 조례에 관한 건</p></td>
                    <td class="text-center">
                      <div class="progress progress-comm progress-xl">
                        <div
                          class="progress-bar progress-stat-1"
                          role="progressbar"
                          style="width: 20%;"
                          aria-valuenow="30"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >요청</div>
                      </div>
                    </td>
                    <td class="text-center">7/15</td>
                  </tr>

                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-warning">입안</span>
                    </td>
                    <td class="text-left"><p class="ellipsis">재난 및 안전관리 기본 조례에 관한 건</p></td>
                    <td class="text-center">
                      <div class="progress progress-comm progress-xl">
                        <div
                          class="progress-bar progress-stat-2"
                          role="progressbar"
                          style="width: 40%;"
                          aria-valuenow="40"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >대기</div>
                      </div>
                    </td>
                    <td class="text-center">7/12</td>
                  </tr>

                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-secondary">입법</span>
                    </td>
                    <td class="text-left"><p class="ellipsis">재난 및 안전관리 기본 조례에 관한 건</p></td>
                    <td class="text-center">
                      <div class="progress progress-comm progress-xl">
                        <div
                          class="progress-bar progress-stat-3"
                          role="progressbar"
                          style="width: 60%;"
                          aria-valuenow="60"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >회답중</div>
                      </div>
                    </td>
                    <td class="text-center">7/09</td>
                  </tr>
                  <tr>
                    <td class="text-center">
                      <span data-v-109177d0 class="label label-success">전문</span>
                    </td>
                    <td class="text-left"><p class="ellipsis">재난 및 안전관리 기본 조례에 관한 건</p></td>
                    <td class="text-center">
                      <div class="progress progress-comm progress-xl">
                        <div
                          class="progress-bar progress-stat-4"
                          role="progressbar"
                          style="width: 80%;"
                          aria-valuenow="80"
                          aria-valuemin="0"
                          aria-valuemax="100"
                        >결제중</div>
                      </div>
                    </td>
                    <td class="text-center">7/03</td>
                  </tr>
                  <tr>
                      <td class="text-center">
                        <span data-v-109177d0 class="label label-success">전문</span>
                      </td>
                      <td class="text-left"><p class="ellipsis">재난 및 안전관리 기본 조례에 관한 건</p></td>
                      <td class="text-center">
                        <div class="progress progress-comm progress-xl">
                          <div
                            class="progress-bar progress-stat-5"
                            role="progressbar"
                            style="width: 100%;"
                            aria-valuenow="100"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          >회답완료</div>
                        </div>
                      </td>
                      <td class="text-center">7/03</td>
                    </tr>
                </tbody>
              </table>
              <a href="#none" class="btn_more">더보기</a>
            </div>
            <!-- /.portlet-body -->
          </div>
          <!-- /.portlet -->
        </div>
        <!-- /.col -->

        <div class="col-md-3 col-sm-5">
          <div class="portlet portlet-boxed">
            <div class="portlet-header">
              <h2 class="portlet-title">공지사항·도움말</h2>
            </div>
            <!-- /.portlet-header -->

            <div class="portlet-body">
                <div class="notice-dash">
                    <div class="tab-notice">
                        <a href="#none" class="link-notice on">공지사항</a><!-- 선택시 on클래스 추가 -->
                        <a href="#none" class="link-help">도움말</a>
                    </div>
                    <ul class="list-notice">
                         <li><a href="#none">입법조사회답 시스템  설명 매뉴얼</a></li>
                         <li><a href="#none">컴퓨터 문서보안(DRM) 프로그램 </a></li>
                         <li><a href="#none">입법조사회답 시스템 점검 안내</a></li>
                         <li><a href="#none">자주하는 질문 모음 V.1.0</a></li>
                    </ul>
                 </div>
                 <a href="#none" class="btn_more">더보기</a>
            </div>

            <div class="button-wrap">
              <a href="#none" class="btn-register">등록</a>
            </div>
            <!-- /.portlet-body -->
          </div>
          <!-- /.portlet -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      
      
      <div class="row">
          <div class="col-md-9">
            <div class="row">
              <div class="col-md-6">
                <div class="portlet portlet-boxed">
                  <div class="portlet-header">
                    <h2 class="portlet-title">요청·회답 검색</h2>
                  </div>

                  <div class="portlet-body">
                      <table class="table tbl-dash2">
                          <colgroup>
                              <col style="width:90px;">
                              <col>
                          </colgroup>
                          </colgroup>
                          <tbody>
                              <tr>
                                  <th scope="row">검색기간</th>
                                  <td>
                                    <div class="v-checkbox-group">
                                        <div class="input-group">
                                            <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                <span>전체</span>
                                            </label>
                                            <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                <span>1주일</span>
                                            </label>
                                            <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                <span>1달</span>
                                            </label>
                                            <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                <span>6달</span>
                                            </label>
                                        </div>
                                      </div>
                                      <div class="grid-box date-group">
                                          <div id="datepicker2" class="input-group date datepicker2">
                                              <input type="text" class="form-control" placeholder="Choose Date">
                                              <span class="input-group-addon"></span>
                                          </div>
                                          <span class="txt-dash">~</span>
                                          <div id="datepicker2" class="input-group date datepicker2">
                                              <input type="text" class="form-control" placeholder="Choose Date">
                                              <span class="input-group-addon"></span>
                                          </div>
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <th scope="row">검색어</th>
                                  <td>
                                      <div class="grid-box">
                                          <select class="form-control form-control-sm" style="width:30%;">
                                              <option>선택하세요.</option>
                                          </select>
                                          <input type="text" class="form-control">
                                      </div>
                                  </td>
                              </tr>
                              <tr>
                                  <th scope="row">검색영역</th>
                                  <td>
                                      <div class="v-checkbox-group">
                                        <div class="input-group">
                                            <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                <span>전체</span>
                                            </label>
                                            <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                <span>제목</span>
                                            </label>
                                            <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                <span>내용</span>
                                            </label>
                                            <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                <span>첨부파일</span>
                                            </label>
                                        </div>
                                      </div>
                                  </td>
                              </tr>
                          </tbody>
                          <tfoot>
                              <tr>
                                  <td></td>
                                  <td><button type="button" class="btn-color color1">검색</button></td>
                              </tr>
                          </tfoot>
                      </table>
                      
                  </div>
                </div>
              </div>
          
              <div class="col-md-6">
                  <div class="portlet portlet-boxed">
                        <div class="portlet-header">
                          <h2 class="portlet-title">통계</h2>
                        </div>

                        <div class="portlet-body">
                            <table class="table tbl-dash2">
                                <colgroup>
                                    <col style="width:90px;">
                                    <col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th scope="row">검색기간</th>
                                        <td>
                                          <div class="v-checkbox-group">
                                              <div class="input-group">
                                                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                      <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                      <span>전체</span>
                                                  </label>
                                                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                      <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                      <span>1주일</span>
                                                  </label>
                                                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                      <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                      <span>1달</span>
                                                  </label>
                                                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                                                      <span class="v-checkbox"><input type="checkbox" class="v-checkbox-input" value=""><span class="v-checkbox-inner"></span></span>
                                                      <span>6달</span>
                                                  </label>
                                              </div>
                                            </div>
                                            <div class="grid-box date-group">
                                                <div id="datepicker2" class="input-group date datepicker2">
                                                    <input type="text" class="form-control" placeholder="Choose Date">
                                                    <span class="input-group-addon"></span>
                                                </div>
                                                <span class="txt-dash">~</span>
                                                <div id="datepicker2" class="input-group date datepicker2">
                                                    <input type="text" class="form-control" placeholder="Choose Date">
                                                    <span class="input-group-addon"></span>
                                                </div>
                                            </div>
                                            <div class="grid-box btn-group">
                                              <div class="grid-row">
                                                  <button type="button" class="btn-color color2">의원별</button>
                                                  <button type="button" class="btn-color color3">조사관별</button>
                                                  <button type="button" class="btn-color color4">요청현황별</button>
                                              </div>
                                              <div class="grid-row">
                                                  <button type="button" class="btn-color color5 txt-sm">의원별요청발의</button>
                                                  <button type="button" class="btn-color color6">입범지원발의</button>
                                                  <button type="button" class="btn-color color7">일주계표</button>
                                              </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                  </div>
              </div>
            </div>
          </div>
            
          <div class="col-md-3">
              <div class="portlet portlet-boxed">
                <div class="portlet-header">
                  <h2 class="portlet-title">공지사항·도움말</h2>
                </div>
                <!-- /.portlet-header -->

                <div class="portlet-body">
                    <div class="notice-dash">
                        <div class="tab-notice">
                            <a href="#none" class="link-notice on">공지사항</a><!-- 선택시 on클래스 추가 -->
                            <a href="#none" class="link-help">도움말</a>
                        </div>
                        <ul class="list-notice">
                             <li><a href="#none">입법조사회답 시스템  설명 매뉴얼</a></li>
                             <li><a href="#none">컴퓨터 문서보안(DRM) 프로그램 </a></li>
                             <li><a href="#none">입법조사회답 시스템 점검 안내</a></li>
                             <li><a href="#none">자주하는 질문 모음 V.1.0</a></li>
                        </ul>
                     </div>
                     <a href="#none" class="btn_more">더보기</a>
                </div>
                <!-- /.portlet-body -->
              </div>
          </div>
          
      </div>
    </div>
    <!-- <modal name="hello-world">
      hello, world!
    </modal>
    <el-upload
      class="upload-demo"
      ref="upload"
      action="https://jsonplaceholder.typicode.com/posts/"      
    >
      <button
        size="small"
        type="primary"
      >select file</button>      
      <div
        class="el-upload__tip"
        slot="tip"
      >jpg/png files with a size less than 500kb</div>
    </el-upload>-->
  </div>
</template>

<script>
// import { InfoWidgetContainer } from '../widget';
import { BarChart } from "../../components/chart";
import ElUpload from "../../components/fileupload";
import View from "../board/View";

export default {
  name: "dashboard",
  components: { BarChart, ElUpload },
  data() {
    return {
      list: [],
      statValues: [10, 12, 5, 12, 1, 4, 7]
    };
  },
  methods: {
    getConfig() {}
  },
  created() {
    // this.$modal.show('hello-world');
    // this.$modal.show({
    //   template: `
    //     <div>
    //       <p>Close using this button:</p>
    //       <button @click="$emit('close')">Close</button>
    //     </div>
    //   `
    // })
  },
  mounted() {
    // this.$modal.show(View, {}, {
    //   draggable: true
    // })
  }
};
</script>

<style>
/* .ibox {
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.2),
    0 1px 5px 0 rgba(0, 0, 0, 0.12);
} */

.panel-title {
  font-weight: normal;
  padding: 0 20px 0 20px;
  font-size: 1.15em;
  line-height: 42px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.panel-title {
  margin-top: 0;
  margin-bottom: 0;
  font-size: 16px;
  color: inherit;
}

.panel .panel-heading,
.panel > :first-child {
  border-top-left-radius: 2px;
  border-top-right-radius: 2px;
}
.panel-heading {
  position: relative;
  height: 42px;
  padding: 0;
  color: #4d627b;
}

.panel .panel-footer,
.panel > :last-child {
  border-bottom-left-radius: 2px;
  border-bottom-right-radius: 2px;
}
.panel-footer {
  background-color: #fdfdfe;
  color: #7a878e;
}
.panel-footer {
  background-color: #fdfdfe;
  color: #7a878e;
  border-color: rgba(0, 0, 0, 0.02);
  position: relative;
}
.panel-footer {
  padding: 10px 15px;
  background-color: #f5f5f5;
  border-top: 1px solid #ddd;
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
}

[class^="col-"]:not(.pad-no) {
  padding-left: 10px;
  padding-right: 10px;
}

.nano {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.panel-warning .panel-heading,
.panel-warning .panel-footer,
.panel-warning.panel-colorful {
  background-color: #ffb300;
  border-color: #ffb300;
  color: #fff;
}

.panel-info .panel-heading,
.panel-info .panel-footer,
.panel-info.panel-colorful {
  background-color: #03a9f4;
  border-color: #03a9f4;
  color: #fff;
}
.panel-success .panel-heading,
.panel-success .panel-footer,
.panel-success.panel-colorful {
  background-color: #8bc34a;
  border-color: #8bc34a;
  color: #fff;
}

.panel-purple .panel-heading,
.panel-purple .panel-footer,
.panel-purple.panel-colorful {
  background-color: #ab47bc;
  border-color: #ab47bc;
  color: #fff;
}

.media:first-child {
  margin-top: 0;
}
.pad-all {
  padding: 15px;
  font-size: 18px;
}

.panel {
  border: 0;
  border-radius: 3px;
  box-shadow: none !important;
  margin-bottom: 20px;
}

.media:first-child {
  margin-top: 0;
}
.media,
.media-body {
  overflow: hidden;
  zoom: 1;
}
.media {
  margin-top: 15px;
}
.media-body,
.media-left,
.media-right {
  display: table-cell;
  vertical-align: top;
}
.media-left,
.media > .pull-left {
  padding-right: 10px;
}

.text-main,
a.text-main:hover,
a.text-main:focus {
  color: #4d627b;
}
.text-2x {
  font-size: 5em;
}
.text-3x {
  font-size: 1.3em;
}
.text-thin {
  font-weight: 300;
}
.pad-lft {
  padding-left: 5px;
}
.text-semibold {
  font-weight: 600;
}
.progress {
  margin-bottom: 0;
}
.icon-3x {
  font-size: 3em;
  line-height: 1em;
}
    
    .dashboard .row + .row { margin-top:28px; }
    .dashboard .portlet { margin:0; }
    .dashboard .portlet-title { font-size:23px; color:#174972; }
    .dashboard .portlet-boxed .portlet-title:before { top:2px; }
    
    .dashboard .portlet-boxed .portlet-header { padding-top:18px; padding-bottom:7px; }
    .dashboard .portlet-boxed .portlet-body { position:relative;}
    .dashboard .portlet-boxed .portlet-body,
    .portlet-boxed .portlet-header+.portlet-body { padding:20px; height:100%; } 
    
    .dashboard .portlet-boxed .btn_more { overflow:hidden; position:absolute; right:0; top:-31px; width:21px; height:21px; font-size:1px; line-height:0; text-indent:-9999px; color:transparent; background:url('/assets/images/btn_more.png') no-repeat 0 0; background-size:21px 21px; }
    
    .dashboard .portlet-boxed .button-wrap { margin-top:12px; }
    .dashboard .btn-register { display:block; height:44px; line-height:42px; font-size:22px; color:#bebebe; text-align:center; text-decoration:none; background:#26557b; }
    
  
    .icon-stat .icon-stat-label { font-weight:600; font-size:30px; }
    .icon-stat .icon-stat-text { font-size:14px; }
    .icon-stat .icon-stat-value { margin-top:-7px; font-size:18px; color:#ffdb16; }
    .icon-stat .icon-stat-value .number { display:inline-block; margin-right:6px; font-size:40px; }
    .icon-stat [class^="mark"] { position:absolute; right:0; top:0; font-size:1px; line-height:0; text-indent:-9999px; color:transparent; }
    .icon-stat .mark-exclam { width:21px; height:21px; background:url('/assets/images/mark_exclam.png') no-repeat 0 0; background-size:21px 21px;}
    .icon-stat.stat-1 { color:#585858; background:#fabd26; } /* 전체 */
    .icon-stat.stat-2 { color:#ffe0ce; background:#f56d1f; } /* 접수대기 */
    .icon-stat.stat-3 { color:#daead1; background:#6fb648; } /* 회답중 */
    .icon-stat.stat-4 { color:#95e9ff; background:#089cc3; } /* 회답완료 */
    .icon-stat.stat-5 { color:#b2b6bc; background:#6b7179; } /* 보류 */
    .icon-stat.stat-6 { color:#585858; background:#90959b; } /* 철회 */
    
    .icon-stat.stat-1 .icon-stat-label { color:#585858; }
    .icon-stat.stat-2 .icon-stat-label { color:#ffe0ce; }
    .icon-stat.stat-3 .icon-stat-label { color:#daead1; }
    .icon-stat.stat-4 .icon-stat-label { color:#95e9ff; }
    .icon-stat.stat-5 .icon-stat-label { color:#b2b6bc; }
    .icon-stat.stat-6 .icon-stat-label { color:#585858; }
    
    .icon-stat.stat-1 .icon-stat-value { color:#595957; }
    
    /* 대시보드 버튼 btn-color */
    .btn-color { overflow: hidden; display:inline-block; width:100%; height:37px; padding:0; line-height:37px; font-size:16px; font-weight:bold; color:#333; cursor:pointer; border:0; border-radius:0; text-align:center; vertical-align:middle; background-color:#bcbcbc; }
    .btn-color.txt-sm { font-size:14px; }
    
/*
    .btn-color.color1 { background-color:#bcbcbc; }
    .btn-color.color2 { background-color:#60aed4; }
    .btn-color.color3 { background-color:#89cf1f; }
    .btn-color.color4 { background-color:#ffbf01; }
    .btn-color.color5 { background-color:#da88df; }
    .btn-color.color6 { background-color:#fe8a47; }
    .btn-color.color7 { background-color:#ff77b5; }
    
*/
    
    /* 대시보드 테이블 */
    /* tbl-dash */
    .tbl-dash { table-layout:fixed; margin-bottom:0; }
    .tbl-dash thead > tr > th { padding:16px 10px 19px; color:#4d4c4b; font-size:16px; border-top:1px solid #3177b4 !important; border-left:1px solid #3177b4; border-bottom:2px solid #3177b4 !important; text-align:center; background:#f2f6f8; vertical-align:middle; }
    .tbl-dash tbody > tr > th {  }
    .tbl-dash tbody > tr > td { padding:10px; border:1px solid #dddddd; border-width:0 0 1px 1px; color:#333; vertical-align:middle; }
    
    .tbl-dash thead > tr > th:first-child,
    .tbl-dash tbody > tr > td:first-child { border-left:0; }
    /* 텍스트 정렬 재정의 */
    .tbl-dash tbody > tr > td.text-center { text-align:center; }
    .tbl-dash tbody > tr > td.text-right { text-align:right; }
    .tbl-dash thead > tr > th.text-left { text-align:left; } 
    .tbl-dash thead > tr > th.text-right { text-align:right; } 
    
    /* tbl-dash2*/
    .tbl-dash2 { table-layout:fixed; overflow:hidden; margin-bottom:0; }
    .portlet-body .tbl-dash2 { margin-top:27px; }
    .tbl-dash2 tbody { border-top:2px solid #3177b4; border-bottom:2px solid #3177b4; }
    .tbl-dash2 tbody > tr > th { padding:10px; font-size:16px; color:#4d4c4b; border:0; vertical-align:top; }
    .tbl-dash2 tbody > tr > td { padding:10px; border:0; vertical-align:top; }
    .tbl-dash2 tfoot > tr > th, .tbl-dash2 tfoot > tr > td { border:0; padding-top:18px; padding-bottom:0; }

    @media (max-width: 900px) {
      .tbl-dash2, 
      .tbl-dash2 tbody, 
      .tbl-dash2 tbody > tr,
      .tbl-dash2 tbody > tr > th, 
      .tbl-dash2 tbody > tr > td, 
      .tbl-dash2 tfoot, 
      .tbl-dash2 tfoot > tr,
      .tbl-dash2 tfoot > tr > td  { display:block; }
    }
    

    .dashboard .label { display:inline-block; min-width:61px; padding:0 2px; font-weight:400; line-height:30px; border:2px solid transparent; border-radius:0; font-size:14px; color:#4d4b4b; box-sizing:border-box; background-color:#ececec; }
    .dashboard .label.label-danger { border-color:#f27b57; }
    .dashboard .label.label-warning { border-color:#f2b058; }
    .dashboard .label.label-secondary { border-color:#52bedc; }
    .dashboard .label.label-success { border-color:#4cb964; }
    .dashboard .label.label-default { border-color:#d2d2d2; }

  
    /* 공지사항 도움말 */
    .dashboard .notice-dash {}
    .notice-dash .tab-notice { }
    .notice-dash .tab-notice:after{ content:''; display:block; clear:both; }
    .notice-dash .tab-notice [class^="link"] { overflow:hidden; width:59px; height:59px; font-size:1px; line-height:0; text-indent:-9999px; color:transparent;background-repeat:no-repeat; background-size:59px 59px; background-position:0 0; }
    .notice-dash .tab-notice .link-notice { float:left; background-image:url(/assets/images/notice_off.png); }
    .notice-dash .tab-notice .link-notice.on, .notice-dash .tab-notice .link-notice:hover { float:left; background-image:url(/assets/images/notice_on.png); }
    .notice-dash .tab-notice .link-help { float:right; background-image:url(/assets/images/help_off.png); }
    .notice-dash .tab-notice .link-help.on, .notice-dash .tab-notice .link-help:hover { float:right; background-image:url(/assets/images/help_on.png); }
    
    .notice-dash .list-notice { margin:0; padding:0; list-style:none; }  
    .notice-dash .list-notice li { border-bottom:1px solid #ddd; }
    .notice-dash .list-notice li > a { display:block; padding:20px 0 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size:16px; color:#333; text-decoration:none; }

    @media (min-width: 768px) {
      .dashboard .row { display:-webkit-flex; display:-ms-flex; display:flex; -webkit-align-items:stretch; -ms-align-items:stretch; align-items:stretch;margin:0 -10px; }
      .dashboard .row .portlet { display:-webkit-flex; display:-ms-flex; display:flex; -webkit-flex-direction:column; -ms-flex-direction:column; flex-direction:column; height:100%; }
   
       /* 대시보드 stat */
      .dashboard .stat-today { margin-left:-20px !important; }
      .dashboard .stat-today .icon-stat { -webkit-flex:1; -ms-flex:1; flex:1; padding-bottom:72px; margin-left:20px; -webkit-flex:1; -ms-flex:1; flex:1; } 
      .dashboard .stat-today .icon-stat .icon-stat-value { position:absolute; bottom:13px; left:13px; right:13px; }
    
    }
    
</style>