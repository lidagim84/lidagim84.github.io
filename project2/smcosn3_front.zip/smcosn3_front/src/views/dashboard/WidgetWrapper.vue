<template>
  <div class="row" :class="item.className" v-if="item.columns.length">
    <div v-for="(widget, index) in item.columns" :key="index" :class="[widget.className]">
      <component
        v-if="widget.componentName  && (widget.checked == undefined || widget.checked)"
        :is="widget.componentName"
        :config="widget"
      ></component>

      <widget-wrapper v-for="(row, index2) in widget.rows" :key="index2" :item="row"></widget-wrapper>
    </div>
  </div>
</template>

<script>
import {
  BoardWidget,
  CommentWidget,
  SearchWidget,
  StatWidget,
  SummaryInfoWidget,
  RequestListWidget,
  ResponseListWidget
} from "../widget";

export default {
  components: {
    BoardWidget,
    CommentWidget,
    SearchWidget,
    StatWidget,
    SummaryInfoWidget,
    RequestListWidget,
    ResponseListWidget
  },
  watch: {
    columns(newVal) {
      if (newVal.length) {
        this.list = newVal;
      } else {
        this.list = [];
      }
    }
  },
  props: {
    columns: {
      type: Array,
      default: () => {
        return [];
      }
    },
    item: {
      type: Object,
      default: {}
    }
  },
  data() {
    return {
      list: []
    };
  },
  methods: {},
  created() {
    if (this.columns.length) this.list = this.columns;
  }
};
</script>
