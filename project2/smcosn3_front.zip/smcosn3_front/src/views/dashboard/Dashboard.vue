<template>
  <div class="container dashboard">
    <widget-wrapper v-for="(item, index) in list" :key="index" :item="item"></widget-wrapper>
  </div>
</template>

<script>
import { getConfig, setConfig, getSummaryStat } from "../../services";

export default {
  name: "dashboard",
  components: {},
  data() {
    return {
      list: [],
      stat: {}
    };
  },  
  methods: {
    getConfig() {
      let configInfo = [];
      //type > 요청인 , 조사관, 일반 직원
      //default(요청인 > councilor, supporter), member( 관리자 > admin, 조사관 > examiner, 기타 > ""), 관리자.
      getConfig(this.userRoleType).then(res => {
        if (res && res.rows && res.rows.length) {
          let items = res.rows;
          this.list = this.setWidgetConfig(items, configInfo);
        }
      });
    },
    setWidgetConfig(list, configInfo) {
      for (let row of list) {
        for (let column of row.columns) {
          if (column.componentName) {
            if (configInfo.length) {
              column.checked =
                configInfo.filter(
                  widget => widget.componentName == column.componentName
                ).length == true;
            }
          } else if (column.rows && column.rows.length) {
            this.setWidgetConfig(column.rows, configInfo);
          }
        }
      }
      return list;
    }
  },
  mounted() {
    this.getConfig();
  }
};
</script>

<style>
.panel-title {
  font-weight: normal;
  padding: 0 20px 0 20px;
  font-size: 1.15em;
  line-height: 42px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.panel-title {
  margin-top: 0;
  margin-bottom: 0;
  font-size: 16px;
  color: inherit;
}

.panel .panel-heading,
.panel > :first-child {
  border-top-left-radius: 2px;
  border-top-right-radius: 2px;
}
.panel-heading {
  position: relative;
  height: 42px;
  padding: 0;
  color: #4d627b;
}

.panel .panel-footer,
.panel > :last-child {
  border-bottom-left-radius: 2px;
  border-bottom-right-radius: 2px;
}
.panel-footer {
  background-color: #fdfdfe;
  color: #7a878e;
}
.panel-footer {
  background-color: #fdfdfe;
  color: #7a878e;
  border-color: rgba(0, 0, 0, 0.02);
  position: relative;
}
.panel-footer {
  padding: 10px 15px;
  background-color: #f5f5f5;
  border-top: 1px solid #ddd;
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
}

[class^="col-"]:not(.pad-no) {
  padding-left: 10px;
  padding-right: 10px;
}

.nano {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.panel-warning .panel-heading,
.panel-warning .panel-footer,
.panel-warning.panel-colorful {
  background-color: #ffb300;
  border-color: #ffb300;
  color: #fff;
}

.panel-info .panel-heading,
.panel-info .panel-footer,
.panel-info.panel-colorful {
  background-color: #03a9f4;
  border-color: #03a9f4;
  color: #fff;
}
.panel-success .panel-heading,
.panel-success .panel-footer,
.panel-success.panel-colorful {
  background-color: #8bc34a;
  border-color: #8bc34a;
  color: #fff;
}

.panel-purple .panel-heading,
.panel-purple .panel-footer,
.panel-purple.panel-colorful {
  background-color: #ab47bc;
  border-color: #ab47bc;
  color: #fff;
}

.media:first-child {
  margin-top: 0;
}
.pad-all {
  padding: 15px;
  font-size: 18px;
}

.panel {
  border: 0;
  border-radius: 3px;
  box-shadow: none !important;
  margin-bottom: 20px;
}

.media:first-child {
  margin-top: 0;
}
.media,
.media-body {
  overflow: hidden;
  zoom: 1;
}
.media {
  margin-top: 15px;
}
.media-body,
.media-left,
.media-right {
  display: table-cell;
  vertical-align: top;
}
.media-left,
.media > .pull-left {
  padding-right: 10px;
}

.text-main,
a.text-main:hover,
a.text-main:focus {
  color: #4d627b;
}
.text-2x {
  font-size: 5em;
}
.text-3x {
  font-size: 1.3em;
}
.text-thin {
  font-weight: 300;
}
.pad-lft {
  padding-left: 5px;
}
.text-semibold {
  font-weight: 600;
}
.progress {
  margin-bottom: 0;
}
.icon-3x {
  font-size: 3em;
  line-height: 1em;
}

.dashboard .row + .row {
  margin-top: 28px;
}
.dashboard .portlet {
  margin: 0;
}
.dashboard .portlet-title {
  font-size: 23px;
  color: #174972;
}
.dashboard .portlet-boxed .portlet-title:before {
  top: 2px;
}

.dashboard .portlet-boxed .portlet-header {
  padding-top: 18px;
  padding-bottom: 7px;
}
.dashboard .portlet-boxed .portlet-body {
  position: relative;
}
.dashboard .portlet-boxed .portlet-body,
.portlet-boxed .portlet-header + .portlet-body {
  padding: 20px;
  height: 100%;
}

.dashboard .portlet-boxed .btn_more {
  overflow: hidden;
  position: absolute;
  right: 0;
  top: -31px;
  width: 21px;
  height: 21px;
  font-size: 1px;
  line-height: 0;
  text-indent: -9999px;
  color: transparent;
  background: url("/assets/images/btn_more.png") no-repeat 0 0;
  background-size: 21px 21px;
}

.dashboard .stat-today {
  display: -webkit-flex;
  display: -ms-flex;
  display: flex;
  -webkit-flex-wrap: wrap;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  -webkit-flex: 1;
  -ms-flex: 1;
  flex: 1;
}

.icon-stat .icon-stat-label {
  font-weight: 600;
  font-size: 30px;
}
.icon-stat .icon-stat-text {
  font-size: 14px;
}
.icon-stat .icon-stat-value {
  margin-top: -7px;
  font-size: 18px;
  color: #ffdb16;
}
.icon-stat .icon-stat-value .number {
  display: inline-block;
  margin-right: 6px;
  font-size: 40px;
}
.icon-stat [class^="mark"] {
  position: absolute;
  right: 0;
  top: 0;
  font-size: 1px;
  line-height: 0;
  text-indent: -9999px;
  color: transparent;
}
.icon-stat .mark-exclam {
  width: 21px;
  height: 21px;
  background: url("/assets/images/mark_exclam.png") no-repeat 0 0;
  background-size: 21px 21px;
}
.icon-stat.stat-1 {
  color: #585858;
  background: #fabd26;
} /* 전체 */
.icon-stat.stat-2 {
  color: #ffe0ce;
  background: #f56d1f;
} /* 접수대기 */
.icon-stat.stat-3 {
  color: #daead1;
  background: #6fb648;
} /* 회답중 */
.icon-stat.stat-4 {
  color: #95e9ff;
  background: #089cc3;
} /* 회답완료 */
.icon-stat.stat-5 {
  color: #b2b6bc;
  background: #6b7179;
} /* 보류 */
.icon-stat.stat-6 {
  color: #585858;
  background: #90959b;
} /* 철회 */

.icon-stat.stat-1 .icon-stat-label {
  color: #585858;
}
.icon-stat.stat-2 .icon-stat-label {
  color: #ffe0ce;
}
.icon-stat.stat-3 .icon-stat-label {
  color: #daead1;
}
.icon-stat.stat-4 .icon-stat-label {
  color: #95e9ff;
}
.icon-stat.stat-5 .icon-stat-label {
  color: #b2b6bc;
}
.icon-stat.stat-6 .icon-stat-label {
  color: #585858;
}

.icon-stat.stat-1 .icon-stat-value {
  color: #595957;
}

/* 대시보드 버튼 btn-color */
.btn-color {
  overflow: hidden;
  display: inline-block;
  width: 100%;
  height: 37px;
  padding: 0;
  line-height: 37px;
  font-size: 16px;
  font-weight: bold;
  color: #333;
  cursor: pointer;
  border: 0;
  border-radius: 0;
  text-align: center;
  vertical-align: middle;
  background-color: #bcbcbc;
}
.btn-color.txt-sm {
  font-size: 14px;
}

/*
    .btn-color.color1 { background-color:#bcbcbc; }
    .btn-color.color2 { background-color:#60aed4; }
    .btn-color.color3 { background-color:#89cf1f; }
    .btn-color.color4 { background-color:#ffbf01; }
    .btn-color.color5 { background-color:#da88df; }
    .btn-color.color6 { background-color:#fe8a47; }
    .btn-color.color7 { background-color:#ff77b5; }
    
*/

/* 대시보드 테이블 */
/* tbl-dash */
.tbl-dash {
  table-layout: fixed;
  margin-bottom: 0;
}
.tbl-dash thead > tr > th {
  padding: 16px 10px 19px;
  color: #4d4c4b;
  font-size: 16px;
  border-top: 1px solid #3177b4 !important;
  border-left: 1px solid #3177b4;
  border-bottom: 2px solid #3177b4 !important;
  text-align: center;
  background: #f2f6f8;
  vertical-align: middle;
}
.tbl-dash tbody > tr > th {
}
.tbl-dash tbody > tr > td {
  padding: 10px;
  border: 1px solid #dddddd;
  border-width: 0 0 1px 1px;
  color: #333;
  vertical-align: middle;
}

.tbl-dash thead > tr > th:first-child,
.tbl-dash tbody > tr > td:first-child {
  border-left: 0;
}
/* 텍스트 정렬 재정의 */
.tbl-dash tbody > tr > td.text-center {
  text-align: center;
}
.tbl-dash tbody > tr > td.text-right {
  text-align: right;
}
.tbl-dash thead > tr > th.text-left {
  text-align: left;
}
.tbl-dash thead > tr > th.text-right {
  text-align: right;
}

/* tbl-dash2*/
.tbl-dash2 {
  table-layout: fixed;
  margin-bottom: 0;
}
.portlet-body .tbl-dash2 {
  margin-top: 27px;
}
.tbl-dash2 tbody {
  border-top: 2px solid #3177b4;
  border-bottom: 2px solid #3177b4;
}
.tbl-dash2 tbody > tr > th {
  padding: 10px;
  font-size: 16px;
  color: #4d4c4b;
  border: 0;
  vertical-align: top;
}
.tbl-dash2 tbody > tr > td {
  padding: 10px;
  border: 0;
  vertical-align: top;
}
.tbl-dash2 tfoot > tr > th,
.tbl-dash2 tfoot > tr > td {
  border: 0;
  padding-top: 18px;
  padding-bottom: 0;
}

@media (max-width: 900px) {
  .tbl-dash2,
  .tbl-dash2 tbody,
  .tbl-dash2 tbody > tr,
  .tbl-dash2 tbody > tr > th,
  .tbl-dash2 tbody > tr > td,
  .tbl-dash2 tfoot,
  .tbl-dash2 tfoot > tr,
  .tbl-dash2 tfoot > tr > td {
    display: block;
  }
}

.dashboard .label {
  display: inline-block;
  min-width: 61px;
  padding: 0 2px;
  font-weight: 400;
  line-height: 30px;
  border: 2px solid transparent;
  border-radius: 0;
  font-size: 14px;
  color: #4d4b4b;
  box-sizing: border-box;
  background-color: #ececec;
}
.dashboard .label.label-danger {
  border-color: #f27b57;
}
.dashboard .label.label-warning {
  border-color: #f2b058;
}
.dashboard .label.label-secondary {
  border-color: #52bedc;
}
.dashboard .label.label-success {
  border-color: #4cb964;
}
.dashboard .label.label-default {
  border-color: #d2d2d2;
}

/* 공지사항 도움말 */
.dashboard .notice-dash {
}
.notice-dash .tab-notice {
}
.notice-dash .tab-notice:after {
  content: "";
  display: block;
  clear: both;
}
.notice-dash .tab-notice [class^="link"] {
  overflow: hidden;
  width: 59px;
  height: 59px;
  font-size: 1px;
  line-height: 0;
  text-indent: -9999px;
  color: transparent;
  background-repeat: no-repeat;
  background-size: 59px 59px;
  background-position: 0 0;
}
.notice-dash .tab-notice .link-notice {
  float: left;
  background-image: url(/assets/images/notice_off.png);
}
.notice-dash .tab-notice .link-notice.on,
.notice-dash .tab-notice .link-notice:hover {
  float: left;
  background-image: url(/assets/images/notice_on.png);
}
.notice-dash .tab-notice .link-help {
  float: right;
  background-image: url(/assets/images/help_off.png);
}
.notice-dash .tab-notice .link-help.on,
.notice-dash .tab-notice .link-help:hover {
  float: right;
  background-image: url(/assets/images/help_on.png);
}

.notice-dash .list-notice {
  margin: 0;
  padding: 0;
  list-style: none;
}
.notice-dash .list-notice li {
  border-bottom: 1px solid #ddd;
}
.notice-dash .list-notice li > a {
  display: block;
  padding: 20px 0 12px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 16px;
  color: #333;
  text-decoration: none;
}

@media (min-width: 768px) {
  .dashboard .row {
    display: -webkit-flex;
    display: -ms-flex;
    display: flex;
    -webkit-align-items: stretch;
    -ms-align-items: stretch;
    align-items: stretch;
    margin: 0 -10px;
  }
  .dashboard .row .portlet {
    display: -webkit-flex;
    display: -ms-flex;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    height: 100%;
  }

  /* 대시보드 stat */
  .dashboard .stat-today {
    margin: 0;
  }
  .dashboard .stat-today .icon-stat {
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    padding-bottom: 72px;
    margin-left: 2px;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
  }
  .dashboard .stat-today .icon-stat:first-child {
    margin-left: 0;
  }
  .dashboard .stat-today .icon-stat .icon-stat-value {
    position: absolute;
    bottom: 13px;
    left: 13px;
    right: 13px;
  }
}
@media (max-width: 767px) {
  .dashboard .stat-today {
    margin: -40px -30px 0 -30px;
  }
  .dashboard .stat-today .icon-stat {
    margin-bottom: 0;
    width: 33.3%;
  }
  .dashboard .stat-today .stat-1 {
    width: 66.6%;
  }
  .icon-stat-label,
  .icon-stat .icon-stat-text,
  .icon-stat .icon-stat-value {
    text-align: center;
  }
}
</style>