<template>
  <div class="portlet portlet-boxed">
    <!-- <div class="portlet-header">
      <h2 class="portlet-title">시스템 관리절차</h2>
    </div> -->
    <div class="portlet-body">
        <!-- 시스템 사용 절차 -->
        <ol class="list-process">
            <li>
              <strong class="title">절차 1) 시스템 로그인 및 요청서 작성</strong>
              <div class="img-box">
                  <img src="/assets/images/guide2_1.png" alt="의원발의 조례안 제·개정 절차">
              </div>
            </li>
            <li>
              <strong class="title">절차 2) 요청 접수, 조사관 배정, 회답서 작성, 내부검토</strong>
              <div class="img-box">
                <img src="/assets/images/guide2_2.png" alt="의원발의 조례안 제·개정 절차">
              </div>
            </li>
            <li>
                <strong class="title">절차 3) 회답서 송부, 열람</strong>
                <div class="img-box">
                  <img src="/assets/images/guide2_3.png" alt="의원발의 조례안 제·개정 절차">
                </div>
            </li>
        </ol>  
        <!-- //시스템 사용 절차 -->
    </div>
  </div>
</template>

<script>
export default {
  name: "guide2",
 
  data: function() {
    return {};
  },
  computed: {},  
  methods: {},
  created() {}
};
</script>

<style>
  .list-process { padding:0; margin:0; list-style:none; }
  .list-process li { position: relative; margin-bottom:130px; }
  .list-process li:last-child { margin-bottom:0; }

  .list-process li:after { 
    content:'';
    display: block;
    width: 40px;
    height: 40px;
    border: 1px solid #26557b;
    border-width: 0 0 2px 2px;
    transform: rotate(-45deg);
    margin-left: -50px;
    margin-top: 20px;
    position:absolute;
    left:50%;
  
  }

  .list-process .img-box { text-align:left; }
  .list-process li:last-child:after { display:none; }
  .list-process li .title { display:block; font-size:20px; font-weight:400; }

  @media (max-width: 767px) {
    .list-process li .title { font-size:18px; }
    .list-process li:after { width:25px; height:25px; margin-left:-14px; border-width: 0 0 1px 1px; }
  }

</style>
