<template>
  <div class="portlet portlet-boxed">
    <!-- <div class="portlet-header">
      <h2 class="portlet-title">의원발의절차</h2>
    </div> -->
    <div class="portlet-body">
        <div class="tit-group2">
            <h3 class="title">1. 의원발의 전체 흐름도</h3>
        </div>
        <div class="img-box">
          <img src="/assets/images/guide3_1.png" alt="의원발의 전체 흐름도">
        </div>

        <div class="tit-group2">
            <h3 class="title">2. 단계별 설명</h3>
        </div>
        <div class="img-box">
          <img src="/assets/images/guide3_2.png" alt="단계별 설명">
        </div>

        <div class="step-box">
          <strong class="title-step">1단계 : 입법조사</strong>
            <table class="tbl-step">
              <colgroup>
                <col style="width:95px;">
                <col>
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">구분</th>
                  <th scope="col">설명</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">시스템명</th>
                  <td><p class="desc">입법조사시스템</p></td>
                </tr>
                <tr>
                  <th scope="row">처리기한</th>
                  <td>
                      <p class="desc">조례 제정 : 요청일로부터 20일 이내 (휴일 포함)</p>
                      <p class="desc">조례 개정 : 요청일로부터 25일 이내 (휴일 포함)</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">공개여부</th>
                  <td>
                      <p class="desc">의원 : 비공개,  대시민 : 비공개</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">기능설명</th>
                  <td>
                      <p class="desc">요구자 : 의원, 의회사무처 직원  /  답변자 : 입법담당관</p>
                      <p class="desc text-info">
                        의원 발의 조례 재·개정 시 발의 전 조사요청 및 회답<br>(조례(안) 검토, 입법정책, 법률자문, 전문정보) 
                      </p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">관련규정</th>
                  <td>
                      <p class="desc">서울특별시의회 입법·법률고문 운영조례</p>
                      <p class="desc">서울특별시의회 입법지원 사무처리 규정</p>
                      <p class="desc">서울특별시의회 전문도서관 설치 및 운영 규정 </p>
                  </td>
                </tr>
                <tr>
                    <th scope="row">흐름도</th>
                    <td>
                      <div class="img-box">
                        <img src="/assets/images/guide3_3.png" alt="1단계 흐름도">
                      </div>
                    </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="step-box">
            <strong class="title-step">2단계 : 비용추계</strong>
            <table class="tbl-step">
              <colgroup>
                <col style="width:95px;">
                <col>
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">구분</th>
                  <th scope="col">설명</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">시스템명</th>
                  <td><p class="desc">비용추계시스템</p></td>
                </tr>
                <tr>
                  <th scope="row">처리기한</th>
                  <td>
                    <p class="desc">요청일로부터 비용추계서 : 14일 이내</p>
                    <p class="desc">요청일로부터 미첨부사유서 1·2호 : 14일 이내</p>
                    <p class="desc">요청일로부터 비대상사유서 : 14일 이내</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">공개여부</th>
                  <td><p class="desc">의원 : 회답 시 공개,  대시민 : 의안접수 시 공개   (정책분석 : 비공개)</p></td>
                </tr>
                <tr>
                  <th scope="row">기능설명</th>
                  <td>
                    <p class="desc">요구자 : 의원·상임위  답변자 : 예산정책담당관</p>
                    <p class="desc text-info">조례(안)별 비용발생에 대한 추계 요청 및 비용추계서 송부</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">관련규정</th>
                  <td><p class="desc">서울특별시의회 의안의 비용 추계에 관한 조례 및 예규</p></td>
                </tr>
                <tr>
                  <th scope="row">시스템명</th>
                  <td><p class="desc">입법조사시스템</p></td>
                </tr>
                <tr>
                    <th scope="row">흐름도</th>
                    <td>
                      <div class="img-box">
                        <img src="/assets/images/guide3_4.png" alt="2단계 흐름도">
                      </div>
                    </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="step-box">
            <strong class="title-step">3단계 : 의안제출(연서), 접수</strong>
            <table class="tbl-step">
              <colgroup>
                <col style="width:95px;">
                <col>
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">구분</th>
                  <th scope="col">설명</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">제출기한</th>
                  <td><p class="desc">임시회 개회 10일 전</p></td>
                </tr>
                <tr>
                  <th scope="row">공개여부</th>
                  <td><p class="desc">의원 : 공개(의안 접수 시),  대시민 : 공개 (의안 접수 시)</p></td>
                </tr>
                <tr>
                  <th scope="row">기능설명</th>
                  <td>
                    <p class="desc">의안 작성(제안공문, 제안서식, 제안본문, 발의자·찬성자 서명명부)</p>
                    <p class="desc">의안 제출, 의안 접수</p>
                    <p class="desc">의회 홈페이지 접수의안 시민공개</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">관련규정</th>
                  <td><p class="desc">지방자치법, 서울시의회 회의규칙</p></td>
                </tr>
                <tr>
                    <th scope="row">흐름도</th>
                    <td>
                      <div class="img-box">
                        <img src="/assets/images/guide3_4.png" alt="3단계 흐름도">
                      </div>  
                    </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="step-box">
            <strong class="title-step">4단계 : 상임위 심사, 입법예고, 본회의 심의, 공포</strong>
            <table class="tbl-step">
              <colgroup>
                <col style="width:95px;">
                <col>
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">구분</th>
                  <th scope="col">설명</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">공개여부</th>
                  <td><p class="desc">의원 : 공개,  대시민 : 공개</p></td>
                </tr>
                <tr>
                  <th scope="row">기능설명</th>
                  <td>
                    <p class="desc">상임위 회부, 입법예고, 상임위 심사</p>
                    <p class="desc">본회의 보고, 심의, 대시민 공개</p>
                    <p class="desc">집행부 이송,  공포,  공포통지서 의회송부</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">관련규정</th>
                  <td><p class="desc">지방자치법, 서울시의회 회의규칙</p></td>
                </tr>
                <tr>
                  <th scope="row">흐름도</th>
                  <td>
                    <div class="img-box">
                      <img src="/assets/images/guide3_5.png" alt="4단계 흐름도">
                    </div>  
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "guide3",
 
  data: function() {
    return {};
  },
  computed: {},  
  methods: {},
  created() {}
};
</script>

<style>

.step-box {  }
.step-box .title-step { display:block; margin:20px 0; font-size:20px; color:#3177b4; }

/* tbl-step */
.tbl-step { table-layout:fixed; width:100%; margin-bottom:0; }
.tbl-step .desc { margin:0; }
.tbl-step thead > tr > th { padding:16px 10px; color:#4d4c4b; font-size:16px; border-top:1px solid #ddd !important; border-left:1px solid #ddd; border-bottom:1px solid #ddd !important; text-align:center; background:#f0f0f0; vertical-align:middle; }
.tbl-step tbody > tr > th,
.tbl-step tbody > tr > td { padding:14px 10px 18px; border:1px solid #ddd; border-width:0 0 1px 1px; font-size:16px; color:#333; vertical-align:middle; }

.tbl-step thead > tr > th:first-child,
.tbl-step tbody > tr > th:first-child,
.tbl-step tbody > tr > td:first-child { border-left:0; }
/* 텍스트 정렬 재정의 */
.tbl-step tbody > tr > td.text-center { text-align:center; }
.tbl-step tbody > tr > td.text-right { text-align:right; }
.tbl-step thead > tr > th.text-left { text-align:left; } 
.tbl-step thead > tr > th.text-right { text-align:right; }


@media (max-width: 767px) {
  .tbl-step, 
  .tbl-step tbody, 
  .tbl-step tbody > tr,
  .tbl-step tbody > tr > th, 
  .tbl-step tbody > tr > td, 
  .tbl-step tfoot, 
  .tbl-step tfoot > tr,
  .tbl-step tfoot > tr > td  { display:block; }

  .tbl-step thead { display:none; }
  .tbl-step tbody > tr > th,
  .tbl-step tbody > tr > td { border:0; padding-left:0; }  
  /* .tbl-step tbody > tr > td { border-bottom:1px solid #ddd; }
  .tbl-step tbody > tr:last-child > td { border-bottom:0; } */
  .tbl-step tbody > tr > th { padding-bottom:0; }

  .step-box { border:1px solid #6fa1cc; padding: 0 10px; margin:20px -10px 0; }
  .step-box .title-step { font-size:18px; }
}

</style>
