<template>
  <div class="portlet portlet-boxed">
    <!-- <div class="portlet-header">
      <h2 class="portlet-title">시스템소개</h2>
    </div> -->
    <div class="portlet-body">
     <!-- 시스템 소개 -->
      <div class="tit-group2">
          <h3 class="title">1.시스템 소개</h3>
      </div>
      <ul class="list-system">
        <li>
          <strong class="title">입법조사회답시스템이란? </strong>
          <p class="desc">
              입법조사회답시스템은 의원발의(發議) 조례안 제·개정의 첫 단계인  「입법조사·분석 ~ 회답」업무의 전 과정을 전산화한 시스템입니다. 
          </p>
          <div class="img-box">
            <img src="/assets/images/guide1_1.png" alt="의원발의 조례안 제·개정 절차">
          </div>
        </li>
        <li>
            <p class="desc">이전에는 의원 발의를 위한 조사요청과 회답서 작성, 의원 열람 등이 전화와 메일로 처리되어 체계적인 관리가 어렵고, 진행현황 확인이 어려웠습니다.</p></li>
        </li>
      </ul>

      <div class="tit-group2">
          <h3 class="title">2.업무흐름</h3>
      </div>
      <p class="text-system">본 시스템을 통해  「조사요청 – 접수 – 조사관 배정 - 회답서 작성·송부 – 회답서 열람」 절차를 모두 한 시스템에서 처리하고 조회할 수 있어 업무 효율성을 높일 수 있습니다.</p>
      <div class="img-box">
        <img src="/assets/images/guide1_2.png" alt="조사요청·회답 절차">
      </div>
      
      <div class="tit-group2">
          <h3 class="title">3.입법조사회답시스템의 장점 </h3>
      </div>
      <ol class="list-system2">
          <li>
            <strong class="title">조사요청 ~ 회답 간소화로 신속한 회답처리</strong>
            <ul>
              <li>요청서(한글문서) 작성, 메일 발송, 유선협의로 인한 불편사항 해소</li>
              <li>간편한 요청서 등록과 회답서 작성(조사관 배정, 결재 상신)</li>
              <li>요청자의 회답서 열람</li>
            </ul>
          </li>
          <li>
            <strong class="title">회답현황을 한 눈에 파악하여 궁금증 해소</strong>
            <ul>
              <li>주요 단계(요청등록 – 접수 – 조사관 배정- 회답서 작성중 – 회답완료)별 진행현황 실시간 확인</li>
              <li>SMS와 웹메일로 진행사항을 자동안내하여 대기시간 단축</li>
              <li>요청건별 회답현황 조회, 다양한 조건검색·통계 활용</li>
            </ul>
          </li>
          <li>
              <strong class="title">정보시스템 연계로 편리한 활용</strong>
              <ul>
                <li>‘의정플러스+’와 ‘행정포털’을 통한 편리한 로그인</li>
                <li>국회 입법조사처(연구보고서) 조회</li>
                <li>회답서 열람 중 ‘비용추계시스템’으로 즉시 이동</li>
              </ul>
            </li>
        </ol>

        <div class="tit-group2">
            <h3 class="title">4. 관련 법령</h3>
        </div>
      
        <ul class="list-system">
          <li><p class="desc">서울특별시의회 입법·법률고문 운영조례 (<a href="#none" target="_blank">링크</a>)</p></li>
          <li><p class="desc">서울특별시의회 입법지원 사무처리 규정 (<a href="#none" target="_blank">링크</a>)</p></li>
          <li><p class="desc">서울특별시의회 전문도서관 설치 및 운영 규정 (<a href="#none" target="_blank">링크</a>)</p></li>
        </ul>

        <div class="tit-group2">
            <h3 class="title">5. 구축 이력</h3>
        </div>

        <ul class="list-system">
          <li><p class="desc">‘19년 6월 ~ 11월 : 입법조사회답시스템 신규 구축 및 운영</p></li>
        </ul>
        <!-- //시스템 소개 -->

    </div>
  </div>
</template>

<script>
export default {
  name: "guide1",
 
  data: function() {
    return {};
  },
  computed: {},  
  methods: {},
  created() {}
};
</script>


<style>
</style>

