<template>
  <div class="row">
    <div class="col-lg-12">
      <div class="ibox ">
        <div class="ibox-content">
          <div class="row">
            <div class="col-sm-12 m-b-xs">
              <div class="input-group">
                <label class="text-sm-right col-form-label">조직: </label>
                <v-dropdown
                  name="dept_no"
                  inputClass="form-control form-control-sm"
                  v-model="dept_no"
                  placeholder="전체"
                  code="dept_no"
                />
                &nbsp;

                <v-dropdown
                  name="search_type"
                  inputClass="form-control form-control-sm"
                  v-model="search_type"
                  placeholder=""
                  :options="[{label:'이름', value:'user_nm'},{label:'아이디', value:'user_id'}]"
                />
                <input
                  placeholder="검색어 입력"
                  type="text"
                  class="form-control form-control-sm"
                  @keyup.13="getList"
                  style="width:100px"
                  v-model="search_text"
                >
                <span class="input-group-append">
                  <button
                    type="button"
                    class="btn btn-sm btn-primary"
                    @click="getList"
                  >검색</button>
                </span>
              </div>
            </div>
          </div>
          <div class="table-responsive">
            <div style="padding: 8px;white-space: nowrap;">
              <i class="fa fa-list"></i> 검색결과 : {{this.totalCount}} 건
            </div>
            <v-table
              is-horizontal-resize
              style="width:100%"
              :isVerticalResize="true"
              :columns="[{field: 'user_id', title: '아이디', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'user_id', title: '이름', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'user_nm', title: '접속아이피', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'user_nm', title: '접속시간', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'user_nm', title: '로그아웃시간', width: 150, titleAlign: 'center', columnAlign: 'center'}]"
              :table-data="tableData"
              :row-click="selectRow"
            >
            </v-table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
import { getUserList } from '../../services';

export default {
  name: 'table',
  computed: {
    ...mapGetters(['userInfo'])
  },
  data() {
    return {
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      dept_no: '',
      search_text: '',
      search_type: 'user_nm'
    };
  },
  methods: {
    ...mapActions(['getUserInfo']),
    onChange: function() {
      this.getList();
    },
    selectRow(rowIndex, rowData) {
      this.$router.push({
        name: 'user',
        query: { user_id: rowData.user_id }
      });
    },
    getList() {
      return getUserList({
        page_index: this.pageIndex,
        page_size: this.pageSize
      }).then(res => {
        this.totalCount = res.data.total_count;
        this.pageCount = Math.ceil(res.data.total_count / this.pageSize);
        this.tableData = res.data.list;
      });
    }
  },
  created() {
    this.getList();
  }
};
</script>
