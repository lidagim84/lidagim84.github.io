<template>
  <div class="row">
    <div class="col-lg-3">
      <widget-container>
        <!-- <template slot="title">권한 트리</template> -->
        <div class="tit-group"><h3 class="title">권한 트리</h3></div>
        <div class="form-group row">
          <tree
            :data="authList"
            show-checkbox
            @check-change="selectItem"
            ref="tree"
            node-key="auth_id"
            :props="{label:'auth_nm'}"
          ></tree>
        </div>
        <!-- <div class="row">
            <div class="col-md-12 list-btn-group">
              <button
                type="button"
                class="btn btn-primary float-right btn-sm"
              >삭제</button>
                      <button
                type="button"
                class="btn btn-primary float-right btn-sm"
              >추가</button>
            </div>
        </div>-->
      </widget-container>
    </div>
    <div class="col-lg-9">
      <widget-container>
        <!-- <template slot="title">권한 정보</template> -->
        <div class="tit-group"><h3 class="title">권한 정보</h3></div>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              권한아이디
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input
                type="text"
                name="auth_id"
                class="form-control"
                :disabled="!isNew"
                v-model="authInfo.auth_id"
                v-validate="'required'"
              />
              <label class="error" v-show="errors.has('auth_id')">{{ errors.first('auth_id') }}</label>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              권한명
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input
                type="text"
                name="auth_nm"
                class="form-control"
                v-model="authInfo.auth_nm"
                v-validate="'required'"
              />
              <label class="error" v-show="errors.has('auth_nm')">{{ errors.first('auth_nm') }}</label>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              설명
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input
                type="text"
                name="description"
                class="form-control"
                v-model="authInfo.description"
                v-validate="'required'"
              />
              <label
                class="error"
                v-show="errors.has('description')"
              >{{ errors.first('description') }}</label>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              사용여부
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <v-checkbox v-model="authInfo.use_yn"></v-checkbox>
            </div>
          </div>
        </div>
        <div class="list-btn-group group-submit">
          <!-- <button
              type="button"
              class="btn btn-primary"
              @click="approveReq"
          >삭제</button>-->
          <button type="button" class="btn-point" @click="addNew">신규</button>
          <button type="button" class="btn-strong" @click="approveReq">저장</button>
          <button type="button" class="btn-normal" @click="deleteItem">삭제</button>
        </div>
      </widget-container>
    </div>
  </div>
</template>

<script>
import { getAuth, setAuth, deleteAuth, getAuthList } from "../../services";

export default {
  name: "auth",
  components: {},
  data() {
    return {
      authInfo: {
        auth_id: null,
        auth_nm: "",
        description: "",
        use_yn: "Y",
        create_user_idx: "test",
        update_user_idx: "test"
      },
      isNew: true,
      authList: []
    };
  },
  methods: {
    approveReq() {
      debugger;
      this.$validator.validateAll().then(res => {
        if (res) {
          setAuth(this.authInfo).then(res => {
            alert("저장했습니다.");
            this.getList();
          });
        }
      });
    },
    getList() {
      getAuthList({}).then(res => {
        this.authList = res.data.map(item => {
          item.checked = false;
          return item;
        });
      });
    },
    selectItem(item) {
      debugger;
      this.isNew = false;
      this.authInfo = item;
    },

    addNew() {
      this.isNew = true;
      this.authInfo = {
        auth_id: null,
        auth_nm: "",
        description: "",
        use_yn: "Y",
        create_user_idx: "test",
        update_user_idx: "test"
      };
    },
    deleteItem() {
      deleteAuth(this.authInfo).then(res => {
        alert("삭제했습니다.");
        this.authInfo = {
          auth_id: null,
          auth_nm: "",
          description: "",
          use_yn: "Y",
          create_user_idx: "test",
          update_user_idx: "test"
        };
        this.isNew = true;
        this.getList();
      });
    }
  },
  created() {
    this.getList();
  }
};
</script>
