<template>
  <div class="row">
    <div class="col-lg-3">
      <widget-container>
        <!-- <template slot="title">권한 사용자 트리</template> -->
        <div class="tit-group"><h3 class="title">권한 사용자 트리</h3></div>
        <div class="form-group row">
          <tree
            :data="authList"
            show-checkbox
            @check-change="getAuthMenuList"
            ref="tree"
            node-key="auth_id"
            :props="{label:'auth_nm'}"
          ></tree>
        </div>
        <!-- <div class="row">
            <div class="col-md-12 list-btn-group">
              <button
                type="button"
                class="btn btn-primary btn-sm"
              >삭제</button>
                      <button
                type="button"
                class="btn btn-primary btn-sm"
              >추가</button>
            </div>
        </div>-->
      </widget-container>
    </div>
    <div class="col-lg-9">
      <widget-container>
        <!-- <template slot="title">권한 메뉴 그룹</template> -->
        <div class="tit-group"><h3 class="title">권한 메뉴 그룹</h3></div>
        <div class="form-group row">
          <tree
            :data="authMenuGrp"
            show-checkbox
            ref="menuTree"
            node-key="menu_id"
            :props="{label:'menu_nm'}"
          ></tree>
        </div>
        <div class="list-btn-group group-submit">
          <div class="float-right">
            <button type="button" class="btn-strong" @click="approveReq">저장</button>
          </div>
        </div>
      </widget-container>
    </div>
  </div>
</template>

<script>
import { getAuthList, getAuthMenuGrp, setAuthMenuGrp } from "../../services";

export default {
  name: "authUserGroup",
  components: {},
  data() {
    return {
      authInfo: {
        auth_id: "",
        auth_nm: "",
        description: "",
        use_yn: "Y",
        create_user_idx: "test",
        update_user_idx: "test"
      },
      menuInfo: {},
      authList: [],
      authMenuGrp: []
    };
  },
  methods: {
    flattenDeep(arr1) {
      return arr1.reduce(
        (acc, val) =>
          val.children && val.children.length
            ? acc.concat(val, this.flattenDeep(val.children))
            : acc.concat(val),
        []
      );
    },
    approveReq() {
      let authId = this.authInfo.auth_id;
      let result = this.flattenDeep(
        this.authMenuGrp.filter(item => item.checked)
      ).map(item => {
        item.auth_id = authId;
        return item;
      });

      if (!result.length) return;

      setAuthMenuGrp(result).then(res => {
        alert("저장했습니다.");
        this.getAuthMenuList({ auth_id: authId });
      });
    },
    getAuthList() {
      getAuthList({}).then(res => {
        this.authList = res.data.map(item => {
          item.checked = false;
          return item;
        });
      });
    },
    getAuthMenuList(item) {
      this.authInfo = item;
      getAuthMenuGrp({ auth_id: item.auth_id }).then(res => {
        this.authMenuGrp = res.data;
      });
    }
  },
  created() {
    this.getAuthList();
  }
};
</script>
