<template>
  <form class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">검색조건</label>
            <div class="col-sm-10 grid-box">
              <!-- <v-dropdown
                name="dept_no"
                inputClass="form-control form-control-sm"
                v-model="dept_no"
                placeholder="전체"
                code="dept_no"
              /> -->
              <v-dropdown
                name="search_type"
                inputClass="form-control form-control-sm"
                v-model="search_type"
                placeholder
                :options="[{label:'이름', value:'user_nm'},{label:'아이디', value:'user_id'}]"
              />
              <input
                placeholder="검색어 입력"
                type="text"
                class="form-control form-control-sm"
                @keyup.13="getList"
                style="width:2000px"
                v-model="search_text"
              />
              <span class="input-group-append">
                <button type="button" class="btn btn-sm btn-primary" @click="search">검색</button>
              </span>
            </div>
          </div>
        </div>
        <div class="table-responsive tbl-wrap-type1">
          <div style="padding: 8px;white-space: nowrap;">
            <i class="fa fa-list"></i>
            검색결과 : {{this.totalCount}} 건
          </div>
          <v-table
            is-horizontal-resize
            style="width:100%"
            :isVerticalResize="true"
            :columns="[{field: 'user_type', title: '유형', width: 150, titleAlign: 'center', columnAlign: 'center', type:'code'},
                        {field: 'dept_nm', title: '부서', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'user_id', title: '아이디', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'user_nm', title: '이름', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'pos_no', title: '직위', width: 150, titleAlign: 'center', columnAlign: 'center', type:'code'},
                        {field: 'hp_no', title: '휴대폰번호', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'email', title: '이메일', width: 200, titleAlign: 'center', columnAlign: 'left', isResize: true }]"
            :table-data="tableData"
            :row-click="selectRow"
          ></v-table>
        </div>
        <div class="row">
          <div class="col-sm-12 m-t-xs align-content-center">
            <v-pager
              v-model="pageIndex"
              :page-count="pageCount"
              @change="onChange"
              @pageSizeChange="pageSizeChange"
            ></v-pager>
          </div>
        </div>
        <div class="list-btn-group group-submit">
          <div class="float-right">
            <button type="button" class="btn-strong" @click="$router.push('user')">등록하기</button>
          </div>
        </div>
      </widget-container>
    </fieldset>
  </form>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getUserList } from "../../services";

export default {
  name: "table",
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      dept_no: "",
      search_text: "",
      search_type: "user_nm"
    };
  },
  watch: {
    $route(to, from) {
      if (to.query.page_index) {
        this.pageIndex = Number(to.query.page_index);
      } else {
        this.pageIndex = 1;
      }
      this.getList();
    }
  },
  methods: {
    onChange() {
      this.$router.push({
        name: "userList",
        query: { page_index: this.pageIndex }
      });
    },
    pageSizeChange(val) {
      this.pageIndex = 1;
      this.pageSize = val;      
      this.getList();
    },
    selectRow(rowIndex, rowData) {
      this.$router.push({
        name: "user",
        query: { user_id: rowData.user_id }
      });
    },
    getList() {
      return getUserList({
        page_index: this.pageIndex,
        page_size: this.pageSize,
//        dept_no: this.dept_no,
        search_text: this.search_text,
        search_type: this.search_type
      }).then(res => {
        const data = res.data;
        this.totalCount = data.TOTAL_COUNT;
        this.pageCount = Math.ceil(data.TOTAL_COUNT / this.pageSize);
        this.tableData = data.list;
      });
    },
    search() {
      this.pageIndex = 1;
      this.getList();
    }
  },
  mounted() {
    const query = this.$route.query;
    if (query.page_index) {
      this.pageIndex = Number(query.page_index);
    }
    this.getList();
  }
};
</script>
