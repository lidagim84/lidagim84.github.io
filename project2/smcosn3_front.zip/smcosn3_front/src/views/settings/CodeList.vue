<template>
  <div class="row">
    <div class="col-lg-3">
      <widget-container>
        <!-- <template slot="title">코드 그룹</template> -->
        <div class="tit-group">
          <h3 class="title">코드 그룹</h3>
        </div>
        <div class="form-group row">
          <tree :data="codeDivList" @node-click="getList" :props="{label:'value'}"></tree>
        </div>
        <!-- <div class="row">
            <div class="col-md-12 list-btn-group">
              <button
                type="button"
                class="btn btn-primary btn-sm"
              >삭제</button>
                      <button
                type="button"
                class="btn btn-primary btn-sm"
              >추가</button>
            </div>
        </div>-->
      </widget-container>
    </div>
    <div class="col-lg-9">
      <widget-container>
        <!-- <template slot="title">코드 정보</template> -->
        <div class="tit-group">
          <h3 class="title">코드 정보</h3>
        </div>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              코드그룹코드
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input
                type="text"
                class="form-control"
                :disabled="!isNew"
                v-model="codeInfo.detail_code"
              />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              그룹코드명
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="codeInfo.value" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              코드리스트
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <div class="list-btn-group mb-10">
                <div class="float-right">
                  <button class="btn-strong" type="button" @click="addItem">
                    <i class="fa fa-plus"></i> 추가
                  </button>
                  <button class="btn-normal" type="button" @click="delItem">
                    <i class="fa fa-minus"></i> 삭제
                  </button>
                </div>
              </div>
              <v-table
                is-horizontal-resize
                style="width:100%"
                :height="(codeList.length+1)*constants.RowHeight"
                :isVerticalResize="true"
                :columns="[
                        {field: 'detail_code', width: 60, titleAlign: 'center',columnAlign:'center',type: 'selection',isFrozen:true},
                        { field: 'detail_code', title: '상세코드', width: 80, titleAlign: 'center', columnAlign: 'center', isResize: true, isEdit:true }, 
                        { field: 'value', title: '텍스트', width: 100, titleAlign: 'center', columnAlign: 'center', isResize: true, isEdit:true },
                        { field: 'sort1', title: '정렬', width: 80, titleAlign: 'center', columnAlign: 'center', isResize: true, isEdit:true },
                        { field: 'description', title: '설명', width: 100, titleAlign: 'center', columnAlign: 'center', isResize: true, isEdit:true }
                        ]"
                :table-data="codeList"
                :cell-edit-done="cellEditDone"
                :select-change="selectChange"
                row-hover-color="#eee"
                row-click-color="#edf7ff"
              ></v-table>
            </div>
          </div>
        </div>
        <div class="list-btn-group group-submit">
          <div class="float-right">
            <!-- <button
                type="button"
                class="btn btn-primary float-right btn-sm"
                @click="deleteCode"
            >삭제</button>-->
            <button type="button" class="btn-point" @click="addNew">신규</button>
            <button type="button" class="btn-strong" @click="approveReq">저장</button>
          </div>
        </div>
      </widget-container>
    </div>
  </div>
</template>

<script>
import { getCodeList, setCode, deleteCode } from "../../services";

export default {
  name: "authCodeGroup",
  components: {},
  data() {
    return {
      codeInfo: {
        code_div: "code_div",
        detail_code: null,
        value: "",
        sort1: 0,
        description: "",
        children: []
      },
      isNew: true,
      codeDivList: [],
      codeList: [],
      selectedCodeList: []
    };
  },
  methods: {
    approveReq() {
      this.codeInfo.children = this.codeList.map(code => {
        code.code_div = this.codeInfo.detail_code;
        return code;
      });
      return setCode(this.codeInfo).then(res => {
        this.getCodeDivList();
        this.getList(res.data);
        this.$store.dispatch("getCodeList", {}).then(() => {
          alert("저장했습니다.");
        });
      });
    },
    deleteCode() {
      deleteCode(this.codeInfo).then(res => {
        alert("삭제했습니다.");
      });
    },
    getCodeDivList() {
      getCodeList({ code_div: "code_div" }).then(res => {
        this.codeDivList = res.data.map(item => {
          item.checked = false;
          return item;
        });
      });
    },
    getList(item) {
      this.isNew = false;
      this.codeInfo.detail_code = item.detail_code;
      this.codeInfo.value = item.value;
      getCodeList({ code_div: item.detail_code }).then(res => {
        this.codeList = res.data;
      });
    },
    selectChange(selection, rowData) {
      this.selectedCodeList = selection;
    },
    addItem() {
      this.codeInfo.sort1 = this.codeList.length;
      this.codeList.push(Object.assign({}, this.codeInfo));
    },
    delItem() {
      this.codeList = this.codeList.filter(
        (item, index) =>
          !this.selectedCodeList.filter(code => index == code.index).length
      );
    },
    cellEditDone(newValue, oldValue, rowIndex, rowData, field) {
      this.codeList[rowIndex][field] = newValue;
    },
    addNew() {
      this.isNew = true;
      this.codeInfo = {
        code_div: "code_div",
        detail_code: null,
        value: "",
        sort1: 0,
        description: "",
        children: []
      };
      this.codeList = [];
    }
  },
  created() {
    this.getCodeDivList();
  }
};
</script>
