<template>
  <form class="form-horizontal">
    <fieldset>
      <widget-container>
        <div class="form-box">
            <div class="form-group">
              <label class="col-sm-1 control-label">로그유형</label>
              <div class="col-sm-2">
                <v-dropdown
                  name="log_type"
                  inputClass="form-control form-control-sm"
                  v-model="log_type"
                  placeholder="전체"
                  code="log_type"
                />
              </div>
              <label class="col-sm-1 control-label">날짜</label>
              <div class="col-sm-4 grid-box date-group">
                <datepicker
                  inputClass="form-control form-control-sm"
                  name="start_dt"
                  v-model="start_dt"
                  class="datepicker-comm"
                ></datepicker>
                <span class="txt-dash">~</span>
                <datepicker
                  inputClass="form-control form-control-sm"
                  name="end_dt"
                  v-model="end_dt"
                  class="datepicker-comm"
                ></datepicker>
              </div>
              <!-- <label class="text-sm-right  control-label">조직: </label>
                <v-dropdown
                  name="dept_no"
                  inputClass="form-control form-control-sm"
                  v-model="dept_no"
                  placeholder="전체"
                  code="dept_no"
              />-->
              <div class="col-sm-4 control-box grid-box">
                <v-dropdown
                  name="search_type"
                  inputClass="form-control form-control-sm"
                  v-model="search_type"
                  placeholder
                  :options="[{label:'아이디', value:'user_id'}]"
                />
                <input
                  placeholder="검색어 입력"
                  type="text"
                  class="form-control form-control-sm"
                  @keyup.13="getList"
                  style="width:100px"
                  v-model="search_text"
                />
                <span class="input-group-append">
                  <button
                    type="button"
                    class="btn btn-sm btn-primary"
                    @click="search"
                  >검색</button>
                </span>
              </div>
            </div>

        </div>
        <div class="table-responsive tbl-wrap-type1">
          <div style="padding: 8px;white-space: nowrap;">
            <i class="fa fa-list"></i>
            검색결과 : {{this.totalCount}} 건
          </div>
          <v-table
            is-horizontal-resize
            style="width:100%"
            :isVerticalResize="true"
            :columns="[{field: 'log_type', title: 'type', width: 100, titleAlign: 'center', columnAlign: 'center', type:'code'},
                        {field: 'action', title: 'action', width: 100, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'target', title: 'target', width: 100, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'user_id', title: '아이디', width: 100, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'user_nm', title: '이름', width: 100, titleAlign: 'center', columnAlign: 'center'},                                                
                        {field: 'ip', title: '접속아이피', width: 150, titleAlign: 'center', columnAlign: 'center'},
                        {field: 'create_date_time', title: '시간', width: 200, titleAlign: 'center', columnAlign: 'center', isResize: true}]"
            :table-data="tableData"
          ></v-table>
        </div>
        <div class="row">
          <div class="col-sm-12 m-t-xs align-content-center">
            <v-pager
              v-model="pageIndex"
              :page-count="pageCount"
              @change="onChange"
              @pageSizeChange="pageSizeChange"
            ></v-pager>
          </div>
        </div>
      </widget-container>
    </fieldset>
  </form>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getLogList } from "../../services";

export default {
  name: "table",
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 10,
      start_dt: "",
      end_dt: "",
      dept_no: "",
      log_type: "",
      search_text: "",
      search_type: "user_id"
    };
  },
  watch: {
    $route(to, from) {
      if (to.query.page_index) {
        this.pageIndex = Number(to.query.page_index);
      } else {
        this.pageIndex = 1;
      }
      this.getList();
    }
  },
  methods: {
    ...mapActions(["getUserInfo"]),
    onChange() {
      this.$router.push({
        name: "logList",
        query: { page_index: this.pageIndex }
      });
    },
    pageSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },
    selectRow(rowIndex, rowData) {
      this.$router.push({
        name: "user",
        query: { user_id: rowData.user_id }
      });
    },
    getList() {
      return getLogList({
        page_index: this.pageIndex,
        page_size: this.pageSize,
        log_type: this.log_type,
        dept_no: this.dept_no,
        start_dt: this.start_dt,
        end_dt: this.end_dt,
        search_text: this.search_text,
        search_type: this.search_type
      }).then(res => {
        this.totalCount = res.data.total_count;
        this.pageCount = Math.ceil(res.data.total_count / this.pageSize);
        this.tableData = res.data.list;
      });
    },
    search() {
      this.pageIndex = 1;
      this.getList();
    }
  },
  mounted() {
    const query = this.$route.query;
    if (query.page_index) {
      this.pageIndex = Number(query.page_index);
    }
    // this.getList();
  }
};
</script>
