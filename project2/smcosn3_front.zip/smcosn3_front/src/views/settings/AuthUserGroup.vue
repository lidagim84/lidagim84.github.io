<template>
  <div class="row">
    <div class="col-lg-3">
      <widget-container>
        <!-- <template slot="title">권한 사용자 트리</template> -->
        <div class="tit-group">
          <h3 class="title">권한 사용자 트리</h3>
        </div>
        <div class="form-group row">
          <tree
            :data="authList"
            show-checkbox
            @node-click="selectedAuth"
            ref="tree"
            node-key="auth_id"
            :props="{label:'auth_nm'}"
          ></tree>
        </div>
        <!-- <div class="row">
            <div class="col-md-12 list-btn-group">
              <button
                type="button"
                class="btn btn-primary btn-sm"
              >삭제</button>
                      <button
                type="button"
                class="btn btn-primary btn-sm"
              >추가</button>
            </div>
        </div>-->
      </widget-container>
    </div>
    <div class="col-lg-9">
      <widget-container>
        <!-- <template slot="title">권한 사용자 그룹</template> -->
        <div class="tit-group">
          <h3 class="title">권한 사용자 그룹</h3>
        </div>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              권한그룹
              <span class="require">*</span>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="authInfo.auth_nm" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              사용자 그룹
              <span class="require">*</span>
            </label>
            <div class="col-sm-10">
              <div class="list-btn-group mb-10">
                <div class="float-right">
                  <button
                    class="btn-strong"
                    type="button"
                    @click="addMng(true).then(res => {userList = [...userList, ...res];})"
                  >
                    <i class="fa fa-plus"></i> 추가
                  </button>
                  <button class="btn-normal" type="button" @click="deleteUser">
                    <i class="fa fa-minus"></i> 삭제
                  </button>
                </div>
              </div>

              <v-table
                is-horizontal-resize
                style="width:100%"
                :height="(userList.length+1)*constants.RowHeight"
                :isVerticalResize="true"
                :columns="[
                          {field: 'user_id', width: 60, titleAlign: 'center',columnAlign:'center',type: 'selection'},
                          { field: 'user_id', title: '아이디', width: 80, titleAlign: 'center', columnAlign: 'center', isResize: true }, 
                          { field: 'user_nm', title: '이름', width: 80, titleAlign: 'center', columnAlign: 'center', isResize: true },
                          { field: 'pos_no', title: '직위', width: 150, titleAlign: 'center', columnAlign: 'center', isResize: true },
                          { field: 'dept_no', title: '조직', width: 150, titleAlign: 'center', columnAlign: 'center', isResize: true },
                          { field: 'phone_no', title: '전화번호', width: 150, titleAlign: 'center', columnAlign: 'center', isResize: true },
                          { field: 'email', title: '이메일', width: 280, titleAlign: 'center', columnAlign: 'left', isResize: true }]"
                :table-data="userList"
                :select-change="selectChange"
                row-hover-color="#eee"
                row-click-color="#edf7ff"
              ></v-table>
            </div>
          </div>
        </div>
        <div class="list-btn-group group-submit">
          <div class="float-right">
            <button type="button" class="btn-strong" @click="approveReq">저장</button>
          </div>
        </div>
      </widget-container>
    </div>
  </div>
</template>

<script>
import { getAuthUserGrp, setAuthUserGrp, getAuthList } from "../../services";

export default {
  name: "authUserGroup",
  components: {},
  data() {
    return {
      authInfo: {
        auth_id: "",
        auth_nm: "",
        description: "",
        use_yn: "Y",
        userList: [],
        create_user_idx: "test",
        update_user_idx: "test"
      },
      authList: [],
      userList: [],
      selectedUserList: []
    };
  },
  methods: {
    approveReq() {
      let params = this.userList.map(user => {
        user.auth_id = this.authInfo.auth_id;
        user.use_yn = "Y";
        user.create_user_idx = "test";
        user.update_user_idx = "test";
        return user;
      });
      setAuthUserGrp(params).then(res => {
        alert("저장했습니다.");
        this.getList();
      });
    },
    getList() {
      getAuthList({}).then(res => {
        this.authList = res.data.map(item => {
          item.checked = false;
          return item;
        });
      });
    },
    getUserList() {
      getAuthUserGrp(this.authInfo).then(res => {
        this.userList = res.data;
      });
    },
    selectedAuth(item) {
      this.authInfo = item;
      this.getUserList();
    },
    selectChange(selection, rowData) {
      this.selectedUserList = selection;
    },
    deleteUser() {
      this.userList = this.userList.filter(
        item =>
          !this.selectedUserList.filter(user => item.user_id == user.user_id)
            .length
      );
    }
  },
  created() {
    this.getList();
  }
};
</script>
