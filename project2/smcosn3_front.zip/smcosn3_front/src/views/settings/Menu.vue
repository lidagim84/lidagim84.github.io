<template>
  <div class="row">
    <div class="col-lg-3">
      <widget-container>
        <!-- <template slot="title">메뉴 구성</template> -->
        <div class="tit-group"><h3 class="title">메뉴 구성</h3></div>
        <div class="form-group row">
          <tree
            :data="menuList"
            show-checkbox
            @check-change="handleCheckChange"
            ref="tree"
            node-key="menu_id"
            :props="{label:'menu_nm'}"
          ></tree>

          <!-- <tree
              :tree-data="menuList"
              :options="{label:'menu_nm', value: 'menu_id'}"
              @handle="(item)=>menuInfo=item"
          ></tree>-->
        </div>
        <!-- <div class="row">
            <div class="col-md-12 list-btn-group">
              <button
                type="button"
                class="btn btn-primary btn-sm"
              >삭제</button>
                      <button
                type="button"
                class="btn btn-primary btn-sm"
              >추가</button>
            </div>
        </div>-->
      </widget-container>
    </div>
    <div class="col-lg-9">
      <widget-container>
        <!-- <template slot="title">메뉴 등록</template> -->
        <div class="tit-group"><h3 class="title">메뉴 등록</h3></div>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              상위메뉴
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="menuInfo.upper_menu_id" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              메뉴아이디
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="menuInfo.menu_id" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              메뉴명
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="menuInfo.menu_nm" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">메뉴설명</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="menuInfo.description" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              라우터이름
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="menuInfo.router_name" />
            </div>
          </div>
          <!-- <div class="form-group row">
              <label class="col-sm-2 control-label">경로<span class="required">*</span></label>
              <div class="col-sm-10">
                <input
                  type="text"
                  class="form-control"
                  v-model="menuInfo.path"
                >
              </div>
          </div>-->
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              icon
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="menuInfo.icon" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              순번
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control" v-model="menuInfo.sort" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">
              사용여부
              <span class="required">*</span>
            </label>
            <div class="col-sm-10">
              <v-checkbox v-model="menuInfo.use_yn"></v-checkbox>
            </div>
          </div>
        </div>
        <div class="list-btn-group group-submit">
          <!-- <button
              type="button"
              class="btn btn-primary btn-sm"
              @click="approveReq"
          >삭제</button>-->
          <div class="float-right">
            <button type="button" class="btn-strong" @click="approveReq">저장</button>
          </div>
        </div>
 
      </widget-container>
    </div>
  </div>
</template>

<script>
import { getMenuList, getMenu, setMenu } from "../../services/settings";

export default {
  name: "menu",
  components: {},
  data() {
    return {
      menuInfo: {
        menu_id: "",
        menu_nm: "",
        description: "",
        router_name: "",
        icon: "",
        path: "",
        use_yn: "Y",
        upper_menu_id: "",
        sort: 0,
        update_user_idx: "test_user_01",
        create_user_idx: "test_user_01"
      },
      menuList: []
    };
  },
  methods: {
    approveReq() {
      setMenu(this.menuInfo).then(res => {
        alert("저장했습니다.");
        this.getList();
      });
    },
    selectedMenu(item) {},
    getList() {
      getMenuList({}).then(res => {
        this.menuList = res.data;
      });
    },
    handleCheckChange(data) {
      console.log(data);
      this.menuInfo = data;
      //console.log(this.$refs.tree.getCheckedKeys());
    }
  },
  created() {
    this.getList();
  }
};
</script>
