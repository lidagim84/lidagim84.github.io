<template>
  <div class="row">
    <div class="col-lg-12">
      <widget-container>
        <div class="form-box">
          <div class="form-group row">
            <label class="col-sm-2 control-label">신청ID</label>
            <div class="col-sm-10">
              <input
                id="user_id"
                name="user_id"
                type="text"
                readonly
                class="form-control"
                v-model="userInfo.user_id"
                v-validate="'required'"
              />
              <label class="error" v-show="errors.has('user_id')">{{ errors.first('user_id') }}</label>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 control-label">이름</label>
            <div class="col-sm-10">
              <input
                id="user_nm"
                name="user_nm"
                type="text"
                class="form-control"
                v-model="userInfo.user_nm"
                v-validate="'required'"
              />
              <label class="error" v-show="errors.has('user_nm')">{{ errors.first('user_nm') }}</label>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 control-label">사용자유형</label>
            <div class="col-sm-10">
              <v-dropdown
                id="user_type"
                name="user_type"
                v-model="userInfo.user_type"
                v-validate="'required'"
                code="user_type"
              ></v-dropdown>
              <label class="error" v-show="errors.has('user_type')">{{ errors.first('user_type') }}</label>
            </div>
          </div>

          <div v-if="userInfo.user_type=='councilor'" class="form-group row">
            <label class="col-sm-2 control-label">상임위원회</label>
            <div class="col-sm-10">
              <v-dropdown
                id="councilor_dept_cd"
                name="councilor_dept_cd"
                v-model="deptList.ld_cd"
                v-validate="'required'"
                code="ld_cd"
              ></v-dropdown>
              <!-- <v-dropdown
                id="councilor_dept_cd"
                name="councilor_dept_cd"
                v-model="userInfo.dept_no"
                v-validate="'required'"
                code="dept_cd"
              ></v-dropdown> -->
              <label
                class="error"
                v-show="errors.has('councilor_dept_cd')"
              >{{ errors.first('councilor_dept_cd') }}</label>
              <!-- <search-input
                id="dept_no"
                name="dept_no"
                :options="deptList"
                labelField="ld_nm"
                valueField="ld_cd"
                v-model="userInfo.dept_cd"
              ></search-input>
              <label class="error" v-show="errors.has('dept_no')">{{ errors.first('dept_no') }}</label>-->
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 control-label">비밀번호</label>
            <div class="col-sm-10">
              <input
                id="password1"
                name="password1"
                type="password"
                class="form-control"
                v-model="userInfo.password1"
                v-validate="'required'"
              />
              <label class="error" v-show="errors.has('password1')">{{ errors.first('password1') }}</label>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">비밀번호 확인</label>
            <div class="col-sm-10">
              <input
                id="password_confirmed"
                name="password_confirmed"
                type="password"
                class="form-control"
                v-model="userInfo.password_confirmed"
                v-validate="'required'"
              />
              <label class="error" v-show="errors.has('password_confirmed')">{{ errors.first('password_confirmed') }}</label>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 control-label">휴대폰번호</label>
            <div class="col-sm-10">
              <input name="hp_no" type="text" class="form-control" v-model="userInfo.hp_no" />
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 control-label">전화번호</label>
            <div class="col-sm-10">
              <input name="phone_no" type="text" class="form-control" v-model="userInfo.phone_no" />
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 control-label">이메일</label>
            <div class="col-sm-10">
              <input
                name="email"
                type="text"
                class="form-control"
                v-model="userInfo.email"
                maxlength="200"
              />
            </div>
          </div>
        </div>

        <div class="col-md-12 list-btn-group group-submit">
          <div class="float-right">
            <button type="button" class="btn-strong" @click="approveReq">저장</button>
            <button v-if="isAdmin" type="button" class="btn-strong" @click="goList">목록으로</button>
          </div>
        </div>
      </widget-container>
    </div>
  </div>
</template>

<script>
import { getUser, setUser, getDeptList } from "../../services";

export default {
  name: "user",
  components: {},
  data() {
    return {
      userInfo: {
        user_id: "",
        user_nm: "",
        password: "",
        password1: "",
        password_confirmed: "",
        user_type: "",
        pos_no: "",
        dept_cd: "",
        update_user_idx: "",
        create_user_idx: ""
      },
      deptList: [],
      staffData: []
    };
  },
  methods: {
    approveReq() {
      this.$validator.validateAll().then(res => {
        if (res) {
          this.setUser();
        }
      });
    },
    setUser() {

      if (this.userInfo.password1 != this.userInfo.password_confirmed) {
        alert("암호가 일치하지않습니다.");
        return;
      }
      this.userInfo.password = this.userInfo.password1;

      setUser(this.userInfo).then(res => {
        this.alert(
          "저장완료",
          `사용자 계정: ${res.data.user_id}\n 저장 했습니다.`,
          "success"
        ).then(() => {
          if (this.isAdmin) this.$router.push({ name: "userList" });
        });
      });
    },
    getDeptList() {
      return getDeptList({}).then(res => {
        const data = res.data;
        if (data.length) {
          this.deptList = data[0].children;
        }
        return data;
      });
    },
    goList() {
      this.$router.push({ name: "userList" });
    }
  },
  created() {
    this.getDeptList();
    if (this.$route.query.user_id) {
      getUser(this.$route.query).then(res => {
        this.userInfo = res.data;
      });
    } else {
      getUser({ user_id: this.loginUserInfo.user_id }).then(res => {
        this.userInfo = res.data;
      });
    }
  }
};
</script>
