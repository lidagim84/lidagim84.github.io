<template>
  <div class="mainnav">
    <div class="container">
      <nav class="collapse mainnav-collapse" :class="{'in':showMenu}" role="navigation">
        <ul class="mainnav-menu">
          <li
            v-show="menu.visible == undefined || menu.visible"
            v-for="(menu, index) in menuList"
            :class="{'active open':menu.expanded}"
            :key="index"
            class="dropdown"
            @mouseover="focus(menu)"
          >
            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
              {{menu.menu_nm}}
              <i class="mainnav-caret"></i>
            </a>

            <ul
              class="dropdown-menu mega-dropdown-menu mega-menu-1"
              role="menu"
              @mouseleave="focusout"
              v-clickoutside="focusout"
            >
              <li>
                <div class="mega-menu-content">
                  <div class="mega-menu-col">
                    <ul class="mega-menu-menu">
                      <li
                        v-show="sencondMenu.visible == undefined || sencondMenu.visible"
                        v-for="(sencondMenu, index) in menu.children"
                        :class="{'active' : (sencondMenu.children && sencondMenu.expanded) || (!sencondMenu.children && currentMenuInfo && sencondMenu.menu_id == currentMenuInfo.menu_id), 'mega-menu-header': sencondMenu.children}"
                        :key="index"
                      >
                        <a herf="#" v-if="!sencondMenu.children" @click="go(sencondMenu)">
                          <!-- <i class="fa fa-dashboard dropdown-icon"></i> -->
                          {{sencondMenu.menu_nm}}
                        </a>
                        {{sencondMenu.children ? sencondMenu.menu_nm : ''}}
                        <ul v-if="sencondMenu.children" class="mega-menu-menu third">
                          <li
                            v-show="thirdMenu.visible == undefined || thirdMenu.visible"
                            v-for="(thirdMenu, index) in sencondMenu.children"
                            :class="currentMenuInfo && thirdMenu.menu_id == currentMenuInfo.menu_id ? 'active' : ''"
                            :key="index"
                          >
                            <a @click.prevent="go(thirdMenu)">{{thirdMenu.menu_nm}}</a>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    </div>
    <!-- /.container -->
  </div>
  <!-- /.mainnav -->
</template>

<script>
export default {
  name: "navbar",
  props: {
    showMenu: {
      type: false
    },
    task_id: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      menuDepth: []
    };
  },
  computed: {
  },
  methods: {
    focus(menu) {
      this.menuList.map(item => {
        if (item.menu_id == menu.menu_id) {
          item.expanded = true;
        } else {
          item.expanded = false;
        }
        return item;
      });
    },
    focusout() {
      this.menuList.map(item => {
        item.expanded = false;
        return item;
      });
    },
    go(menu) {
      menu.expanded = !menu.expanded;
      this.menuDepth = [];
      if (menu) {
        this.setMenu(this.getCurrnetMenu(menu.menu_id, this.menuList, 0));
        if (menu.router_name) {
          this.$router.push({ name: menu.router_name, query: menu.query });
        } else if (menu.path) {
          this.$router.push({ path: menu.path });
        }
      }
    }
  },
  watch: {
    menuList: function(val) {
      //menu.json에 등록되지 않은 입력 폼은 currentMenu어떻게?
    }
  },
  created() {
    // this.setMenu(this.getCurrnetMenu(this.$route.name, this.menuList));
    let param = { type: this.userRoleType };
    this.getMenuList(param);
  }
};
</script>


<style>
.logo-element img {
  width: 100%;
  margin: auto !important;
  padding: 10px 20px 10px 20px;
}
</style>
