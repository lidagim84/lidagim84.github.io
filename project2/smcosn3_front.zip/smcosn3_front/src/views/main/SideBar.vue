<template>
  <div
    id="right-sidebar"
    class="animated sidebar-open"
  >
    <div
      class="slimScrollDiv"
      style="position: relative; overflow: hidden; width: auto; height: 100%;"
    >
      <div
        class="sidebar-container"
        style="overflow: hidden; width: auto; height: 100%;"
      >
        <!-- <ul class="nav nav-tabs navs-3">
          <li>
            <a
              class="nav-link"
              data-toggle="tab"
              href="#tab-1"
            > Notes </a>
          </li>
          <li>
            <a
              class="nav-link"
              data-toggle="tab"
              href="#tab-2"
            > Projects </a>
          </li>
          <li>
            <a
              class="nav-link active show"
              data-toggle="tab"
              href="#tab-3"
            > <i class="fa fa-gear"></i> </a>
          </li>
        </ul> -->

        <div class="tab-content">

          <div
            id="tab-3"
            class="tab-pane active show"
          >

            <div class="sidebar-title">
              <h3><i class="fa fa-gears"></i> 대쉬보드 위젯 설정</h3>
              <small><i class="fa fa-tim"></i> 대쉬보드 위젯을 추가 설정 할 수 있습니다.</small>
            </div>

            <div class="setings-item">
              <span>
                전체화면
              </span>
              <v-switch
                id="fullscreen"
                v-model="fullScreen"
              ></v-switch>
            </div>
            <div
              class="setings-item"
              v-for="(item, index) in list"
              :key="index"
            >
              <span>
                {{item.widgetName}}
              </span>
              <v-switch
                :id="'switch-'+ index"
                v-model="item.checked"
              ></v-switch>

            </div>
          </div>
          <div class="row">
            <div class="col-md-12 float-center">
              <button
                type="button"
                class="btn btn-primary btn-sm btn-block"
                @click="setConfig"
              >확인</button>
            </div>
          </div>
        </div>
      </div>

      <div
        class="slimScrollBar"
        style="background: rgb(0, 0, 0); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 908px;"
      ></div>
      <div
        class="slimScrollRail"
        style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.4; z-index: 90; right: 1px;"
      ></div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
import { getConfig, setConfig } from '../../services';
import Switch from '../../components/radio/Switch';
export default {
  name: 'sidebar',
  components: {
    Switch
  },
  data() {
    return {
      list: [],
      isFullScreen: '',
      auth_id: 'admin'
    };
  },
  computed: {
    ...mapGetters(['menuList', 'currentMenuInfo'])
  },
  methods: {
    getWidgetList(list) {
      for (let row of list) {
        for (let column of row.columns) {
          if (column.componentName) {
            this.list.push(column);
          } else if (column.rows && column.rows.length) {
            this.getWidgetList(column.rows);
          }
        }
      }
    },
    getConfig() {
      getConfig().then(res => {
        let items = res.data.default.rows;
        // if (res.data[this.auth_id]) {
        //   items = res.data[this.auth_id].rows;
        // }
        this.getWidgetList(items);

        this.list = this.list.map(item => {
          if (this.configItemList.length) {
            item.checked =
              this.configItemList.filter(
                widget => widget.componentName == item.componentName
              ).length == true;
          } else {
            item.checked = true;
          }
          return item;
        });
      });
    },
    setConfig() {
      let items = this.list.filter(item => item.checked);
      let config = JSON.stringify(items);
      setConfig({
        user_id: this.loginUserInfo.user_id,
        config: config
      }).then(res => {
        debugger;
        if (res.data && res.data.config) {
          localStorage.setItem('configInfo', config);
          this.$EventBus.$emit('updateConfig', items);
        }
        this.$emit('update', this.fullScreen);
      });
    }
  },
  created() {
    this.getConfig();
  }
};
</script>

<style>
.btn-block {
  margin: 20px;
}
</style>
