<template>
  <li class="dropdown show">
    <a
      class="dropdown-toggle count-info"
      data-toggle="dropdown"
      href="#"
      aria-expanded="true"
      @click="() => show = !show"
    >
      <i class="fa fa-bell"></i> <span
        v-if="notiCount > 0"
        class="label label-primary"
      >{{notiCount}}</span>
    </a>
    <ul
      class="dropdown-menu dropdown-alerts show"
      v-if="notiCount > 0 && show"
    >
      <li
        v-for="(task, index) in list"
        :key="index"
      >
        <a
          href="mailbox.html"
          class="dropdown-item"
        >
          <div>
            <i class="fa fa-envelope fa-fw"></i> {{task.req_user_nm}}님이 {{stateName[task.state]}} 했습니다.
            <span class="float-right text-muted small">{{task.create_date_time | fromNow}}</span>
          </div>
        </a>
      </li>
      <li class="dropdown-divider"></li>
      <li>
        <div class="text-center link-block">
          <a
            href="notifications.html"
            class="dropdown-item"
            @click="confirmNoti"
          >
            <strong>See All Alerts</strong>
            <i class="fa fa-angle-right"></i>
          </a>
        </div>
      </li>
    </ul>
  </li>
</template>

<script>
import { getNotiList, setNoti } from '../../services';
import { mapGetters } from 'vuex';

export default {
  name: 'notify',
  computed: {
    ...mapGetters(['userInfo', 'currentMenuInfo'])
  },
  data() {
    return {
      list: [],
      show: false,
      notiCount: 0,
      viewToastList: []
    };
  },
  methods: {
    getNotiList() {
      getNotiList({
        approver_id: this.loginUserInfo.user_id,
        confirm: 'N'
      }).then(res => {
        this.list = res.data;
        this.notiCount = this.list.length;
        for (let task of res.data) {
          if (this.viewToastList.filter(item => item == task.task_id).length) {
            continue;
          }
          this.$toastr('add', {
            type: 'success',
            title: `${this.jobName[task.job_id]} 번호 : ${task.task_id}`,
            msg: `${task.req_user_nm}님이 ${
              this.stateName[task.state]
            } 했습니다.`
          });
          this.viewToastList.push(task.task_id);
        }
      });
    },
    setNoti(jobId, taskId) {
      return setNoti({
        confirm: 'Y',
        job_id: jobId,
        task_id: taskId,
        approver_id: this.loginUserInfo.user_id
      });
    },
    confirmNoti() {
      for (let task of this.list) {
        this.setNoti(task.job_id, task.task_id);
      }
      this.show = false;
      this.notiCount = 0;
    }
  },
  created() {
    // this.getNotiList();
  }
};
</script>
