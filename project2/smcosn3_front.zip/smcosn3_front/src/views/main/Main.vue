<template>
  <div>
    <div id="wrapper">
      <header class="navbar" role="banner">
        <div class="container">
          <div class="navbar-header">
            <button
              class="navbar-toggle"
              type="button"
              data-toggle="collapse"
              data-target=".navbar-collapse"
            >
              <span class="sr-only">Toggle navigation</span>
              <i class="fa fa-cog"></i>
            </button>
            <a class="mainnav-toggle" data-toggle="collapse" data-target=".mainnav-collapse">
              <span class="sr-only">Toggle navigation</span>
              <i class="fa fa-bars"></i>
            </a>
            <h1>
              <a class="navbar-brand navbar-brand-img" @click="goHome">
                <img src="/assets/images/logo.png" alt="서울특별시의회 입법조사회답시스템" style="height: 100%;" />
              </a>
            </h1>
          </div>
          <!-- /.navbar-header -->
          <!-- <form class="mainnav-form" style="right:45%">
            <input
              type="text"
              class="form-control input-md mainnav-search-query"
              placeholder="Search"
            />
            <button class="btn btn-sm mainnav-form-btn">
              <i class="fa fa-search"></i>
            </button>
          </form>-->

          <div class="collapse navbar-collapse" :class="{'in':showSetting}" role="navigation">
            <div class="inner">
              <div class="navbar-form navbar-search-form">
                <div class="form-group">
                  <input
                    type="text"
                    class="navbar-search-field"
                    placeholder="검색어를 입력하세요."
                    v-on:keyup.13="search"
                  />
                </div>
              </div>

              <ul class="nav navbar-nav">
                <li class="navbar-profile">
                  <a class="dropdown" href="#">
                    {{loginUserInfo.user_nm}}
                    <span
                      class="text-append"
                    >{{this.loginUserInfo.user_type | code('pos_nm')}}</span>
                  </a>
                </li>
                <li class="dropdown">
                  <a data-toggle="dropdown" href="#" @click="logOut()">로그아웃</a>
                </li>
                <li class="dropdown">
                  <a class="dropdown-toggle btn-alarm" data-toggle="dropdown" href="javascript:;">알림</a>
                </li>
                <li>
                  <div class="page-control">
                    <button type="button" class="control" title="화면 확대">
                      <i class="fa fa-plus"></i>
                    </button>
                    <button type="button" class="control" title="화면크기 초기화">가</button>
                    <button type="button" class="control" title="화면 축소">
                      <i class="fa fa-minus"></i>
                    </button>
                    <a href="#none" class="control query">
                      <span class="ico-query">
                        <img src="assets/images/question.png" alt="물음" />
                      </span>
                    </a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- /.container -->
      </header>
      <nav-bar :showMenu="showMenu"></nav-bar>
      <div class="content">
        <div class="container">
          <div class="page-header" v-if="currentMenuInfo.menu_nm && $route.name != 'dashboard'">
            <ol class="breadcrumb">
              <li v-for="(menu, index) in currentMenuInfo.menuDepth" :key="index">
                <a>{{menu.menu_nm}}</a>
              </li>
            </ol>
            <h2 class="page-title">
              {{currentMenuInfo.menu_nm}}
              <small>{{currentMenuInfo.description}}</small>
            </h2>
          </div>

          <router-view />
        </div>
      </div>
      <!-- .content -->
    </div>
    <!-- /#wrapper -->

    <footer class="footer">
      <div class="container">
        <ul class="list-info">
          <li>
            <strong class="title">본관 :</strong>
            <span>(04519) 서울특별시 중구 세종대로 125 (태평로1가 60-1)</span>
          </li>
          <li>
            <strong class="title">별관 :</strong>
            <span>(04515) 서울특별시 중구 덕수궁길 15 (서소문동 37) 서울특별시의회 의원회관</span>
          </li>
          <li>
            <strong class="title">전화문의 :</strong>
            <span>2180-7843, 7846</span>
          </li>
        </ul>
        <p class="copyright">Copyright © 2018 서울특별시의회. All rights reserved.</p>
        <a href="#none" class="btn-private">개인정보처리방침</a>
      </div>
    </footer>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import NavBar from "@/views/main/NavBar.vue";

export default {
  name: "app",
  components: {
    NavBar
  },
  data() {
    return {
      showMenu: false,
      showSetting: false,
      isShow: false,
      staffData: [],
      selectedEquip: []
    };
  },
  computed: {
    ...mapGetters(["userInfo", "currentMenuInfo"])
  },
  methods: {
    ...mapActions(["logout", "setMenu"]),
    logOut() {
      return this.logout().then(() => this.$router.push("login"));
    },
    goHome() {
      if (this.$route.name == "dashboard") {
        this.$EventBus.$emit("refreshDashboard");
      } else {
        this.$router.push("dashboard");
      }
    },
    search() {
      this.setMenu({});
      this.$router.push({ name: "searchResult" });
    },
    showUserSettingMenu(isBtn) {
      if (isBtn) {
        this.showSetting = !this.showSetting;
      } else {
        this.showSetting = false;
      }
    }
  }
};
</script>

<style>
.show {
  display: block !important;
}

.navbar .navbar-nav > li .text-append {
  font-size: 14px;
}
.navbar-nav > li > [class*="btn"] {
  position: relative;
  background-color: transparent;
  padding-right: 12px;
  height: 26px;
}
.navbar-nav > li > .btn-alarm:before {
  content: "";
  display: inline-block;
  width: 13px;
  height: 14px;
  margin-top: 6px;
  vertical-align: middle;
  background: url("/assets/images/img-alarm.png") no-repeat 0 0;
}

.navbar-nav > li > a {
  padding: 0;
  color: #2b2b2b;
}

.navbar-nav > li .page-control .control + .control {
  margin-left: 3px;
}

.navbar-nav > li .page-control button {
  display: inline-block;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 1px solid #3177b4;
  font-size: 16px;
  color: #6c6c6c;
  box-sizing: border-box;
  background: transparent;
}
.navbar-nav > li .page-control button .fa {
  color: #000;
}
.navbar-nav > li .page-control a {
  vertical-align: top;
}

.navbar-search-form .form-group {
  position: relative;
  background: #fff;
}

.navbar-search-form .form-group:before {
  content: "";
  position: absolute;
  top: 2px;
  right: 0;
  height: 34px;
  width: 34px;
  background: url("/assets/images/ico_search.png") no-repeat 0 0;
}

.navbar-search-form .navbar-search-field {
  font-size: 13px;
  font-weight: 400;
  color: #959595;
  padding-left: 12px;
  padding-right: 34px;
  border: 2px solid #3177b4 !important;
  background-color: transparent !important;
  -webkit-box-shadow: none;
  box-shadow: none;
  border-radius: 0;
  height: 34px;
  width: 292px;
}
.navbar-search-form .navbar-search-field::-webkit-input-placeholder {
  color: #959595;
}
.navbar-search-form .navbar-search-field:-moz-placeholder {
  color: #959595;
}
.navbar-search-form .navbar-search-field::-moz-placeholder {
  color: #959595;
}
.navbar-search-form .navbar-search-field:-ms-input-placeholder {
  color: #959595;
}

@media (max-width: 767px) {
  .navbar-search-form .navbar-search-field {
    width: 100% !important;
  }
  .navbar-search-form {
    position: relative;
    top: 0px;
    box-shadow: none;
    padding: 0px;
    margin-right: 0;
    margin-left: 0;
  }
  .navbar-nav {
    margin: 0;
  }
  .navbar-nav li {
    padding: 7px 0;
  }

  .navbar-nav > li > .btn-alarm:before {
    margin: -1px 4px 0 0;
  }

  .navbar-nav > li > .btn-user + .dropdown-menu {
    display: block;
    position: static;
    float: none;
    width: auto;
    margin-top: 0;
    background-color: transparent;
    border: 0;
    -webkit-box-shadow: none;
    box-shadow: none;
  }
  .navbar-nav li .page-control {
    display: -webkit-flex;
    display: -ms-flex;
    display: flex;
  }
  .navbar-nav li .page-control .control {
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
  }
  .navbar-nav li .page-control .control.query {
    text-align: center;
    background: #3177b4;
  }
}

@media (min-width: 768px) {
  .navbar-form {
    margin: 0;
    padding: 10px 0 0 20px;
  }

  .navbar-nav {
    display: -webkit-flex;
    display: -ms-flex;
    display: flex;
    float: right;
    margin-top: 18px;
  }
  .navbar .navbar-nav > li {
    margin-left: 30px;
  }

  .navbar-nav > li > .btn-alarm {
    width: 28px;
    overflow: hidden;
    font-size: 1px;
    line-height: 0;
    color: transparent;
  }

  .navbar-nav > li > .btn-user + .dropdown-menu {
    top: 38px;
  }
  .navbar-nav > li > [class*="btn"]:after {
    content: "";
    position: absolute;
    right: 0;
    bottom: 10px;
    width: 9px;
    height: 5px;
    background: url("/assets/images/ico_triangle.png") no-repeat 0 0;
  }
  .navbar-nav > li .page-control {
    margin-top: -6px;
  }
}

.panel-title {
  font-weight: normal;
  padding: 0 20px 0 20px;
  font-size: 1.15em;
  line-height: 42px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.panel-title {
  margin-top: 0;
  margin-bottom: 0;
  font-size: 16px;
  color: inherit;
}

.panel .panel-heading,
.panel > :first-child {
  border-top-left-radius: 2px;
  border-top-right-radius: 2px;
}
.panel-heading {
  position: relative;
  height: 12px;
  padding: 0;
  color: #4d627b;
}

.panel .panel-footer,
.panel > :last-child {
  border-bottom-left-radius: 2px;
  border-bottom-right-radius: 2px;
}
.panel-footer {
  background-color: #fdfdfe;
  color: #7a878e;
}
.panel-footer {
  background-color: #fdfdfe;
  color: #7a878e;
  border-color: rgba(0, 0, 0, 0.02);
  position: relative;
}
.panel-footer {
  /* padding: 10px 15px; */
  background-color: #f5f5f5;
  border-top: 1px solid #ddd;
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
}

[class^="col-"]:not(.pad-no) {
  /* padding-left: 10px;
  padding-right: 10px; */
}

.nano {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.panel-warning .panel-heading,
.panel-warning .panel-footer,
.panel-warning.panel-colorful {
  background-color: #ffd36a;
  border-color: #ffb300;
  color: #fff;
}

.panel-info .panel-heading,
.panel-info .panel-footer,
.panel-info.panel-colorful {
  background-color: #a0d4ec;
  border-color: #03a9f4;
  color: #fff;
}
.panel-success .panel-heading,
.panel-success .panel-footer,
.panel-success.panel-colorful {
  background-color: #8bc34a;
  border-color: #8bc34a;
  color: #fff;
}

.panel-purple .panel-heading,
.panel-purple .panel-footer,
.panel-purple.panel-colorful {
  background-color: #ab47bc;
  border-color: #ab47bc;
  color: #fff;
}

.panel-mint .panel-heading,
.panel-mint .panel-footer,
.panel-mint.panel-colorful {
  background-color: #9ed361;
  border-color: #26a69a;
  color: #fff;
}

.panel-danger .panel-heading,
.panel-danger .panel-footer,
.panel-danger.panel-colorful {
  background-color: #e7a09e;
  border-color: #f44336;
  color: #fff;
}

.media:first-child {
  margin-top: 0;
}
.pad-all {
  padding: 5px;
  font-size: 18px;
}

.panel {
  border: 0;
  border-radius: 3px;
  box-shadow: none !important;
  /* margin-bottom: 20px; */
}

.media:first-child {
  margin-top: 0;
}
.media,
.media-body {
  overflow: hidden;
  zoom: 1;
}
.media {
  margin-top: 15px;
}
.media-body,
.media-left,
.media-right {
  display: table-cell;
  vertical-align: top;
}
.media-left,
.media > .pull-left {
  padding-right: 10px;
}

.text-main,
a.text-main:hover,
a.text-main:focus {
  color: #4d627b;
}
.text-2x {
  font-size: 1.2em;
}
.text-3x {
  font-size: 1.3em;
}
.text-thin {
  font-weight: 300;
}
.pad-lft {
  padding-left: 5px;
}
.text-semibold {
  font-weight: 600;
}
.progress {
  margin-bottom: 0;
}
.icon-3x {
  font-size: 3em;
  line-height: 1em;
}

.mar-no {
  margin: 0;
}

.float-left {
  float: left !important;
}
.float-right {
  float: right !important;
}
.float-none {
  float: none !important;
}

.list-btn-group {
  text-align: center;
}

.list-btn-group:after {
  content: "";
  display: block;
  clear: both;
}

.list-btn-group .float-right [class*="btn"] {
  margin: 0 0 0 5px;
}
.list-btn-group .float-left [class*="btn"] {
  margin: 0 5px 0 0;
}

.list-btn-group.group-submit {
  margin: 100px 0 52px;
}

@media (max-width: 767px) {
  .list-btn-group {
    text-align: right;
  }

  .list-btn-group .float-left,
  .list-btn-group .float-right {
    display: inline-block;
    float: none !important;
  }

  .list-btn-group [class*="btn"],
  .list-btn-group .float-left [class*="btn"] {
    margin: 0 0 0 5px;
  }
  .list-btn-group.group-submit {
    margin: 50px 0 35px;
  }
}

@media (min-width: 768px) {
  .list-btn-group.group-submit [class^="btn"] {
    padding: 0 30px;
  }
}
</style>