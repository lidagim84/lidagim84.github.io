<template>
  <widget-container>
    <h5 slot="title">
      Activity.
    </h5>
    <div class="feed-activity-list">
      <div
        class="feed-element"
        v-for="(task, index) of taskList"
        :key="index"
      >
        <div class="media-body">
          <span class="float-right">{{task.create_date_time}}</span>
          <span
            :class="stateClass(task.state)"
            style="padding: 0px 3px 1px 3px;"
          >{{task.state | code('task_state')}}</span> {{task.req_user_nm}}
          <div
            class="actions"
            v-if="task.etc"
          >
            <span class="text-muted small"> {{task.etc}}</span>
          </div>
        </div>

      </div>
    </div>
  </widget-container>
</template>

<script>
import { getTaskInfo, setTaskInfo } from '../../services/common';

export default {
  name: 'activity-widget',
  props: {
    job_id: {
      type: String,
      default: ''
    },
    task_id: {
      type: String,
      default: ''
    }
  },
  data: function() {
    return {
      taskList: []
    };
  },
  computed: {},
  watch: {
    task_id(newVal) {
      if (newVal) {
        this.getTaskInfo();
      }
    }
  },
  methods: {
    getTaskInfo() {
      return getTaskInfo({ job_id: this.job_id, task_id: this.task_id }).then(
        res => (this.taskList = res.data.filter(item => item.state))
      );
    },
    setTaskInfo(taskId, state) {
      return setTaskInfo({
        job_id: this.job_id,
        task_id: taskId,
        req_user_id: this.loginUserInfo.user_id,
        approver_id: this.userInfo.user_id,
        state: state
      }).then(res => {
        return res.data;
      });
    },
    selectedApprover() {
      this.addMng().then(res => {
        this.userInfo = res;
        this.$emit('selectedApprover', res);
        return res;
      });
    }
  },
  created() {
    if (this.task_id) {
      this.getTaskInfo();
    }
    // this.$EventBus.$on('updateTask', taskList => {
    // this.taskList = taskList.filter(item => item.state);
    // });
  }
};
</script>

<style>
.feed-element {
  margin: 2px 0 2px 0;
  padding: 4px 0 5px 0;
}

.feed-activity-list .feed-element:last-child {
  border-bottom: none !important;
}
</style>
