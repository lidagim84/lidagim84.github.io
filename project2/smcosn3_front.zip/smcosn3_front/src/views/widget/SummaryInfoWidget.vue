<template>
  <div>
    <div class="text-left" @click="goPage">
      <span class="icon-stat-label">{{config.widgetName}}</span>
      <p class="icon-stat-text">{{config.description}}</p>
      <span class="icon-stat-value">
        <span class="number">{{count}}</span>건
      </span>
    </div>
  </div>
</template>

<script>
import { getTaskInfo, setTaskInfo, getSummaryStat } from "../../services";

export default {
  name: "summary-info-widget",
  props: {
    config: {
      type: Object
    }
  },
  data: function() {
    return {
      count: 0
    };
  },
  computed: {},
  methods: {
    goPage() {
      // this.$router.push({
      //   name: "requestList",
      //   query: { state_list: this.config.fieldName.toLowerCase() }
      // });

      this.$EventBus.$emit(
        "updateState",
        this.config.fieldName.toLowerCase(),
        this.config.widgetName
      );
    },
    getList() {
      let _this = this;
      this.getSummaryStat().then(res => {
        if (_this.config.fieldName && res) {
          _this.count = res[_this.config.fieldName];
        }
      });
    }
  },
  created() {
    this.getList();

    this.$EventBus.$on("refreshDashboard", () => {
      this.getList();
    });
  }
};
</script>