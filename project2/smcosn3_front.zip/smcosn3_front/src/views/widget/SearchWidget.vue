<template>
  <div class="portlet portlet-boxed">
    <div class="portlet-header">
      <h2 class="portlet-title">요청·회답 검색</h2>
    </div>
    <div class="portlet-body">
      <table class="table tbl-dash2">
        <colgroup>
          <col style="width:85px;" />
          <col />
        </colgroup>
        <tbody>
          <tr>
            <th scope="row">검색기간</th>
            <td>
              <div class="v-checkbox-group">
                <div class="input-group">
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>전체</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>1주일</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>1달</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>6달</span>
                  </label>
                </div>
              </div>
              <div class="grid-box date-group">
                  <datepicker
                    inputClass="form-control form-control-sm"
                    name="start_dt"
                    v-model="start_dt"
                    class="datepicker-comm"
                  ></datepicker>
                  <span class="txt-dash">~</span>
                  <datepicker
                    inputClass="form-control form-control-sm"
                    name="end_dt"
                    v-model="end_dt"
                    class="datepicker-comm"
                  ></datepicker>
              </div>
            </td>
          </tr>
          <tr>
            <th scope="row">검색어</th>
            <td>
              <div class="grid-box">
                <select class="form-control form-control-sm" style="width:30%;">
                  <option>선택하세요.</option>
                </select>
                <input type="text" class="form-control" />
              </div>
            </td>
          </tr>
          <tr>
            <th scope="row">검색영역</th>
            <td>
              <div class="v-checkbox-group">
                <div class="input-group">
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>전체</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>제목</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>내용</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>첨부파일</span>
                  </label>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td></td>
            <td>
              <button type="button" class="btn-color color1">검색</button>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
</template>

<script>
import { getTaskInfo, setTaskInfo } from "../../services";

export default {
  name: "search-widget",
  props: {
    job_id: {
      type: String,
      default: "",
      required: true
    },
    task_id: {
      type: String,
      default: "",
      required: true
    }
  },
  data: function() {
    return {};
  },
  computed: {},
  watch: {
    task_id(newVal) {
      if (newVal) {
        this.getTaskInfo();
      }
    }
  },
  methods: {},
  created() {}
};
</script>

<style>
.feed-element {
  margin: 2px 0 2px 0;
  padding: 4px 0 5px 0;
}

.feed-activity-list .feed-element:last-child {
  border-bottom: none !important;
}
</style>
