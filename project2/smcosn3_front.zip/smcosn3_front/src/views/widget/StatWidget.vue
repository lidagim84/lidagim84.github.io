<template>
  <div class="portlet portlet-boxed">
    <div class="portlet-header">
      <h2 class="portlet-title">통계</h2>
    </div>

    <div class="portlet-body">
      <table class="table tbl-dash2">
        <colgroup>
          <col style="width:85px;" />
          <col />
        </colgroup>
        <tbody>
          <tr>
            <th scope="row">검색기간</th>
            <td>
              <div class="v-checkbox-group">
                <div class="input-group">
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>전체</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>1주일</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>1달</span>
                  </label>
                  <label class="v-checkbox-wrapper" style="display: inline-block;">
                    <span class="v-checkbox">
                      <input type="checkbox" class="v-checkbox-input" value />
                      <span class="v-checkbox-inner"></span>
                    </span>
                    <span>6달</span>
                  </label>
                </div>
              </div>
              <div class="grid-box date-group">
                  <datepicker
                    inputClass="form-control form-control-sm"
                    name="start_dt"
                    v-model="start_dt"
                    class="datepicker-comm"
                  ></datepicker>
                  <span class="txt-dash">~</span>
                  <datepicker
                    inputClass="form-control form-control-sm"
                    name="end_dt"
                    v-model="end_dt"
                    class="datepicker-comm"
                  ></datepicker>
              </div>
              <div class="grid-box btn-group">
                <div class="grid-row">
                  <button type="button" class="btn-color color2">의원별</button>
                  <button type="button" class="btn-color color3">조사관별</button>
                  <button type="button" class="btn-color color4">요청현황별</button>
                </div>
                <div class="grid-row">
                  <button type="button" class="btn-color color5 txt-sm">의원별요청발의</button>
                  <button type="button" class="btn-color color6">입범지원발의</button>
                  <button type="button" class="btn-color color7">일주계표</button>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { getTaskInfo, setTaskInfo } from "../../services";

export default {
  name: "stat-widget",
  props: {
    job_id: {
      type: String,
      default: "",
      required: true
    },
    task_id: {
      type: String,
      default: "",
      required: true
    }
  },
  data: function() {
    return {};
  },
  computed: {},
  watch: {
    task_id(newVal) {
      if (newVal) {
        this.getTaskInfo();
      }
    }
  },
  methods: {},
  created() {}
};
</script>

<style>
.feed-element {
  margin: 2px 0 2px 0;
  padding: 4px 0 5px 0;
}

.feed-activity-list .feed-element:last-child {
  border-bottom: none !important;
}

.btn-color { background-color:#d8d8d8; }
</style>
