<template>
  <div class="portlet portlet-boxed">
    <div class="portlet-header">
      <h2 class="portlet-title">공지사항·도움말</h2>
    </div>
    <!-- /.portlet-header -->

    <div class="portlet-body">
      <div class="notice-dash">
        <div class="tab-notice">
          <a
            href="#none"
            class="link-notice"
            :class="{'on': board_type =='gongji'}"
            @click="toggleChange('gongji')"
          >공지사항</a>
          <!-- 선택시 on클래스 추가 -->
          <a
            href="#none"
            class="link-help"
            :class="{'on': board_type =='help'}"
            @click="toggleChange('help')"
          >도움말</a>
        </div>
        <ul class="list-notice">
          <li v-for="(item, index) in tableData" :key="index">
            <a href="#none" @click="selectRow(item)">{{ item.title}}</a>
          </li>
        </ul>
      </div>
      <!-- <a href="#none" class="btn_more" @click="$router.push({name:'boardList', query:board_type})">더보기</a> -->
      <a href="#none" class="btn_more" @click="goBoardList()">더보기</a>
    </div>
    <!-- /.portlet-body -->

    <!-- <div class="portlet-header" align="right">
        <button type="button" class="btn-strong" @click="$router.push({name:'request'})">신규 요청</button>
    </div> -->
  </div>
</template>

<script>
import { getTaskInfo, setTaskInfo } from "../../services";
import { mapGetters, mapActions } from "vuex";
import { getBoardList, setBoard, getBoard } from "../../services";

export default {
  name: "boardlist",
  computed: {
    ...mapGetters(["userInfo"])
  },
  data() {
    return {
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 4,
      board_type: "gongji",
      id: "",
      end_dt: "",
      user_id: "",
      user_nm: "",
      state: "",
      search_text: "",
      search_type: "",
      user_type: "",
      vio_cd: ""
    };
  },
  watch: {
    $route(to, from) {
      if (to.query.page_index) {
        this.pageIndex = Number(to.query.page_index);
      } else {
        this.pageIndex = 1;
      }
      // this.state = to.query.state;
      this.getList();
    }
  },

  methods: {
    onChange() {
      this.$router.push({
        name: "boardList",
        query: { page_index: this.pageIndex }
      });
    },
    pageSizeChange(val) {
      this.pageIndex = 1;
      this.pageSize = val;
      this.getList();
    },
    selectRow(item) {
      this.$router.push({
        name: "boardView",
        query: { board_type: item.board_type, id: item.id }
      });
    },
    goBoardList() {
      this.$router.push({
        name: "boardList",
        query: { board_type: this.board_type }
      });
    },
    toggleChange(type) {
      this.board_type = type;
      this.getList();
    },
    getList() {
      return getBoardList({
        page_index: this.pageIndex,
        page_size: this.pageSize,
        board_type: this.board_type
      }).then(res => {
        const data = res.data;
        this.totalCount = data.TOTAL_COUNT;
        this.pageCount = Math.ceil(data.TOTAL_COUNT / this.pageSize);
        this.tableData = data.list;
      });
    },
    search() {
      this.pageIndex = 1;
      this.getList();
    }
  },
  mounted() {
    const query = this.$route.query;
    this.pageIndex = 1;
    if (query.page_index) {
      this.pageIndex = Number(query.page_index);
    }
    this.getList();
  }
};
</script>