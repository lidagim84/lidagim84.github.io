<template>
  <widget-container>
    <h5 slot="title">
      Comment.
    </h5>
    <comment :task_id="task_id"></comment>
  </widget-container>
</template>

<script>
import { getTaskInfo, setTaskInfo } from '../../services';

export default {
  name: 'comment-widget',
  props: {
    job_id: {
      type: String,
      default: '',
      required: true
    },
    task_id: {
      type: String,
      default: '',
      required: true
    }
  },
  data: function() {
    return {};
  },
  computed: {},
  watch: {
    task_id(newVal) {
      if (newVal) {
        this.getTaskInfo();
      }
    }
  },
  methods: {},
  created() {}
};
</script>

<style>
.feed-element {
  margin: 2px 0 2px 0;
  padding: 4px 0 5px 0;
}

.feed-activity-list .feed-element:last-child {
  border-bottom: none !important;
}
</style>
