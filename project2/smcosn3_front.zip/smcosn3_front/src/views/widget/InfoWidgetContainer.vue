<template>
  <div :class="['widget', 'widget-stat', bgClass, 'text-white']">
    <div class="widget-stat-btn"><a
        href="#"
        data-click="widget-reload"
      ><i class="fa fa-redo"></i></a></div>
    <div class="widget-stat-icon"><i :class="iconClass"></i></div>
    <div class="widget-stat-info">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'widget-container',
  props: {
    bgClass: {
      type: String,
      default: 'bg-success'
    },
    iconClass: {
      type: String,
      default: 'fa fa-users'
    }
  },
  data() {
    return {};
  },
  methods: {}
};
</script>

<style>
.widget {
  border: none;
  /* -webkit-box-shadow: 0 2px 0 rgba(0, 0, 0, 0.07); */
  /* box-shadow: 0 2px 0 rgba(0, 0, 0, 0.07); */
  /* -webkit-border-radius: 5px; */
  /* -moz-border-radius: 5px; */
  /* border-radius: 5px; */
  margin-bottom: 20px;
  position: relative;
  /* background: #fff; */
  padding: 20px;
  display: block;
  border-color: #e7eaec;
  border-image: none;
  border-style: solid solid none;
  border-width: 1px 0;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.2),
    0 1px 5px 0 rgba(0, 0, 0, 0.12);
}
.widget-stat-btn {
  position: absolute;
  right: 15px;
  top: 15px;
  z-index: 1000;
}
.widget-stat-icon {
  font-size: 96px;
  color: #000;
  opacity: 0.25;
  position: absolute;
  right: 0;
  bottom: 0;
  top: 25%;
  overflow: hidden;
}
.widget-stat-right .widget-stat-info {
  margin-left: 0;
  margin-right: 0;
  position: relative;
}

.widget-stat-progress {
  margin: 10px -20px;
  position: relative;
}

.widget-stat-right .widget-stat-footer {
  margin: -10px 0;
  text-align: left;
  color: #fff;
  color: rgba(255, 255, 255, 0.7);
  font-size: 12px;
  position: relative;
}
.widget-stat-btn {
  position: absolute;
  right: 15px;
  top: 15px;
  z-index: 1000;
}

.widget-stat-progress .progress {
  /* background: url(../img/transparent/black-0.5.png); */
  background: rgba(0, 0, 0, 0.5);
  height: 2px;
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  border-radius: 0;
}
.progress {
  height: 20px;
  margin-bottom: 20px;
  overflow: hidden;
  background: #eaedef;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}
.progress {
  display: -ms-flexbox;
  display: flex;
  height: 1rem;
  overflow: hidden;
  font-size: 0.75rem;
  background-color: #e9ecef;
  border-radius: 0.25rem;
}

.widget-stat-number {
  font-size: 26px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 700;
}

.text-white {
  color: #fff !important;
}
.bg-success {
  /* background: #17b6a4 !important; */
  background: #17b6a4 !important;
}
.bg-primary {
  background: #2184da !important;
}

.bg-inverse-dark {
  background: #30373e !important;
}
.bg-white {
  background: #fff !important;
  color: #000 !important;
}

.bg-inverse .widget-stat-icon,
.bg-inverse-dark .widget-stat-icon,
.bg-inverse-light .widget-stat-icon {
  color: #fff;
}

.bg-grey,
.bg-secondary {
  background: #8a8f94 !important;
}

.lazur-bg {
  background-color: #3bc0c3 !important;
  color: #ffffff;
}

.purple {
  background-color: #8892d6;
  border-color: #8892d6;
}

.lazur-bg-t {
  background-color: #45bbe0 !important;
  border-color: #45bbe0;
  box-shadow: 0 2px 0 rgba(0, 0, 0, 0.07);
}
.shadow {
  background-color: rgba(255, 255, 255, 0.2);
  /* box-shadow: 0 2px 0 rgba(0,0,0,.07); */
  color: #ffffff;
  overflow: hidden;
  position: relative;
}
.widget-stat-icon {
  font-size: 96px;
  color: #000;
  opacity: 0.25;
  position: absolute;
  right: 0;
  bottom: 0;
  top: 25%;
  overflow: hidden;
}

.chart-summary {
  font-size: 12px;
  font-weight: 500;
}

.chart-summary .text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.chart-summary .number,
.chart-summary .text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.chart-summary + .chart-summary {
  margin-top: 10px;
}

.chart-summary {
  font-size: 12px;
  font-weight: 500;
}

.chart-summary .number {
  font-size: 16px;
  color: #333;
  font-weight: 700;
}

.chart-doughnut {
  float: left;
  /* width: 85px; */
  /* height: 85px; */
}

.chart-bar {
  float: left;
  /* width: 85px; */
  /* height: 85px; */
  padding-right: 20px;
}

.chart-title {
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 15px;
  padding-bottom: 5px;
  border-bottom: 2px solid #ebeced;
}

.chart-info {
  margin-left: 100px !important;
  padding-left: 20px;
}
</style>
