<template>
  <div class="portlet portlet-boxed">
    <div class="portlet-header">
      <h2 class="portlet-title">{{title}} {{totalCount}}건</h2>
    </div>
    <!-- /.portlet-header -->
    <div class="portlet-body">
      <div class="tbl-wrap-type1">
        <v-table
          is-horizontal-resize
          style="width:100%"
          :isVerticalResize="true"
          :columns="[{field: 'req_no', title: '요청번호', width: 90, titleAlign: 'center', columnAlign: 'center', formatter: (rowData,rowIndex,pagingIndex,field) => this.parseReqNo(rowData.req_no)},
                    {field: 'req_type', title: '요청분류', width: 90, titleAlign: 'center', columnAlign: 'center', formatter: (rowData,rowIndex,pagingIndex,field) => this.setReqTypeStyle(rowData.req_type)},
                    {field: 'req_title', title: '요청제목', width: 100, titleAlign: 'center', columnAlign: 'left', isResize: true},                        
                    {field: 'state', title: '현황', width: 280, titleAlign: 'center', columnAlign: 'center', formatter: (rowData,rowIndex,pagingIndex,field) => this.sateProress(rowData.state, rowData.pre_state)},                                    
                    {field: 'examiner_nm', title: '조사관', width: 70, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'dept_cd', title: '담당팀', width: 90, titleAlign: 'center', columnAlign: 'center', type:'code'},                                                                
                    {field: 'councilor_nm', title: '요청인', width: 70, titleAlign: 'center', columnAlign: 'center'},
                    {field: 'create_date_time', title: '요청일', width: 90, titleAlign: 'center', columnAlign: 'center', type: 'datetime'},
                    {field: 'res_limit_dt', title: '회답기한', width: 90, titleAlign: 'center', columnAlign: 'center', type: 'datetime'}]"
          :table-data="tableData"
          :row-click="selectRow"
        ></v-table>
      </div>
      <a href="#none" class="btn_more" @click="goList">더보기</a>
    </div>
    <!-- /.portlet-body -->
  </div>
</template>

<script>
import { getResList } from "../../services";

export default {
  name: "response-list-widget",
  props: {
    job_id: {
      type: String,
      default: "",
      required: true
    },
    task_id: {
      type: String,
      default: "",
      required: true
    }
  },
  data: function() {
    return {
      tableData: [],
      totalCount: 0,
      pageIndex: 1,
      pageCount: 1,
      pageSize: 5,
      start_dt: "",
      end_dt: "",
      user_id: "",
      user_nm: "",
      state: "",
      state_list: [
        "request",
        "wait",
        "res",
        "approve",
        "complete",
        "retract",
        "hold"
      ],
      search_text: "",
      search_type: "",
      user_type: "",
      title: "전체",
      fields: ""
    };
  },
  computed: {},
  watch: {
    task_id(newVal) {
      if (newVal) {
        this.getList();
      }
    }
  },
  methods: {
    getList() {
      this.user_type = this.userIdProp;
      this.user_id = this.loginUserInfo.user_id;
      if (this.user_type == this.constants.RoleType.TeamMember + "_id") {
        this.state = this.constants.ReqState.COMPLETE;
      }
      return getResList({
        page_index: this.pageIndex,
        page_size: this.pageSize,
        search_text: this.search_text,
        search_type: this.search_type,
        user_type: this.user_type,
        user_id: this.user_id,
        state: this.state,
        state_list: this.state_list
      }).then(res => {
        const data = res.data;
        this.totalCount = data.TOTAL_COUNT;
        this.pageCount = Math.ceil(data.TOTAL_COUNT / this.pageSize);
        this.tableData = data.list;
      });
    },
    selectRow(rowIndex, rowData) {
      this.$router.push({
        name: "response",
        query: {
          req_no: rowData.req_no,
          res_no: rowData.res_no,
          req_type: rowData.req_type
        }
      });
    },
    goList() {
      this.$router.push({
        name: "requestList",
        query: { state_list: this.state_list.join("_") }
      });
    }
  },
  created() {
    this.getList();
    this.$EventBus.$on("updateState", (stateList, title) => {
      this.state_list = stateList.split("_");
      if (stateList == "total") {
        this.state_list = [
          ...this.constants.userTypeStateMap.member,
          "retract",
          "hold"
        ];
      }
      this.title = title;
      this.getList();
    });

    this.$EventBus.$on("refreshDashboard", () => {
      this.title = "전체";
      this.state_list = [
        ...this.constants.userTypeStateMap.member,
        "retract",
        "hold"
      ];
      this.getList();
    });
  },
  mounted() {}
};
</script>

<style>
.feed-element {
  margin: 2px 0 2px 0;
  padding: 4px 0 5px 0;
}

.feed-activity-list .feed-element:last-child {
  border-bottom: none !important;
}
</style>
