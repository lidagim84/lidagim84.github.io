<template>
  <div class="portlet portlet-boxed">
    <div class="portlet-header" v-if="$slots['title']">
      <h2 class="portlet-title">
        <slot name="title"></slot>
      </h2>
    </div>
    <div class="portlet-body">
      <slot></slot>
    </div>
    <slot name="footer"></slot>
  </div>
</template>

<script>
export default {
  name: "widget-container",
  props: {
    showTitle: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {};
  },
  methods: {}
};
</script>

<style>
.lazur-bg {
  background-color: #3bc0c3 !important;
  color: #ffffff;
}

.purple {
  background-color: #8892d6;
  border-color: #8892d6;
}

.lazur-bg-t {
  background-color: #45bbe0 !important;
  border-color: #45bbe0;
  box-shadow: 0 2px 0 rgba(0, 0, 0, 0.07);
}
.shadow {
  background-color: rgba(255, 255, 255, 0.2);
  /* box-shadow: 0 2px 0 rgba(0,0,0,.07); */
  color: #ffffff;
  overflow: hidden;
  position: relative;
}
</style>
