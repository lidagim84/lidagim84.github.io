import Vue from 'vue';
import VeeValidate, { Validator } from 'vee-validate';

Validator.extend('earlier', {
  validate: (value, field) => value <= field
});

Validator.extend('later', {
  validate: (value, field) => value >= field
});

const config = {
  locale: 'ko',
  dictionary: {
    ko: {
      attributes: {
        user_id: '사용자 아이디',
        email: '이메일',
        name: '이름',
        password: '패스워드',
        password1: '패스워드',
        password_confirmed: '패스워드 확인',
        homepage: '홈페이지',
        case_name: '사건명',
        case_no: '사건',
        manager_id: '담당자',
        approver_id: '승인자',      
        req_title: '제목',
        res_title: '제목',
        res_desc: '분석내용',
        state: '상태',
        user_nm: '이름',
        hp_no: '휴대전화',
        phone_no: '사무실전화번호',
        dept_cd: '부서명',
        councilor_dept_cd: '상임위원회'        
      },
      messages: {
        email: () => `올바른 이메일 형식이 아닙니다.`,
        required: field => `${field} 필수 입력란입니다.`,
        confirmed: (field, confirmedField) =>
          `${confirmedField}와 일치하지 않습니다.`,
        url: () => `올바른 URL 형식이 아닙니다.`,
        earlier: () => `시작일은 종료일 이전이어야 합니다.`,
        later: () => `종료일은 시작일 이후여야 합니다.`
      }
    }
  }
};

Vue.use(VeeValidate, config);
export default VeeValidate;
