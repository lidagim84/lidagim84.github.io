import moment from 'moment';

function uppercase(input) {
  return input.toUpperCase();
}

export default {
  install(Vue) {
    Vue.filter('uppercase', uppercase);
    Vue.filter('first4Chars', str => str.substring(0, 4));
    Vue.filter('last4Chars', str => str.substring(str.length - 4));
    Vue.filter('datepicker', value =>
      moment(value, 'YYYYMMDD').format('YYYY-MM-DD')
    );
    Vue.filter(
      'dspDate',
      (value, inFormat = 'YYYYMMDD', outFormat = 'YYYY-MM-DD') => {
        return moment(value, inFormat).format(outFormat);
      }
    );
    Vue.filter('datepickerFormat', (value, formatter) =>
      moment(value).format(formatter)
    );
    Vue.filter('datetime', (value, formatter = 'YYYY-MM-DD') => {
      if (value) {
        return moment(value).format(formatter);
      }
    });
    Vue.filter('fromNow', (value, formatter = 'YYYY-MM-DD') => {
      if (value) {
        return moment(value).fromNow();
      }
    });
    Vue.filter('userId', value => {
      let userList = JSON.parse(localStorage.getItem('userList'));
      if (userList && userList.length) {
        let data = userList.filter(item => item.user_id === value);
        value = data.length > 0 ? data[0].user_nm : value;
      }
      return value;
    });
    Vue.filter('numberComma', value => {
      if (!value) {
        return value;
      }
      var parts = value.toString().split('.');
      return (
        parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') +
        (parts[1] ? '.' + parts[1] : '')
      );
    });
    Vue.filter('maxLength', (value, length) => {
      return value.substring(0, length) + '...';
    });

    Vue.filter('code', (value, codeDiv) => {
      let codeList = JSON.parse(localStorage.getItem('commonCodeList'));
      if (codeList && codeList.length) {
        let data = codeList.filter(
          item => item.code_div == codeDiv && item.detail_code == value
        );
        value = data.length > 0 ? data[0].value : value;
      }
      return value;
    });

    Vue.filter('prettyBytes', function (bytes, decimals, kib) {
      kib = kib || false
      if (bytes === 0) return '0 Bytes'
      if (isNaN(parseFloat(bytes)) && !isFinite(bytes)) return 'Not an number'
      const k = kib ? 1024 : 1000
      const dm = decimals || 2
      const sizes = kib ? ['Bytes', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB'] : ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
      const i = Math.floor(Math.log(bytes) / Math.log(k))

      return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i]
    })

    Vue.filter('fileType', function (value) {
      let arr = value.split('.');
      return arr.length ? arr[arr.length - 1] : '';
    })


  }
};
