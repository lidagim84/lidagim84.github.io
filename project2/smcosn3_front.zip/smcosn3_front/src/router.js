import Vue from 'vue';
import Router from 'vue-router';
import store from './store';
// import jwt from 'jsonwebtoken';
// import NProgress from 'nprogress';
// const loading = NProgress.configure({ showSpinner: false });

Vue.use(Router);

var router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/login',
      name: 'login',
      component: () => import('./views/login/Login.vue')
    },
    {
      path: '/desk',
      name: 'desk',
      component: () => import('./views/login/Desk.vue')
    },
    {
      path: '/register',
      name: 'register',
      component: () => import('./views/login/Register.vue')
    },
    {
      path: '/forgotPassword',
      name: 'forgotPassword',
      component: () => import('./views/login/ForgotPassword.vue')
    },
    {
      path: '/forgotId',
      name: 'forgotId',
      component: () => import('./views/login/ForgotId.vue')
    },
    {
      path: '/setPassword',
      name: 'setPassword',
      component: () => import('./views/login/SetPassword.vue')
    },
    {
      path: '/ConfirmID',
      name: 'ConfirmID',
      component: () => import('./views/login/ConfirmID.vue')
    },
    {
      path: '/view',
      name: 'view',
      component: () => import('./views/board/View.vue')
    },
    {
      path: '/',
      name: 'main',
      meta: { authRequired: true },
      component: () => import('./views/main/Main.vue'),
      redirect: '/dashboard',
      children: [
        {
          path: '/guide1',
          name: 'guide1',
          props: true,
          component: () => import('./views/guide/Guide1.vue'),
          meta: { authRequired: true }
        },
        {
          path: '/guide2',
          name: 'guide2',
          props: true,
          component: () => import('./views/guide/Guide2.vue'),
          meta: { authRequired: true }
        },
        {
          path: '/guide3',
          name: 'guide3',
          props: true,
          component: () => import('./views/guide/Guide3.vue'),
          meta: { authRequired: true }
        },
        {
          path: '/dashboard',
          name: 'dashboard',
          props: true,
          component: () => import('./views/dashboard/Dashboard.vue'),
          meta: { authRequired: true }
        },
        {
          path: '/dashboard_bak',
          name: 'dashboard_bak',
          props: true,
          component: () => import('./views/dashboard/Dashboard_bak.vue'),
          meta: { authRequired: true }
        },
        {
          path: '/requestList',
          name: 'requestList',
          props: true,
          component: () => import('./views/req/RequestList.vue')
        },
        {
          path: '/request',
          name: 'request',
          props: true,
          component: () => import('./views/req/Request.vue')
        },
        {
          path: '/responseList',
          name: 'responseList',
          props: true,
          component: () => import('./views/res/ResponseList.vue')
        },
        {
          path: '/responseInitMatching',
          name: 'responseInitMatching',
          props: true,
          component: () => import('./views/res/ResponseInitMatching.vue')
        },
        {
          path: '/responseInitMatchingList',
          name: 'responseInitMatchingList',
          props: true,
          component: () => import('./views/res/ResponseInitMatchingList.vue')
        },
        {
          path: '/responseInitMatchiingDetail',
          name: 'responseInitMatchiingDetail',
          props: true,
          component: () => import('./views/res/ResponseInitMatchiingDetail.vue')
        },
        {
          path: '/response',
          name: 'response',
          props: true,
          component: () => import('./views/res/Response.vue')
        },
        {
          path: '/searchResult',
          name: 'searchResult',
          props: true,
          component: () => import('./views/search/SearchResult.vue')
        },
        {
          path: '/nadbSearchResult',
          name: 'nadbSearchResult',
          props: true,
          component: () => import('./views/search/NADBSearchResult.vue')
        },
        {
          path: '/nadbSearchResult2',
          name: 'nadbSearchResult2',
          props: true,
          component: () => import('./views/search/NADBSearchResult2.vue')
        },
        {
          path: '/myStat',
          name: 'myStat',
          props: true,
          component: () => import('./views/stat/MyStat.vue')
        },
        {
          path: '/userList',
          name: 'userList',
          props: true,
          component: () => import('./views/settings/UserList.vue')
        },
        {
          path: '/user',
          name: 'user',
          props: true,
          component: () => import('./views/settings/User.vue')
        },
        {
          path: '/auth',
          name: 'auth',
          props: true,
          component: () => import('./views/settings/Auth.vue')
        },
        {
          path: '/authMenuGroup',
          name: 'authMenuGroup',
          props: true,
          component: () => import('./views/settings/AuthMenuGroup.vue')
        },
        {
          path: '/authUserGroup',
          name: 'authUserGroup',
          props: true,
          component: () => import('./views/settings/AuthUserGroup.vue')
        },
        {
          path: '/menu',
          name: 'menu',
          props: true,
          component: () => import('./views/settings/Menu.vue')
        },
        {
          path: '/codeList',
          name: 'codeList',
          props: true,
          component: () => import('./views/settings/CodeList.vue')
        },
        {
          path: '/logList',
          name: 'logList',
          props: true,
          component: () => import('./views/settings/LogList.vue')
        },
        {
          path: '/uploadLog',
          name: 'uploadLog',
          props: true,
          component: () => import('./views/settings/UploadLog.vue')
        },
        {
          path: '/boardWrite',
          name: 'boardWrite',
          props: true,
          component: () => import('./views/board/Write.vue')
        },
        {
          path: '/boardList',
          name: 'boardList',
          props: true,
          component: () => import('./views/board/List.vue')
        },
        {
          path: '/boardView',
          name: 'boardView',
          props: true,
          component: () => import('./views/board/View.vue')
        },
        {
          path: '/qna',
          name: 'qna',
          props: true,
          component: () => import('./views/board/Qna.vue')
        }
      ]
    }
  ]
});

// const VUE_APP_TOKEN_SECRET_KEY = process.env.VUE_APP_TOKEN_SECRET_KEY;

// function isAuthenticated() {
//   let token = localStorage.getItem('token');
//   if (token) {
//     let decoded = jwt.verify(
//       token,
//       new Buffer(VUE_APP_TOKEN_SECRET_KEY, 'base64'),
//       {
//         algorithms: ['HS512']
//       }
//     );
//     if (!decoded || (decoded && Math.floor(Date.now() / 1000) > decoded.exp)) {
//       return false;
//     }
//     return true;
//   }
//   return false;
// }

function getCurrnetMenu(to, menuList) {
  let rnt = {};
  for (let m of menuList) {
    if (to.name == m.router_name || to.path == m.path) {
      return (rnt = m);
    } else if (m.children) {
      rnt = getCurrnetMenu(to, m.children);
      if (rnt && rnt.menu_id) {
        return rnt;
      }
    }
  }
  return rnt;
}

function getCurrentMenu(to) {
  // let menuInfo = getCurrnetMenu(to, store.getters.menuList);
}

// router.beforeEach(function (to, from, next) {
//   // to: 이동할 url에 해당하는 라우팅 객체
//   // loading.start();  
//   getCurrentMenu(to);
//   if (
//     to.matched.some(function (routeInfo) {
//       return routeInfo.meta.authRequired;
//     })
//   ) {
//     //http://192.168.20.57:8080/?sso_token=Vy3zFyENGINEx5F1zTyGIDx5FDEMO1zCy1570680079zPy86400zAy23zEyVUmJnSe3vJlOIlmVMww7x79x2BpYx7AqB5Y31drx7Ao9Uwoe4x78ldaDj9stAXux2Bs8x2BoYx79lSERGKd9F159D9Q4bC5R2ELx2F7CsSx2FXCvfjHiIqUMJmTBtQox3DzKyLax7A7x2BOkx2FbdNWLi1VXsaH2sSrVOEXDvNQUUke7x2BlIJSwNx2BveSf6p11VN0DtmGK0kIzSSy00000000111zUURy0123456789ABCDEFzMyAbF5tFB7GPAx3Dz&sRtnUrl=
//     if (!localStorage.getItem('userInfo')) {
//       next('/login');
//     } else {
//       //{ path: to.path, query: { sso_token: to.query.sso_token } }
//       // let url = `${to.path}?sso_token=${to.query.sso_token}`;      
//       next()
//     }
//   } else {
//     next(); // 페이지 전환

//   }

// });

export default router;
