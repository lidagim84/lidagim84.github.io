module.exports = {
  devServer: {
    proxy: {
      '/service': {
        target: 'http://localhost:57626/service',
        changeOrigin: true,
        pathRewrite: {
          '^/service': ''
        }
      }
    }
  }
};
